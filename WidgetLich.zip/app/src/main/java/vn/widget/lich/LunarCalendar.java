package vn.widget.lich;

/** Âm lịch Việt Nam (thuật toán Hồ Ngọc Đức), múi giờ +7. */
public class LunarCalendar {
    private static final String[] CAN = {"Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"};
    private static final String[] CHI = {"Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"};

    private static int INT(double d) { return (int) Math.floor(d); }

    private static int jdFromDate(int dd, int mm, int yy) {
        int a = (14 - mm) / 12;
        int y = yy + 4800 - a;
        int m = mm + 12 * a - 3;
        int jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
        if (jd < 2299161) jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083;
        return jd;
    }

    private static double newMoon(int k) {
        double T = k / 1236.85, T2 = T * T, T3 = T2 * T, dr = Math.PI / 180;
        double Jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
        Jd1 = Jd1 + 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
        double M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
        double Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
        double F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
        double C1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr) + 0.0021 * Math.sin(2 * dr * M);
        C1 = C1 - 0.4068 * Math.sin(Mpr * dr) + 0.0161 * Math.sin(dr * 2 * Mpr);
        C1 = C1 - 0.0004 * Math.sin(dr * 3 * Mpr);
        C1 = C1 + 0.0104 * Math.sin(dr * 2 * F) - 0.0051 * Math.sin(dr * (M + Mpr));
        C1 = C1 - 0.0074 * Math.sin(dr * (M - Mpr)) + 0.0004 * Math.sin(dr * (2 * F + M));
        C1 = C1 - 0.0004 * Math.sin(dr * (2 * F - M)) - 0.0006 * Math.sin(dr * (2 * F + Mpr));
        C1 = C1 + 0.0010 * Math.sin(dr * (2 * F - Mpr)) + 0.0005 * Math.sin(dr * (2 * Mpr + M));
        double deltat;
        if (T < -11) deltat = 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3;
        else deltat = -0.000278 + 0.000265 * T + 0.000262 * T2;
        return Jd1 + C1 - deltat;
    }

    private static double sunLongitude(double jdn) {
        double T = (jdn - 2451545.0) / 36525, T2 = T * T, dr = Math.PI / 180;
        double M = 357.52910 + 35999.05030 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
        double L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
        double DL = (1.914600 - 0.004817 * T - 0.000014 * T2) * Math.sin(dr * M);
        DL = DL + (0.019993 - 0.000101 * T) * Math.sin(dr * 2 * M) + 0.000290 * Math.sin(dr * 3 * M);
        double L = (L0 + DL) * dr;
        L = L - Math.PI * 2 * INT(L / (Math.PI * 2));
        return L;
    }

    private static int getSunLongitude(int dayNumber, double tz) {
        return INT(sunLongitude(dayNumber - 0.5 - tz / 24) / Math.PI * 6);
    }

    private static int getNewMoonDay(int k, double tz) {
        return INT(newMoon(k) + 0.5 + tz / 24);
    }

    private static int getLunarMonth11(int yy, double tz) {
        double off = jdFromDate(31, 12, yy) - 2415021.076998695;
        int k = INT(off / 29.530588853);
        int nm = getNewMoonDay(k, tz);
        if (getSunLongitude(nm, tz) >= 9) nm = getNewMoonDay(k - 1, tz);
        return nm;
    }

    private static int getLeapMonthOffset(int a11, double tz) {
        int k = INT((a11 - 2415021.076998695) / 29.530588853 + 0.5);
        int last, i = 1;
        int arc = getSunLongitude(getNewMoonDay(k + i, tz), tz);
        do {
            last = arc;
            i++;
            arc = getSunLongitude(getNewMoonDay(k + i, tz), tz);
        } while (arc != last && i < 14);
        return i - 1;
    }

    /** Trả về {ngày âm, tháng âm, năm âm, nhuận(0/1)}. */
    public static int[] solarToLunar(int dd, int mm, int yy) {
        double tz = 7;
        int dayNumber = jdFromDate(dd, mm, yy);
        int k = INT((dayNumber - 2415021.076998695) / 29.530588853);
        int monthStart = getNewMoonDay(k + 1, tz);
        if (monthStart > dayNumber) monthStart = getNewMoonDay(k, tz);
        int a11 = getLunarMonth11(yy, tz);
        int b11 = a11;
        int lunarYear;
        if (a11 >= monthStart) {
            lunarYear = yy;
            a11 = getLunarMonth11(yy - 1, tz);
        } else {
            lunarYear = yy + 1;
            b11 = getLunarMonth11(yy + 1, tz);
        }
        int lunarDay = dayNumber - monthStart + 1;
        int diff = INT((monthStart - a11) / 29.0);
        int leap = 0;
        int lunarMonth = diff + 11;
        if (b11 - a11 > 365) {
            int leapMonthDiff = getLeapMonthOffset(a11, tz);
            if (diff >= leapMonthDiff) {
                lunarMonth = diff + 10;
                if (diff == leapMonthDiff) leap = 1;
            }
        }
        if (lunarMonth > 12) lunarMonth -= 12;
        if (lunarMonth >= 11 && diff < 4) lunarYear -= 1;
        return new int[]{lunarDay, lunarMonth, lunarYear, leap};
    }

    public static String canChi(int lunarYear) {
        return CAN[(lunarYear + 6) % 10] + " " + CHI[(lunarYear + 8) % 12];
    }

    /** Ngày lễ (dương lịch d/m hoặc âm lịch). Trả null nếu không có. */
    public static String holiday(int d, int m, int[] l) {
        if (d == 1 && m == 1) return "Tết Dương lịch";
        if (d == 14 && m == 2) return "Valentine";
        if (d == 8 && m == 3) return "Quốc tế Phụ nữ";
        if (d == 30 && m == 4) return "Giải phóng miền Nam";
        if (d == 1 && m == 5) return "Quốc tế Lao động";
        if (d == 2 && m == 9) return "Quốc khánh";
        if (d == 20 && m == 10) return "Phụ nữ Việt Nam";
        if (d == 20 && m == 11) return "Nhà giáo Việt Nam";
        if (d == 24 && m == 12) return "Giáng sinh";
        if (l[3] == 0) {
            if (l[0] == 1 && l[1] == 1) return "Mùng 1 Tết Nguyên Đán";
            if (l[0] == 2 && l[1] == 1) return "Mùng 2 Tết";
            if (l[0] == 3 && l[1] == 1) return "Mùng 3 Tết";
            if (l[0] == 15 && l[1] == 1) return "Rằm tháng Giêng";
            if (l[0] == 10 && l[1] == 3) return "Giỗ Tổ Hùng Vương";
            if (l[0] == 15 && l[1] == 4) return "Phật Đản";
            if (l[0] == 5 && l[1] == 5) return "Tết Đoan Ngọ";
            if (l[0] == 15 && l[1] == 7) return "Vu Lan";
            if (l[0] == 15 && l[1] == 8) return "Tết Trung Thu";
            if (l[0] == 23 && l[1] == 12) return "Ông Táo chầu trời";
        }
        return null;
    }

    private static final String[] ANIMAL = {"Chuột", "Trâu", "Hổ", "Mèo", "Rồng", "Rắn", "Ngựa", "Dê", "Khỉ", "Gà", "Chó", "Heo"};
    private static final String[] ANIMAL_EMOJI = {"\uD83D\uDC2D", "\uD83D\uDC2E", "\uD83D\uDC2F", "\uD83D\uDC31", "\uD83D\uDC32", "\uD83D\uDC0D",
            "\uD83D\uDC34", "\uD83D\uDC10", "\uD83D\uDC35", "\uD83D\uDC14", "\uD83D\uDC36", "\uD83D\uDC37"};
    private static final String[] ZODIAC = {"Ma Kết", "Bảo Bình", "Song Ngư", "Bạch Dương", "Kim Ngưu", "Song Tử",
            "Cự Giải", "Sư Tử", "Xử Nữ", "Thiên Bình", "Bọ Cạp", "Nhân Mã"};
    private static final String[] ZODIAC_SYMBOL = {"\u2651", "\u2652", "\u2653", "\u2648", "\u2649", "\u264A",
            "\u264B", "\u264C", "\u264D", "\u264E", "\u264F", "\u2650"};
    // ngày bắt đầu của cung kế tiếp theo tháng dương (1..12)
    private static final int[] ZODIAC_CUT = {20, 19, 21, 20, 21, 21, 23, 23, 23, 23, 22, 22};

    /** Con giáp của năm âm lịch, ví dụ "Ngựa". */
    public static String animal(int lunarYear) { return ANIMAL[(lunarYear + 8) % 12]; }

    public static String animalEmoji(int lunarYear) { return ANIMAL_EMOJI[(lunarYear + 8) % 12]; }

    private static int zodiacIndex(int d, int m) {
        // từ ngày ZODIAC_CUT[m-1] của tháng m chuyển sang cung kế tiếp (chỉ số m % 12)
        return d >= ZODIAC_CUT[m - 1] ? m % 12 : m - 1;
    }

    /** Cung hoàng đạo theo dương lịch, ví dụ "Bọ Cạp". */
    public static String zodiac(int d, int m) { return ZODIAC[zodiacIndex(d, m)]; }

    public static String zodiacSymbol(int d, int m) { return ZODIAC_SYMBOL[zodiacIndex(d, m)] + "\uFE0F"; }
}
