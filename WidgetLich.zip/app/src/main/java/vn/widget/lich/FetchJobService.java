package vn.widget.lich;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.PersistableBundle;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

/** Tải thời tiết và giá ở nền (không bị giới hạn 10 giây của broadcast). */
public class FetchJobService extends JobService {
    static final int JOB_MANUAL = 101, JOB_AUTO = 102;

    static void schedule(Context c, boolean manual) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        PersistableBundle b = new PersistableBundle();
        b.putInt("manual", manual ? 1 : 0);
        JobInfo.Builder jb = new JobInfo.Builder(manual ? JOB_MANUAL : JOB_AUTO, new ComponentName(c, FetchJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setExtras(b)
                .setOverrideDeadline(manual ? 20_000 : 300_000);
        try { js.schedule(jb.build()); } catch (Exception ignored) { }
    }

    static void scheduleIfStale(Context c) {
        if (WeatherClient.isStale(c) || PriceClient.isStale(c)) schedule(c, false);
    }

    static void toast(final Context c, final String msg) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() { Toast.makeText(c.getApplicationContext(), msg, Toast.LENGTH_SHORT).show(); }
        });
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        final boolean manual = params.getExtras().getInt("manual", 0) == 1;
        final Context c = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean w = false, p = true;
                try {
                    if (manual) {
                        w = WeatherClient.fetch(c);
                        if (PriceClient.anyEnabled(c)) p = PriceClient.fetch(c);
                    } else {
                        WeatherClient.refreshIfStale(c);
                        PriceClient.refreshIfStale(c);
                    }
                } catch (Throwable ignored) {
                }
                Prefs.setRefreshStart(c, 0);
                try { WidgetProvider.updateAll(c); } catch (Throwable ignored) { }
                if (manual) {
                    Calendar t = Calendar.getInstance();
                    if (w || p && PriceClient.anyEnabled(c)) {
                        toast(c, String.format(Locale.US, "Đã cập nhật lúc %02d:%02d%s", t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE),
                                (w && (p || !PriceClient.anyEnabled(c))) ? "" : " (một số mục lỗi)"));
                    } else {
                        toast(c, "Không cập nhật được, kiểm tra mạng");
                    }
                }
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return false; }
}
