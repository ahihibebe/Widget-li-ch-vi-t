package vn.widget.lich;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/** Lấy thời tiết từ Open-Meteo (miễn phí, không cần key). */
public class WeatherClient {
    static final long MAX_AGE = 30 * 60 * 1000L;
    static final long RETRY_GAP = 10 * 60 * 1000L;

    static class Data {
        boolean ok;
        double temp, tmin, tmax;
        int code;
        long time;
        int days;
        String[] dates = new String[7];
        int[] codes = new int[7];
        double[] mins = new double[7];
        double[] maxs = new double[7];
    }

    static String describe(int c) {
        if (c == 0) return "Trời quang";
        if (c == 1) return "Ít mây";
        if (c == 2) return "Có mây";
        if (c == 3) return "Nhiều mây";
        if (c == 45 || c == 48) return "Sương mù";
        if (c >= 51 && c <= 57) return "Mưa phùn";
        if (c >= 61 && c <= 65) return "Mưa";
        if (c == 66 || c == 67) return "Mưa lạnh";
        if (c >= 71 && c <= 77) return "Tuyết";
        if (c >= 80 && c <= 82) return "Mưa rào";
        if (c == 85 || c == 86) return "Tuyết rơi";
        if (c >= 95) return "Dông";
        return "Nhiều mây";
    }

    static Data load(Context c) {
        Data d = new Data();
        String s = Prefs.sp(c).getString("wjson", null);
        if (s == null) return d;
        try {
            JSONObject o = new JSONObject(s);
            JSONObject cur = o.getJSONObject("current");
            d.temp = cur.getDouble("temperature_2m");
            d.code = cur.getInt("weather_code");
            JSONObject day = o.getJSONObject("daily");
            JSONArray t = day.getJSONArray("time");
            JSONArray wc = day.getJSONArray("weather_code");
            JSONArray mx = day.getJSONArray("temperature_2m_max");
            JSONArray mn = day.getJSONArray("temperature_2m_min");
            d.days = Math.min(7, t.length());
            for (int i = 0; i < d.days; i++) {
                d.dates[i] = t.getString(i);
                d.codes[i] = wc.getInt(i);
                d.maxs[i] = mx.getDouble(i);
                d.mins[i] = mn.getDouble(i);
            }
            d.tmax = d.maxs[0];
            d.tmin = d.mins[0];
            d.time = Prefs.sp(c).getLong("wtime", 0);
            d.ok = true;
        } catch (Exception e) {
            d.ok = false;
        }
        return d;
    }

    /** Gọi trong luồng nền. Trả true nếu cập nhật thành công. */
    static boolean fetch(Context c) {
        long now = System.currentTimeMillis();
        Prefs.sp(c).edit().putLong("wtry", now).apply();
        HttpURLConnection con = null;
        try {
            String u = String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                            + "&current=temperature_2m,weather_code"
                            + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                            + "&timezone=auto&forecast_days=5",
                    Prefs.lat(c), Prefs.lon(c));
            con = (HttpURLConnection) new URL(u).openConnection();
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            new JSONObject(sb.toString()).getJSONObject("current"); // kiểm tra hợp lệ
            Prefs.sp(c).edit().putString("wjson", sb.toString()).putLong("wtime", now).apply();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            if (con != null) con.disconnect();
        }
    }

    static boolean isStale(Context c) {
        long now = System.currentTimeMillis();
        long last = Prefs.sp(c).getLong("wtime", 0);
        long tried = Prefs.sp(c).getLong("wtry", 0);
        return last == 0 ? now - tried > 60_000 : (now - last > MAX_AGE && now - tried > RETRY_GAP);
    }

    /** Đổi vị trí xong thì wtime = 0 nên tải lại ngay (nhưng không quá 1 lần/phút). */
    static void refreshIfStale(Context c) {
        long now = System.currentTimeMillis();
        long last = Prefs.sp(c).getLong("wtime", 0);
        long tried = Prefs.sp(c).getLong("wtry", 0);
        if (last == 0) {
            if (now - tried > 60_000) fetch(c);
            return;
        }
        if (now - last > MAX_AGE && now - tried > RETRY_GAP) fetch(c);
    }
}
