package vn.widget.lich;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Danh sách tỉnh/phường/xã (provinces.open-api.vn v2) và đổi tên địa phương thành tọa độ (OpenStreetMap Nominatim). */
public class GeoClient {
    static class Item {
        int code;
        String name;
        Item(int code, String name) { this.code = code; this.name = name; }
        @Override public String toString() { return name; }
    }

    static String http(String url, int timeoutMs) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setConnectTimeout(timeoutMs);
            con.setReadTimeout(timeoutMs);
            con.setRequestProperty("User-Agent", "WidgetLich/1.0 (Android)");
            con.setRequestProperty("Accept-Language", "vi");
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) > 0) {
                sb.append(buf, 0, n);
                if (sb.length() > 4_000_000) break;
            }
            r.close();
            return sb.toString();
        } finally {
            con.disconnect();
        }
    }

    // ---------- danh sách hành chính (có cache) ----------
    static List<Item> provinces(Context c) {
        String key = "geo_provinces";
        String s = Prefs.sp(c).getString(key, null);
        try {
            if (s == null) {
                s = http("https://provinces.open-api.vn/api/v2/p/", 10000);
                new JSONArray(s);
                Prefs.sp(c).edit().putString(key, s).apply();
            }
            JSONArray a = new JSONArray(s);
            List<Item> out = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.getInt("code"), o.getString("name")));
            }
            return out;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    static List<Item> wards(Context c, int provinceCode) {
        String key = "geo_wards_" + provinceCode;
        String s = Prefs.sp(c).getString(key, null);
        try {
            if (s == null) {
                s = http("https://provinces.open-api.vn/api/v2/p/" + provinceCode + "?depth=2", 15000);
                new JSONObject(s).getJSONArray("wards");
                Prefs.sp(c).edit().putString(key, s).apply();
            }
            JSONArray a = new JSONObject(s).getJSONArray("wards");
            List<Item> out = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.getInt("code"), o.getString("name")));
            }
            return out;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    // ---------- tọa độ ----------
    private static String stripPrefix(String s) {
        String[] pre = {"Thành phố ", "Tỉnh ", "Phường ", "Xã ", "Thị trấn ", "Đặc khu "};
        for (String p : pre) if (s.startsWith(p)) return s.substring(p.length());
        return s;
    }

    private static double[] nominatim(String q, String mustContain) {
        try {
            String u = "https://nominatim.openstreetmap.org/search?format=json&limit=3&accept-language=vi&countrycodes=vn&q="
                    + URLEncoder.encode(q, "UTF-8");
            JSONArray a = new JSONArray(http(u, 10000));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String dn = o.optString("display_name", "");
                if (mustContain == null || dn.toLowerCase(Locale.ROOT).contains(mustContain.toLowerCase(Locale.ROOT)))
                    return new double[]{o.getDouble("lat"), o.getDouble("lon")};
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Trả {lat, lon, level}: level 2 = tìm được tới phường/xã, 1 = chỉ tới tỉnh; null nếu thất bại. */
    static double[] geocode(String ward, String province) {
        String prov = stripPrefix(province);
        String w = stripPrefix(ward);
        double[] r = nominatim(ward + ", " + province + ", Việt Nam", prov);
        if (r == null) r = nominatim(w + ", " + prov + ", Việt Nam", prov);
        if (r != null) return new double[]{r[0], r[1], 2};
        r = nominatim(province + ", Việt Nam", null);
        if (r != null) return new double[]{r[0], r[1], 1};
        return null;
    }

    /** Tên phường/xã từ tọa độ GPS (chỉ để hiển thị). */
    static String reverse(double lat, double lon) {
        try {
            String u = String.format(Locale.US,
                    "https://nominatim.openstreetmap.org/reverse?format=json&zoom=16&accept-language=vi&lat=%.5f&lon=%.5f", lat, lon);
            JSONObject o = new JSONObject(http(u, 8000));
            JSONObject ad = o.optJSONObject("address");
            if (ad != null) {
                String ward = firstNonEmpty(ad.optString("suburb"), ad.optString("quarter"), ad.optString("village"),
                        ad.optString("town"), ad.optString("neighbourhood"));
                String prov = firstNonEmpty(ad.optString("state"), ad.optString("city"));
                if (ward.length() > 0 && prov.length() > 0) return ward + ", " + prov;
                if (prov.length() > 0) return prov;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static String firstNonEmpty(String... a) {
        for (String s : a) if (s != null && s.length() > 0) return s;
        return "";
    }
}
