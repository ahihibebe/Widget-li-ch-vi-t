package vn.widget.lich;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

public class WidgetProvider extends AppWidgetProvider {
    static final String ACTION_TICK = "vn.widget.lich.TICK";

    @Override
    public void onReceive(final Context context, Intent intent) {
        super.onReceive(context, intent);
        String a = intent.getAction();
        if (a == null) return;
        if (ACTION_TICK.equals(a)
                || AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(a)
                || Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a)
                || Intent.ACTION_DATE_CHANGED.equals(a)) {
            final PendingResult pr = goAsync();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        WeatherClient.refreshIfStale(context);
                        updateAll(context);
                        scheduleNext(context);
                    } catch (Throwable ignored) {
                    } finally {
                        pr.finish();
                    }
                }
            }).start();
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        updateAll(context);
        scheduleNext(context);
    }

    @Override
    public void onEnabled(Context context) {
        scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        cancel(context);
    }

    static int[] ids(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, WidgetProvider.class));
    }

    static void updateAll(Context c) {
        int[] ids = ids(c);
        if (ids.length == 0) return;
        Bitmap bmp = WidgetRenderer.render(c);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
        rv.setImageViewBitmap(R.id.img, bmp);
        PendingIntent pi = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        rv.setOnClickPendingIntent(R.id.img, pi);
        AppWidgetManager.getInstance(c).updateAppWidget(ids, rv);
    }

    private static PendingIntent tickIntent(Context c) {
        Intent i = new Intent(c, WidgetProvider.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Hẹn cập nhật vào đầu phút kế tiếp (không đánh thức máy khi đang ngủ). */
    static void scheduleNext(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        if (ids(c).length == 0) {
            am.cancel(tickIntent(c));
            return;
        }
        long now = System.currentTimeMillis();
        long next = now - now % 60000 + 60000 + 300;
        am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(c));
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(tickIntent(c));
    }
}
