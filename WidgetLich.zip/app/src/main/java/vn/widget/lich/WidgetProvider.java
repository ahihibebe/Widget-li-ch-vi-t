package vn.widget.lich;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;

public class WidgetProvider extends AppWidgetProvider {
    static final String ACTION_TICK = "vn.widget.lich.TICK";
    static final String ACTION_REFRESH = "vn.widget.lich.REFRESH";
    static final String ACTION_TAB = "vn.widget.lich.TAB";

    @Override
    public void onReceive(final Context context, Intent intent) {
        super.onReceive(context, intent);
        final String a = intent.getAction();
        if (a == null) return;
        if (ACTION_TAB.equals(a)) {
            int t = intent.getIntExtra("tab", 0);
            int curTab = PriceClient.currentTab(context, PriceClient.enabledTabs(context));
            if (t == curTab) { if (t == 1) Prefs.setGoldPage(context, Prefs.goldPage(context) + 1); }
            else Prefs.setGoldPage(context, 0);
            Prefs.setPriceTab(context, t);
            updateAll(context);
            return;
        }
        if (ACTION_REFRESH.equals(a)) {
            Prefs.setRefreshStart(context, System.currentTimeMillis());
            FetchJobService.toast(context, "Đang cập nhật...");
            updateAll(context);
            FetchJobService.schedule(context, true);
            return;
        }
        if (ACTION_TICK.equals(a)
                || Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a)
                || Intent.ACTION_DATE_CHANGED.equals(a)) {
            updateAll(context);
            scheduleNext(context);
            FetchJobService.scheduleIfStale(context);
        }
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        updateAll(context);
        scheduleNext(context);
        FetchJobService.scheduleIfStale(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager mgr, int id, Bundle newOptions) {
        updateAll(context);
    }

    @Override
    public void onEnabled(Context context) {
        scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        scheduleNext(context); // tự huỷ báo thức nếu không còn widget nào
    }

    // ---------- cập nhật ----------
    static int[] mainIds(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, WidgetProvider.class));
    }

    static int[] priceIds(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, PriceWidgetProvider.class));
    }

    static int count(Context c) { return mainIds(c).length + priceIds(c).length; }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : mainIds(c)) {
            int[] sz = pixelSize(c, m, id);
            m.updateAppWidget(id, views(c, WidgetRenderer.render(c, sz[0], sz[1])));
        }
        for (int id : priceIds(c)) {
            int[] sz = pixelSize(c, m, id);
            m.updateAppWidget(id, viewsPrice(c, WidgetRenderer.renderPrices(c, sz[0], sz[1])));
        }
    }

    /** Kích thước thật của widget (pixel) để vẽ đúng tỉ lệ; giới hạn để không quá nặng. */
    static int[] pixelSize(Context c, AppWidgetManager m, int id) {
        Bundle o = m.getAppWidgetOptions(id);
        boolean land = c.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        int wdp = land ? o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0) : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hdp = land ? o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0) : o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wdp <= 0 || hdp <= 0) { wdp = 250; hdp = 167; }
        float d = c.getResources().getDisplayMetrics().density;
        float w = wdp * d, h = hdp * d;
        float k = Math.min(1f, 1000f / Math.max(w, h));
        return new int[]{Math.max(160, Math.round(w * k)), Math.max(100, Math.round(h * k))};
    }

    /** RemoteViews: cả widget mở app, góc phải-trên là nút làm mới. */
    static RemoteViews views(Context c, Bitmap bmp) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
        rv.setImageViewBitmap(R.id.img, bmp);
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), flags));
        Intent r = new Intent(c, WidgetProvider.class).setAction(ACTION_REFRESH);
        rv.setOnClickPendingIntent(R.id.refresh, PendingIntent.getBroadcast(c, 2, r, flags));
        return rv;
    }

    /** Widget giá: góc phải-trên làm mới, thanh tab dưới cùng chuyển tab (chỉ hiện các tab đang bật). */
    static RemoteViews viewsPrice(Context c, Bitmap bmp) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_price);
        rv.setImageViewBitmap(R.id.img, bmp);
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), flags));
        Intent r = new Intent(c, WidgetProvider.class).setAction(ACTION_REFRESH);
        rv.setOnClickPendingIntent(R.id.refresh, PendingIntent.getBroadcast(c, 2, r, flags));
        java.util.List<Integer> tabs = PriceClient.enabledTabs(c);
        int[] zones = {R.id.tab0, R.id.tab1, R.id.tab2};
        for (int j = 0; j < 3; j++) {
            if (j < tabs.size()) {
                rv.setViewVisibility(zones[j], android.view.View.VISIBLE);
                Intent t = new Intent(c, WidgetProvider.class).setAction(ACTION_TAB)
                        .setData(android.net.Uri.parse("widgetlich://tab/" + tabs.get(j)))
                        .putExtra("tab", tabs.get(j));
                rv.setOnClickPendingIntent(zones[j], PendingIntent.getBroadcast(c, 20 + j, t, flags));
            } else {
                rv.setViewVisibility(zones[j], android.view.View.GONE);
            }
        }
        return rv;
    }

    // ---------- báo thức mỗi phút ----------
    private static PendingIntent tickIntent(Context c) {
        Intent i = new Intent(c, WidgetProvider.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Hẹn cập nhật vào đầu phút kế tiếp (không đánh thức máy khi đang ngủ). */
    static void scheduleNext(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        if (count(c) == 0) {
            am.cancel(tickIntent(c));
            return;
        }
        long now = System.currentTimeMillis();
        long next = now - now % 60000 + 60000 + 300;
        am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(c));
    }
}
