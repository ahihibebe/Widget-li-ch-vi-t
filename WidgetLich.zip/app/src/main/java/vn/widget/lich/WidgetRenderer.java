package vn.widget.lich;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;

import java.util.Calendar;
import java.util.Locale;

/** Vẽ toàn bộ widget thành một Bitmap (dùng cho cả widget lẫn xem trước trong app). */
public class WidgetRenderer {
    static final int W = 840, H = 560;
    static final String[] DOW_LONG = {"Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"};
    static final String[] DOW_SHORT = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static void text(Canvas cv, String s, float x, float y, float size, int color, boolean bold, Paint.Align a) {
        P.setStyle(Paint.Style.FILL);
        P.setShader(null);
        P.setTextSize(size);
        P.setColor(color);
        P.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        P.setTextAlign(a);
        cv.drawText(s, x, y, P);
    }

    private static float fitSize(String s, float targetW, float maxSize) {
        P.setTypeface(Typeface.DEFAULT_BOLD);
        P.setTextSize(100);
        float w = P.measureText(s);
        return Math.min(maxSize, 100f * targetW / w);
    }

    private static void rrect(Canvas cv, float l, float t, float r, float b, float rad, int fill, int stroke, float sw) {
        RectF rc = new RectF(l, t, r, b);
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(fill);
        cv.drawRoundRect(rc, rad, rad, P);
        if (sw > 0) {
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(sw);
            P.setColor(stroke);
            cv.drawRoundRect(rc, rad, rad, P);
            P.setStyle(Paint.Style.FILL);
        }
    }

    private static void circle(Canvas cv, float x, float y, float r, int color) {
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(color);
        cv.drawCircle(x, y, r, P);
    }

    static Bitmap render(Context c) {
        Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);

        int theme = Prefs.theme(c);
        int style = Prefs.style(c);
        boolean h24 = Prefs.is24h(c);
        boolean lunarOn = Prefs.showLunar(c);

        int text, sub, tile, tileStroke, today, todayStroke, track;
        if (theme == 0) {
            text = 0xFF111827; sub = 0xFF6B7280; tile = 0xFFF1F5F9; tileStroke = 0xFFE2E8F0;
            today = 0xFFDBE7FF; todayStroke = 0xFF93B4FF; track = 0x22000000;
            rrect(cv, 6, 6, W - 6, H - 6, 64, 0xF7FFFFFF, 0xFFE5E7EB, 3);
        } else if (theme == 1) {
            text = 0xFFF9FAFB; sub = 0xFF9CA3AF; tile = 0xFF1F2937; tileStroke = 0xFF374151;
            today = 0xFF374151; todayStroke = 0xFF6B7280; track = 0x33FFFFFF;
            rrect(cv, 6, 6, W - 6, H - 6, 64, 0xF2111827, 0xFF1F2937, 3);
        } else {
            text = 0xFFFFFFFF; sub = 0xCCFFFFFF; tile = 0x33FFFFFF; tileStroke = 0x55FFFFFF;
            today = 0x40FFFFFF; todayStroke = 0x99FFFFFF; track = 0x33FFFFFF;
            rrect(cv, 6, 6, W - 6, H - 6, 64, 0x701E2440, 0x00000000, 0);
            P.setStyle(Paint.Style.FILL);
            P.setShader(new LinearGradient(0, 0, W, H, 0x45FFFFFF, 0x08FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRoundRect(new RectF(6, 6, W - 6, H - 6), 64, 64, P);
            P.setShader(null);
            rrect(cv, 6, 6, W - 6, H - 6, 64, 0, 0x80FFFFFF, 3.5f);
        }

        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY), min = now.get(Calendar.MINUTE);
        String time = h24 ? String.format(Locale.US, "%02d:%02d", hour, min)
                : String.format(Locale.US, "%d:%02d", hour % 12 == 0 ? 12 : hour % 12, min);
        float ts = fitSize(time, h24 ? 400 : 330, 210);
        text(cv, time, 46, 250, ts, text, true, Paint.Align.LEFT);
        if (!h24) {
            P.setTypeface(Typeface.DEFAULT_BOLD);
            P.setTextSize(ts);
            float tw = P.measureText(time);
            text(cv, hour < 12 ? "SA" : "CH", 46 + tw + 8, 250, 34, sub, true, Paint.Align.LEFT);
        }

        int d = now.get(Calendar.DAY_OF_MONTH), m = now.get(Calendar.MONTH) + 1, y = now.get(Calendar.YEAR);
        text(cv, DOW_LONG[now.get(Calendar.DAY_OF_WEEK) - 1] + ", " + d + " tháng " + m, 50, 322, 40, text, true, Paint.Align.LEFT);
        if (lunarOn) {
            int[] l = LunarCalendar.solarToLunar(d, m, y);
            text(cv, "Âm lịch: " + l[0] + " tháng " + l[1] + (l[3] == 1 ? " (nhuận)" : ""), 50, 368, 34, sub, false, Paint.Align.LEFT);
        }

        drawWeek(cv, now, lunarOn, text, sub, today, todayStroke);

        if (style == 0) drawStats(c, cv, text, sub, tile, tileStroke, track);
        else drawWeather(c, cv, text, sub, tile, tileStroke, track);
        return bmp;
    }

    private static void drawWeek(Canvas cv, Calendar now, boolean lunarOn, int text, int sub, int today, int todayStroke) {
        Calendar w = (Calendar) now.clone();
        int back = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7; // 0 = Thứ Hai
        w.add(Calendar.DAY_OF_YEAR, -back);
        float cw = (W - 60) / 7f;
        for (int i = 0; i < 7; i++) {
            float x = 30 + i * cw, cx = x + cw / 2;
            if (i == back) rrect(cv, x + 3, 404, x + cw - 3, 536, 38, today, todayStroke, 3);
            int dd = w.get(Calendar.DAY_OF_MONTH), mm = w.get(Calendar.MONTH) + 1, yy = w.get(Calendar.YEAR);
            text(cv, DOW_SHORT[i], cx, 446, 28, i == back ? text : sub, false, Paint.Align.CENTER);
            text(cv, String.valueOf(dd), cx, 494, 48, text, true, Paint.Align.CENTER);
            if (lunarOn) {
                int[] l = LunarCalendar.solarToLunar(dd, mm, yy);
                text(cv, l[0] == 1 ? l[0] + "/" + l[1] : String.valueOf(l[0]), cx, 526, 24, sub, false, Paint.Align.CENTER);
            }
            w.add(Calendar.DAY_OF_YEAR, 1);
        }
    }

    // ---------- Kiểu mới: thông số hệ thống ----------
    private static void drawStats(Context c, Canvas cv, int text, int sub, int tile, int tileStroke, int track) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int pct = 0, status = -1;
        float temp = 0;
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            pct = scale > 0 ? level * 100 / scale : 0;
            temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        }
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;

        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double gb = 1024.0 * 1024 * 1024;
        double ramTotal = mi.totalMem / gb, ramUsed = (mi.totalMem - mi.availMem) / gb;
        int ramPct = mi.totalMem > 0 ? (int) Math.round(ramUsed * 100 / ramTotal) : 0;

        int diskPct = 0;
        long freeG = 0;
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            long tot = sf.getTotalBytes(), free = sf.getAvailableBytes();
            diskPct = tot > 0 ? (int) ((tot - free) * 100 / tot) : 0;
            freeG = Math.round(free / gb);
        } catch (Exception ignored) { }

        // tiêu đề: chấm xanh + tên máy + nút làm mới
        circle(cv, 474, 62, 8, 0xFF22C55E);
        String model = Build.MODEL == null ? "Android" : Build.MODEL;
        text(cv, model, 494, 72, 26, sub, true, Paint.Align.LEFT);
        drawRefresh(cv, W - 60, 60, 24, tile, tileStroke, text);

        String tStat = temp < 36 ? "Mát" : (temp < 42 ? "Ấm" : "Nóng");
        float tw = 168, th = 130, x0 = 462, y0 = 100, gap = 14;
        int tp = (int) Math.max(0, Math.min(100, (temp - 20) * 100 / 30));
        drawTile(cv, x0, y0, tw, th, "PIN", pct + "%", charging ? "Sạc" : "", pct, pct < 20 ? 0xFFEF4444 : 0xFF22C55E, text, sub, tile, tileStroke, track);
        drawTile(cv, x0 + tw + gap, y0, tw, th, "NHIỆT ĐỘ", String.format(Locale.US, "%.1f°", temp), tStat, tp, 0xFFF59E0B, text, sub, tile, tileStroke, track);
        drawTile(cv, x0, y0 + th + gap, tw, th, "RAM", ramPct + "%", String.format(Locale.US, "%.1f/%dG", ramUsed, Math.round(ramTotal)), ramPct, 0xFF8B5CF6, text, sub, tile, tileStroke, track);
        drawTile(cv, x0 + tw + gap, y0 + th + gap, tw, th, "Ổ CỨNG", diskPct + "%", freeG + "G", diskPct, 0xFF14B8A6, text, sub, tile, tileStroke, track);
    }

    private static void drawTile(Canvas cv, float x, float y, float w, float h, String label, String value, String note,
                                 int pct, int color, int text, int sub, int tile, int tileStroke, int track) {
        rrect(cv, x, y, x + w, y + h, 30, tile, tileStroke, 2.5f);
        rrect(cv, x + 16, y + 16, x + 38, y + 38, 7, color, 0, 0);
        text(cv, label, x + 48, y + 36, 22, sub, true, Paint.Align.LEFT);
        text(cv, value, x + 16, y + 88, 40, text, true, Paint.Align.LEFT);
        if (note.length() > 0) text(cv, note, x + w - 14, y + 88, 19, sub, false, Paint.Align.RIGHT);
        float bl = x + 16, br = x + w - 16, by = y + h - 24;
        rrect(cv, bl, by, br, by + 9, 5, track, 0, 0);
        float fw = (br - bl) * Math.max(0, Math.min(100, pct)) / 100f;
        if (fw > 9) rrect(cv, bl, by, bl + fw, by + 9, 5, color, 0, 0);
    }

    private static void drawRefresh(Canvas cv, float cx, float cy, float r, int fill, int stroke, int color) {
        circle(cv, cx, cy, r, fill);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(3);
        P.setColor(stroke);
        cv.drawCircle(cx, cy, r, P);
        P.setColor(color);
        P.setStrokeWidth(3.5f);
        P.setStrokeCap(Paint.Cap.ROUND);
        cv.drawArc(new RectF(cx - 10, cy - 10, cx + 10, cy + 10), -50, 270, false, P);
        P.setStyle(Paint.Style.FILL);
        Path tri = new Path();
        tri.moveTo(cx + 9, cy - 14);
        tri.lineTo(cx + 15, cy - 3);
        tri.lineTo(cx + 3, cy - 5);
        tri.close();
        cv.drawPath(tri, P);
        P.setStrokeCap(Paint.Cap.BUTT);
    }

    // ---------- Kiểu cổ điển: thời tiết ----------
    private static void drawWeather(Context c, Canvas cv, int text, int sub, int tile, int tileStroke, int track) {
        WeatherClient.Data wd = WeatherClient.load(c);

        circle(cv, 523, 82, 47, 0xFF4F46E5);
        drawWeatherIcon(cv, 523, 82, 64, wd.ok ? wd.code : 3);
        drawRefresh(cv, 619, 82, 22, tile, tileStroke, text);

        String temp = wd.ok ? Math.round(wd.temp) + "°" : "--°";
        text(cv, temp, W - 38, 112, 74, text, true, Paint.Align.RIGHT);
        String desc = wd.ok ? WeatherClient.describe(wd.code) + " · " + Math.round(wd.tmin) + "°–" + Math.round(wd.tmax) + "°" : "Chưa có dữ liệu";
        text(cv, desc, W - 38, 160, 27, sub, false, Paint.Align.RIGHT);

        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int pct = 0;
        float temp2 = 0;
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            pct = scale > 0 ? level * 100 / scale : 0;
            temp2 = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
        }
        rrect(cv, 470, 192, 802, 340, 42, tile, tileStroke, 2.5f);
        // pin
        rrect(cv, 496, 214, 512, 240, 4, pct < 20 ? 0xFFEF4444 : 0xFF22C55E, 0, 0);
        text(cv, pct + "%", 528, 241, 32, text, true, Paint.Align.LEFT);
        rrect(cv, 496, 254, 776, 262, 4, track, 0, 0);
        float fw = 280f * pct / 100f;
        if (fw > 8) rrect(cv, 496, 254, 496 + fw, 262, 4, pct < 20 ? 0xFFEF4444 : 0xFF22C55E, 0, 0);
        // nhiệt độ máy
        rrect(cv, 500, 280, 508, 316, 4, 0xFFF97316, 0, 0);
        circle(cv, 504, 318, 10, 0xFFF97316);
        text(cv, String.format(Locale.US, "%.1f°C", temp2), 528, 318, 32, text, true, Paint.Align.LEFT);
    }

    private static void drawCloud(Canvas cv, float cx, float cy, float s, int color) {
        circle(cv, cx - 0.17f * s, cy + 0.03f * s, 0.17f * s, color);
        circle(cv, cx + 0.01f * s, cy - 0.09f * s, 0.23f * s, color);
        circle(cv, cx + 0.2f * s, cy + 0.04f * s, 0.16f * s, color);
        rrect(cv, cx - 0.33f * s, cy + 0.03f * s, cx + 0.36f * s, cy + 0.2f * s, 0.085f * s, color, 0, 0);
    }

    private static void drawWeatherIcon(Canvas cv, float cx, float cy, float s, int code) {
        int cloud = 0xFF22D3EE, sun = 0xFFFBBF24;
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        boolean storm = code >= 95;
        if (code <= 1) {
            circle(cv, cx, cy, 0.22f * s, sun);
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(4);
            P.setStrokeCap(Paint.Cap.ROUND);
            P.setColor(sun);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                cv.drawLine(cx + (float) Math.cos(a) * 0.32f * s, cy + (float) Math.sin(a) * 0.32f * s,
                        cx + (float) Math.cos(a) * 0.42f * s, cy + (float) Math.sin(a) * 0.42f * s, P);
            }
            P.setStyle(Paint.Style.FILL);
            P.setStrokeCap(Paint.Cap.BUTT);
            return;
        }
        if (code == 2) circle(cv, cx + 0.2f * s, cy - 0.2f * s, 0.18f * s, sun);
        drawCloud(cv, cx, cy - (rain || snow || storm ? 0.06f * s : 0), s, cloud);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(4.5f);
        P.setStrokeCap(Paint.Cap.ROUND);
        if (rain) {
            P.setColor(0xFFBAE6FD);
            for (int i = -1; i <= 1; i++)
                cv.drawLine(cx + i * 0.17f * s, cy + 0.2f * s, cx + i * 0.17f * s - 0.05f * s, cy + 0.34f * s, P);
        } else if (snow) {
            P.setColor(0xFFFFFFFF);
            for (int i = -1; i <= 1; i++)
                cv.drawPoint(cx + i * 0.17f * s, cy + 0.27f * s, P);
        } else if (storm) {
            P.setStyle(Paint.Style.FILL);
            P.setColor(sun);
            Path bolt = new Path();
            bolt.moveTo(cx + 0.04f * s, cy + 0.12f * s);
            bolt.lineTo(cx - 0.1f * s, cy + 0.3f * s);
            bolt.lineTo(cx, cy + 0.3f * s);
            bolt.lineTo(cx - 0.05f * s, cy + 0.44f * s);
            bolt.lineTo(cx + 0.12f * s, cy + 0.24f * s);
            bolt.lineTo(cx + 0.02f * s, cy + 0.24f * s);
            bolt.close();
            cv.drawPath(bolt, P);
        }
        P.setStyle(Paint.Style.FILL);
        P.setStrokeCap(Paint.Cap.BUTT);
    }
}
