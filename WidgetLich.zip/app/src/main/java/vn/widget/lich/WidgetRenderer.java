package vn.widget.lich;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Vẽ widget thành Bitmap đúng kích thước thật của widget (và cho cả phần xem trước trong app).
 * Bố cục thiết kế cao 560 đơn vị, rộng thay đổi theo tỉ lệ; mọi cỡ chữ tự co giãn theo.
 */
public class WidgetRenderer {
    static final int DH = 560;
    static final String[] DOW_LONG = {"Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"};
    static final String[] DOW_SHORT = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};

    static final String[] FONT_NAMES = {"Chuẩn", "Mảnh", "Nhẹ", "Đậm", "Siêu đậm", "Gọn", "Serif", "Mono", "Viết tay", "Của bạn"};
    static final String[] TIME_COLOR_NAMES = {"Tự động", "Trắng", "Vàng", "Cam", "Hồng", "Xanh dương", "Xanh lá"};
    static final int[] TIME_COLORS = {0, 0xFFFFFFFF, 0xFFFDE047, 0xFFFB923C, 0xFFF472B6, 0xFF60A5FA, 0xFF4ADE80};

    static final String[] BG_NAMES = {"Không", "Hoàng hôn", "Đại dương", "Rừng", "Đêm", "Anh đào", "Tím"};
    static final int[][] BG_PRESETS = {
            {0, 0}, {0xFFFF9966, 0xFFFF5E62}, {0xFF2193B0, 0xFF6DD5ED}, {0xFF134E5E, 0xFF71B280},
            {0xFF0F2027, 0xFF2C5364}, {0xFFEE9CA7, 0xFFB86B88}, {0xFF614385, 0xFF516395}};
    static final int BG_IMAGE = 100;
    static final int SUNDAY_RED = 0xFFEF4444;

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);

    static class Pal {
        int text, sub, tile, tileStroke, today, todayStroke, track;
    }

    // ---------- tài nguyên: font + ảnh nền ----------
    private static Typeface customFace;
    private static long customStamp = -1;
    private static Bitmap bgBitmap;
    private static long bgStamp = -1;

    static File fontFile(Context c) { return new File(c.getFilesDir(), "custom_font.ttf"); }
    static File bgFile(Context c) { return new File(c.getFilesDir(), "background.jpg"); }

    static Typeface timeFace(Context c) { return faceFor(c, Prefs.font(c)); }

    static synchronized Typeface faceFor(Context c, int font) {
        switch (font) {
            case 0: return Typeface.create("sans-serif-medium", Typeface.NORMAL);
            case 1: return Typeface.create("sans-serif-thin", Typeface.NORMAL);
            case 2: return Typeface.create("sans-serif-light", Typeface.NORMAL);
            case 4: return Typeface.create("sans-serif-black", Typeface.NORMAL);
            case 5: return Typeface.create("sans-serif-condensed", Typeface.BOLD);
            case 6: return Typeface.create("serif", Typeface.BOLD);
            case 7: return Typeface.create("monospace", Typeface.BOLD);
            case 8: return Typeface.create("casual", Typeface.NORMAL);
            case 9: {
                File f = fontFile(c);
                if (f.exists()) {
                    if (customFace == null || customStamp != f.lastModified()) {
                        try {
                            customFace = Typeface.createFromFile(f);
                            customStamp = f.lastModified();
                        } catch (Exception e) {
                            customFace = null;
                        }
                    }
                    if (customFace != null) return customFace;
                }
                return Typeface.create("sans-serif", Typeface.BOLD);
            }
            default: return Typeface.create("sans-serif", Typeface.BOLD);
        }
    }

    static synchronized Bitmap backgroundImage(Context c) {
        File f = bgFile(c);
        if (!f.exists()) return null;
        if (bgBitmap == null || bgStamp != f.lastModified()) {
            try {
                bgBitmap = BitmapFactory.decodeFile(f.getPath());
                bgStamp = f.lastModified();
            } catch (Throwable t) {
                bgBitmap = null;
            }
        }
        return bgBitmap;
    }

    // ---------- tiện ích vẽ ----------
    private static void text(Canvas cv, String s, float x, float y, float size, int color, Typeface tf, Paint.Align a) {
        P.setStyle(Paint.Style.FILL);
        P.setShader(null);
        P.setTextSize(size);
        P.setColor(color);
        P.setTypeface(tf);
        P.setTextAlign(a);
        cv.drawText(s, x, y, P);
    }

    private static void text(Canvas cv, String s, float x, float y, float size, int color, boolean bold, Paint.Align a) {
        text(cv, s, x, y, size, color, bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT, a);
    }

    private static float width(String s, float size, Typeface tf) {
        P.setTypeface(tf);
        P.setTextSize(size);
        return P.measureText(s);
    }

    /** Cỡ chữ lớn nhất không vượt maxSize mà vừa chiều rộng maxW. */
    private static float fit(String s, float maxW, float maxSize, Typeface tf) {
        float w = width(s, 100, tf);
        if (w <= 0) return maxSize;
        return Math.min(maxSize, 100f * maxW / w);
    }

    private static void rrect(Canvas cv, float l, float t, float r, float b, float rad, int fill, int stroke, float sw) {
        RectF rc = new RectF(l, t, r, b);
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(fill);
        cv.drawRoundRect(rc, rad, rad, P);
        if (sw > 0) {
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(sw);
            P.setColor(stroke);
            cv.drawRoundRect(rc, rad, rad, P);
            P.setStyle(Paint.Style.FILL);
        }
    }

    private static void circle(Canvas cv, float x, float y, float r, int color) {
        P.setShader(null);
        P.setStyle(Paint.Style.FILL);
        P.setColor(color);
        cv.drawCircle(x, y, r, P);
    }

    // ---------- khung nền ----------
    private static Pal drawCard(Context c, Canvas cv, float dw) {
        Pal p = new Pal();
        int theme = Prefs.theme(c);
        int bg = Prefs.bg(c);
        RectF card = new RectF(6, 6, dw - 6, DH - 6);
        float rad = 64;
        int tr = Math.max(0, Math.min(95, Prefs.transparency(c)));
        int layerAlpha = 255 * (100 - tr) / 100;
        int layer = layerAlpha < 255 ? cv.saveLayerAlpha(new RectF(0, 0, dw, DH), layerAlpha) : -1;
        Bitmap img = bg == BG_IMAGE ? backgroundImage(c) : null;
        boolean hasBg = (bg >= 1 && bg < BG_PRESETS.length) || img != null;

        if (hasBg) {
            cv.save();
            Path clip = new Path();
            clip.addRoundRect(card, rad, rad, Path.Direction.CW);
            cv.clipPath(clip);
            if (img != null) {
                float sc = Math.max(card.width() / img.getWidth(), card.height() / img.getHeight());
                float sw = card.width() / sc, sh = card.height() / sc;
                int sl = Math.round((img.getWidth() - sw) / 2f), st = Math.round((img.getHeight() - sh) / 2f);
                Rect src = new Rect(sl, st, Math.round(sl + sw), Math.round(st + sh));
                P.setShader(null);
                P.setFilterBitmap(true);
                cv.drawBitmap(img, src, card, P);
            } else {
                int[] g = BG_PRESETS[bg];
                P.setStyle(Paint.Style.FILL);
                P.setShader(new LinearGradient(0, 0, dw, DH, g[0], g[1], Shader.TileMode.CLAMP));
                cv.drawRect(card, P);
                P.setShader(null);
            }
            int dim = Math.max(0, Math.min(90, Prefs.bgDim(c)));
            P.setStyle(Paint.Style.FILL);
            P.setColor(Color.argb(dim * 255 / 100, 0, 0, 0));
            cv.drawRect(card, P);
            cv.restore();
            rrect(cv, 6, 6, dw - 6, DH - 6, rad, 0, 0x80FFFFFF, 3.5f);
            setGlass(p);
        } else if (theme == 0) {
            p.text = 0xFF111827; p.sub = 0xFF6B7280; p.tile = 0xFFF1F5F9; p.tileStroke = 0xFFE2E8F0;
            p.today = 0xFFDBE7FF; p.todayStroke = 0xFF93B4FF; p.track = 0x22000000;
            rrect(cv, 6, 6, dw - 6, DH - 6, rad, 0xF7FFFFFF, 0xFFE5E7EB, 3);
        } else if (theme == 1) {
            p.text = 0xFFF9FAFB; p.sub = 0xFF9CA3AF; p.tile = 0xFF1F2937; p.tileStroke = 0xFF374151;
            p.today = 0xFF374151; p.todayStroke = 0xFF6B7280; p.track = 0x33FFFFFF;
            rrect(cv, 6, 6, dw - 6, DH - 6, rad, 0xF2111827, 0xFF1F2937, 3);
        } else {
            setGlass(p);
            rrect(cv, 6, 6, dw - 6, DH - 6, rad, 0x701E2440, 0, 0);
            P.setStyle(Paint.Style.FILL);
            P.setShader(new LinearGradient(0, 0, dw, DH, 0x45FFFFFF, 0x08FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRoundRect(card, rad, rad, P);
            P.setShader(null);
            rrect(cv, 6, 6, dw - 6, DH - 6, rad, 0, 0x80FFFFFF, 3.5f);
        }
        if (layer >= 0) cv.restoreToCount(layer);
        return p;
    }

    private static void setGlass(Pal p) {
        p.text = 0xFFFFFFFF; p.sub = 0xCCFFFFFF; p.tile = 0x33FFFFFF; p.tileStroke = 0x55FFFFFF;
        p.today = 0x40FFFFFF; p.todayStroke = 0x99FFFFFF; p.track = 0x33FFFFFF;
    }

    private static Bitmap begin(int pxW, int pxH, float[] dwOut, Canvas[] cvOut) {
        float dw = Math.max(400f, Math.min(1500f, DH * (float) pxW / pxH));
        float scale = Math.min(pxW / dw, pxH / (float) DH);
        Bitmap bmp = Bitmap.createBitmap(pxW, pxH, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        cv.translate((pxW - dw * scale) / 2f, (pxH - DH * scale) / 2f);
        cv.scale(scale, scale);
        dwOut[0] = dw;
        cvOut[0] = cv;
        return bmp;
    }

    // ================= Widget chính =================
    static Bitmap render(Context c) { return render(c, 840, 560); }

    static Bitmap render(Context c, int pxW, int pxH) {
        float[] dwA = new float[1];
        Canvas[] cvA = new Canvas[1];
        Bitmap bmp = begin(pxW, pxH, dwA, cvA);
        float dw = dwA[0];
        Canvas cv = cvA[0];

        Pal pal = drawCard(c, cv, dw);
        Calendar now = Calendar.getInstance();
        boolean wide = dw >= 700;
        float pw = wide ? Math.max(300f, Math.min(440f, dw * 0.42f)) : 0;
        float rx = dw - 34 - pw;
        float leftW = wide ? rx - 20 - 46 : dw - 96;

        // giờ (và tên hiển thị lớn nằm ngay trên, căn theo bề rộng đồng hồ)
        String nm = Prefs.nameOn(c) ? Prefs.name(c).trim() : "";
        boolean hasName = nm.length() > 0;
        boolean h24 = Prefs.is24h(c);
        int hour = now.get(Calendar.HOUR_OF_DAY), min = now.get(Calendar.MINUTE);
        String time = h24 ? String.format(Locale.US, "%02d:%02d", hour, min)
                : String.format(Locale.US, "%d:%02d", hour % 12 == 0 ? 12 : hour % 12, min);
        Typeface tf = timeFace(c);
        float targetW = Math.min(leftW - (h24 ? 0 : 70), 540);
        float timeBase = hasName ? 254 : 236;
        float ts = fit(time, targetW, hasName ? 185 : 215, tf);
        int tcol = Prefs.timeColor(c);
        int timeColor = tcol > 0 && tcol < TIME_COLORS.length ? TIME_COLORS[tcol] : pal.text;
        text(cv, time, 44, timeBase, ts, timeColor, tf, Paint.Align.LEFT);
        float clockW = width(time, ts, tf);
        if (!h24) text(cv, hour < 12 ? "SA" : "CH", 44 + clockW + 8, timeBase, 34, pal.sub, true, Paint.Align.LEFT);
        if (hasName) {
            float nameBase = timeBase - ts * 0.74f - 10;
            float maxByHeight = Math.max(20f, (nameBase - 16) / 0.8f);
            float ns = fit(nm, Math.max(clockW, 160f), Math.min(80f, maxByHeight), tf);
            text(cv, nm, 46, nameBase, ns, pal.text, tf, Paint.Align.LEFT);
        }

        // ngày / âm lịch / con giáp / cung
        int d = now.get(Calendar.DAY_OF_MONTH), m = now.get(Calendar.MONTH) + 1, y = now.get(Calendar.YEAR);
        int[] l = LunarCalendar.solarToLunar(d, m, y);
        String dateLine = DOW_LONG[now.get(Calendar.DAY_OF_WEEK) - 1] + ", " + d + " tháng " + m;
        text(cv, dateLine, 48, 298, fit(dateLine, leftW, 38, Typeface.DEFAULT_BOLD), pal.text, true, Paint.Align.LEFT);
        boolean lunarOn = Prefs.showLunar(c);
        if (lunarOn) {
            String s = "Âm lịch: " + l[0] + " tháng " + l[1] + (l[3] == 1 ? " (nhuận)" : "");
            text(cv, s, 48, 340, fit(s, leftW, 32, Typeface.DEFAULT), pal.sub, false, Paint.Align.LEFT);
        }
        StringBuilder ex = new StringBuilder();
        if (Prefs.showAnimal(c)) ex.append(LunarCalendar.animalEmoji(l[2])).append(' ').append(LunarCalendar.canChi(l[2]));
        if (Prefs.showZodiac(c)) {
            if (ex.length() > 0) ex.append("  ·  ");
            ex.append(LunarCalendar.zodiacSymbol(d, m)).append(' ').append(LunarCalendar.zodiac(d, m));
        }
        if (ex.length() > 0) {
            String s = ex.toString();
            text(cv, s, 48, lunarOn ? 380 : 340, fit(s, leftW, 30, Typeface.DEFAULT), pal.sub, false, Paint.Align.LEFT);
        }

        drawWeek(cv, now, lunarOn, dw, pal);

        if (wide) {
            if (Prefs.style(c) == 0) drawStats(c, cv, pal, rx, pw, dw);
            else drawWeather(c, cv, pal, rx, pw, dw);
        } else {
            drawNarrowInfo(c, cv, pal, dw);
        }
        drawRefresh(cv, dw * 0.92f, 56, 24, pal.tile, pal.tileStroke, pal.text, Prefs.isRefreshing(c));
        return bmp;
    }

    private static void drawWeek(Canvas cv, Calendar now, boolean lunarOn, float dw, Pal pal) {
        Calendar w = (Calendar) now.clone();
        int back = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7; // 0 = Thứ Hai
        w.add(Calendar.DAY_OF_YEAR, -back);
        float cw = (dw - 60) / 7f;
        for (int i = 0; i < 7; i++) {
            float x = 30 + i * cw, cx = x + cw / 2;
            if (i == back) rrect(cv, x + 3, 408, x + cw - 3, 538, 38, pal.today, pal.todayStroke, 3);
            int dd = w.get(Calendar.DAY_OF_MONTH), mm = w.get(Calendar.MONTH) + 1, yy = w.get(Calendar.YEAR);
            boolean sun = i == 6;
            text(cv, DOW_SHORT[i], cx, 447, 27, sun ? SUNDAY_RED : (i == back ? pal.text : pal.sub), sun, Paint.Align.CENTER);
            text(cv, String.valueOf(dd), cx, 494, 46, sun ? SUNDAY_RED : pal.text, true, Paint.Align.CENTER);
            if (lunarOn) {
                int[] l = LunarCalendar.solarToLunar(dd, mm, yy);
                text(cv, l[0] == 1 ? l[0] + "/" + l[1] : String.valueOf(l[0]), cx, 527, 23, pal.sub, false, Paint.Align.CENTER);
            }
            w.add(Calendar.DAY_OF_YEAR, 1);
        }
    }

    // ---------- thông tin pin ----------
    private static int[] battery(Context c, float[] tempOut) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int pct = 0, charging = 0;
        float temp = 0;
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            pct = scale > 0 ? level * 100 / scale : 0;
            temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            charging = (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL) ? 1 : 0;
        }
        tempOut[0] = temp;
        return new int[]{pct, charging};
    }

    // ---------- khổ hẹp: một dòng thông tin ----------
    private static void drawNarrowInfo(Context c, Canvas cv, Pal pal, float dw) {
        if (Prefs.nameOn(c) && Prefs.name(c).trim().length() > 0) return;
        float[] t = new float[1];
        int[] b = battery(c, t);
        String s;
        if (Prefs.style(c) == 0) {
            StringBuilder sb = new StringBuilder();
            if (Prefs.statPin(c)) sb.append(b[0]).append('%');
            if (Prefs.statTemp(c)) { if (sb.length() > 0) sb.append(" · "); sb.append(String.format(Locale.US, "%.1f°C", t[0])); }
            s = sb.toString();
            if (s.length() == 0) return;
        } else {
            WeatherClient.Data w = WeatherClient.load(c);
            s = w.ok ? Math.round(w.temp) + "° " + WeatherClient.describe(w.code) : "Thời tiết --";
        }
        float maxW = dw * 0.92f - 24 - 20 - 48;
        text(cv, s, dw * 0.92f - 36, 66, fit(s, maxW, 26, Typeface.DEFAULT_BOLD), pal.sub, true, Paint.Align.RIGHT);
    }

    // ---------- kiểu mới: thông số hệ thống ----------
    private static void drawStats(Context c, Canvas cv, Pal pal, float rx, float pw, float dw) {
        float[] tempA = new float[1];
        int[] bat = battery(c, tempA);
        int pct = bat[0];
        float temp = tempA[0];
        boolean charging = bat[1] == 1;

        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double gb = 1024.0 * 1024 * 1024;
        double ramTotal = mi.totalMem / gb, ramUsed = (mi.totalMem - mi.availMem) / gb;
        int ramPct = mi.totalMem > 0 ? (int) Math.round(ramUsed * 100 / ramTotal) : 0;

        int diskPct = 0;
        long freeG = 0;
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            long tot = sf.getTotalBytes(), free = sf.getAvailableBytes();
            diskPct = tot > 0 ? (int) ((tot - free) * 100 / tot) : 0;
            freeG = Math.round(free / gb);
        } catch (Exception ignored) { }

        circle(cv, rx + 12, 62, 8, 0xFF22C55E);
        String model = Build.MODEL == null ? "Android" : Build.MODEL;
        float mw = dw * 0.92f - 36 - (rx + 32);
        text(cv, model, rx + 30, 72, fit(model, mw, 26, Typeface.DEFAULT_BOLD), pal.sub, true, Paint.Align.LEFT);

        String tStat = temp < 36 ? "Mát" : (temp < 42 ? "Ấm" : "Nóng");
        int tp = (int) Math.max(0, Math.min(100, (temp - 20) * 100 / 30));
        List<Object[]> tiles = new ArrayList<>();
        if (Prefs.statPin(c)) tiles.add(new Object[]{"PIN", pct + "%", charging ? "Sạc" : "", pct, pct < 20 ? 0xFFEF4444 : 0xFF22C55E});
        if (Prefs.statTemp(c)) tiles.add(new Object[]{"NHIỆT ĐỘ", String.format(Locale.US, "%.1f°", temp), tStat, tp, 0xFFF59E0B});
        if (Prefs.statRam(c)) tiles.add(new Object[]{"RAM", ramPct + "%", String.format(Locale.US, "%.1f/%dG", ramUsed, Math.round(ramTotal)), ramPct, 0xFF8B5CF6});
        if (Prefs.statDisk(c)) tiles.add(new Object[]{"Ổ CỨNG", diskPct + "%", freeG + "G", diskPct, 0xFF14B8A6});

        float gap = 14, y0 = 100, areaH = 274;
        int n = tiles.size();
        if (n == 0) {
            text(cv, "Chưa bật ô thông số nào", rx + pw / 2, y0 + areaH / 2, fit("Chưa bật ô thông số nào", pw - 20, 26, Typeface.DEFAULT), pal.sub, false, Paint.Align.CENTER);
            return;
        }
        // tự chia lại bố cục theo số ô: 1 ô lớn / 2 ô chồng / 2+1 / lưới 2x2
        float half = (pw - gap) / 2f;
        float rowH = n == 1 ? areaH : (areaH - gap) / 2f;
        for (int i = 0; i < n; i++) {
            Object[] t = tiles.get(i);
            float x, y, w, h = rowH;
            if (n == 1) { x = rx; y = y0; w = pw; }
            else if (n == 2) { x = rx; y = y0 + i * (rowH + gap); w = pw; }
            else if (n == 3) {
                if (i < 2) { x = rx + i * (half + gap); y = y0; w = half; }
                else { x = rx; y = y0 + rowH + gap; w = pw; }
            } else { x = rx + (i % 2) * (half + gap); y = y0 + (i / 2) * (rowH + gap); w = half; }
            drawTile(cv, x, y, w, h, (String) t[0], (String) t[1], (String) t[2], (Integer) t[3], (Integer) t[4], pal);
        }
    }

    /** Một ô thông số; mọi kích thước tự co giãn theo cỡ ô (f = hệ số). */
    private static void drawTile(Canvas cv, float x, float y, float w, float h, String label, String value, String note,
                                 int pct, int color, Pal pal) {
        float f = Math.max(0.85f, Math.min(1.5f, Math.min(w / 169f, h / 130f)));
        float pad = 16 * f;
        rrect(cv, x, y, x + w, y + h, 30 * Math.min(f, 1.2f), pal.tile, pal.tileStroke, 2.5f);
        rrect(cv, x + pad, y + pad, x + pad + 22 * f, y + pad + 22 * f, 7 * f, color, 0, 0);
        text(cv, label, x + pad + 32 * f, y + pad + 20 * f, 22 * f, pal.sub, true, Paint.Align.LEFT);
        float noteW = note.length() > 0 ? width(note, 19 * f, Typeface.DEFAULT) + 8 : 0;
        float vs = fit(value, w - 2 * pad - noteW, 40 * f, Typeface.DEFAULT_BOLD);
        float vy = y + h * 0.66f;
        text(cv, value, x + pad, vy, vs, pal.text, true, Paint.Align.LEFT);
        if (note.length() > 0) text(cv, note, x + w - pad + 2, vy, 19 * f, pal.sub, false, Paint.Align.RIGHT);
        float bl = x + pad, br = x + w - pad, bh = 9 * f, by = y + h - pad - bh + 2;
        rrect(cv, bl, by, br, by + bh, bh / 2, pal.track, 0, 0);
        float fw = (br - bl) * Math.max(0, Math.min(100, pct)) / 100f;
        if (fw > bh) rrect(cv, bl, by, bl + fw, by + bh, bh / 2, color, 0, 0);
    }

    static void drawRefresh(Canvas cv, float cx, float cy, float r, int fill, int stroke, int color, boolean active) {
        if (active) { fill = 0xFF2563EB; stroke = 0xFF93B4FF; color = 0xFFFFFFFF; }
        circle(cv, cx, cy, r, fill);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(3);
        P.setColor(stroke);
        cv.drawCircle(cx, cy, r, P);
        P.setColor(color);
        P.setStrokeWidth(3.5f);
        P.setStrokeCap(Paint.Cap.ROUND);
        cv.drawArc(new RectF(cx - 10, cy - 10, cx + 10, cy + 10), -50, 270, false, P);
        P.setStyle(Paint.Style.FILL);
        Path tri = new Path();
        tri.moveTo(cx + 9, cy - 14);
        tri.lineTo(cx + 15, cy - 3);
        tri.lineTo(cx + 3, cy - 5);
        tri.close();
        cv.drawPath(tri, P);
        P.setStrokeCap(Paint.Cap.BUTT);
    }

    // ---------- kiểu cổ điển: thời tiết ----------
    private static void drawWeather(Context c, Canvas cv, Pal pal, float rx, float pw, float dw) {
        WeatherClient.Data wd = WeatherClient.load(c);
        float right = dw - 34;

        circle(cv, rx + 46, 84, 40, 0xFF4F46E5);
        drawWeatherIcon(cv, rx + 46, 84, 56, wd.ok ? wd.code : 3);

        String temp = wd.ok ? Math.round(wd.temp) + "°" : "--°";
        text(cv, temp, right - 4, 134, 66, pal.text, true, Paint.Align.RIGHT);
        String desc = wd.ok ? WeatherClient.describe(wd.code) + " · " + Math.round(wd.tmin) + "°–" + Math.round(wd.tmax) + "°" : "Chưa có dữ liệu";
        text(cv, desc, right - 4, 170, fit(desc, pw - 8, 26, Typeface.DEFAULT), pal.sub, false, Paint.Align.RIGHT);
        String loc = "\uD83D\uDCCD " + Prefs.locLabel(c);
        text(cv, loc, right - 4, 204, fit(loc, pw - 8, 24, Typeface.DEFAULT_BOLD), pal.text, true, Paint.Align.RIGHT);

        float[] t = new float[1];
        int[] bat = battery(c, t);
        int pct = bat[0];
        int bcol = pct < 20 ? 0xFFEF4444 : 0xFF22C55E;
        rrect(cv, rx, 220, right, 358, 42, pal.tile, pal.tileStroke, 2.5f);
        rrect(cv, rx + 26, 236, rx + 42, 260, 4, bcol, 0, 0);
        text(cv, pct + "%", rx + 58, 261, 32, pal.text, true, Paint.Align.LEFT);
        rrect(cv, rx + 26, 272, right - 26, 280, 4, pal.track, 0, 0);
        float fw = (pw - 52) * pct / 100f;
        if (fw > 8) rrect(cv, rx + 26, 272, rx + 26 + fw, 280, 4, bcol, 0, 0);
        rrect(cv, rx + 30, 296, rx + 38, 328, 4, 0xFFF97316, 0, 0);
        circle(cv, rx + 34, 332, 10, 0xFFF97316);
        text(cv, String.format(Locale.US, "%.1f°C", t[0]), rx + 58, 336, 32, pal.text, true, Paint.Align.LEFT);
    }

    private static void drawCloud(Canvas cv, float cx, float cy, float s, int color) {
        circle(cv, cx - 0.17f * s, cy + 0.03f * s, 0.17f * s, color);
        circle(cv, cx + 0.01f * s, cy - 0.09f * s, 0.23f * s, color);
        circle(cv, cx + 0.2f * s, cy + 0.04f * s, 0.16f * s, color);
        rrect(cv, cx - 0.33f * s, cy + 0.03f * s, cx + 0.36f * s, cy + 0.2f * s, 0.085f * s, color, 0, 0);
    }

    private static void drawWeatherIcon(Canvas cv, float cx, float cy, float s, int code) {
        int cloud = 0xFF22D3EE, sun = 0xFFFBBF24;
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        boolean storm = code >= 95;
        if (code <= 1) {
            circle(cv, cx, cy, 0.22f * s, sun);
            P.setStyle(Paint.Style.STROKE);
            P.setStrokeWidth(4);
            P.setStrokeCap(Paint.Cap.ROUND);
            P.setColor(sun);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                cv.drawLine(cx + (float) Math.cos(a) * 0.32f * s, cy + (float) Math.sin(a) * 0.32f * s,
                        cx + (float) Math.cos(a) * 0.42f * s, cy + (float) Math.sin(a) * 0.42f * s, P);
            }
            P.setStyle(Paint.Style.FILL);
            P.setStrokeCap(Paint.Cap.BUTT);
            return;
        }
        if (code == 2) circle(cv, cx + 0.2f * s, cy - 0.2f * s, 0.18f * s, sun);
        drawCloud(cv, cx, cy - (rain || snow || storm ? 0.06f * s : 0), s, cloud);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(4.5f);
        P.setStrokeCap(Paint.Cap.ROUND);
        if (rain) {
            P.setColor(0xFFBAE6FD);
            for (int i = -1; i <= 1; i++)
                cv.drawLine(cx + i * 0.17f * s, cy + 0.2f * s, cx + i * 0.17f * s - 0.05f * s, cy + 0.34f * s, P);
        } else if (snow) {
            P.setColor(0xFFFFFFFF);
            for (int i = -1; i <= 1; i++) cv.drawPoint(cx + i * 0.17f * s, cy + 0.27f * s, P);
        } else if (storm) {
            P.setStyle(Paint.Style.FILL);
            P.setColor(sun);
            Path bolt = new Path();
            bolt.moveTo(cx + 0.04f * s, cy + 0.12f * s);
            bolt.lineTo(cx - 0.1f * s, cy + 0.3f * s);
            bolt.lineTo(cx, cy + 0.3f * s);
            bolt.lineTo(cx - 0.05f * s, cy + 0.44f * s);
            bolt.lineTo(cx + 0.12f * s, cy + 0.24f * s);
            bolt.lineTo(cx + 0.02f * s, cy + 0.24f * s);
            bolt.close();
            cv.drawPath(bolt, P);
        }
        P.setStyle(Paint.Style.FILL);
        P.setStrokeCap(Paint.Cap.BUTT);
    }

    // ================= Widget giá cả (3 tab) =================
    static final String[] PRICE_TAB_TITLE = {"Cà phê · Hồ tiêu", "Giá vàng", "Xăng dầu"};
    static final String[] PRICE_TAB_LABEL = {"☕ Cà phê/Tiêu", "🥇 Vàng", "⛽ Xăng dầu"};

    static Bitmap renderPrices(Context c) { return renderPrices(c, 840, 560); }

    static Bitmap renderPrices(Context c, int pxW, int pxH) {
        float[] dwA = new float[1];
        Canvas[] cvA = new Canvas[1];
        Bitmap bmp = begin(pxW, pxH, dwA, cvA);
        float dw = dwA[0];
        Canvas cv = cvA[0];
        Pal pal = drawCard(c, cv, dw);
        PriceClient.Data d = PriceClient.load(c);
        List<Integer> tabs = PriceClient.enabledTabs(c);
        drawRefresh(cv, dw * 0.92f, 56, 24, pal.tile, pal.tileStroke, pal.text, Prefs.isRefreshing(c));

        if (tabs.isEmpty()) {
            text(cv, "Chưa bật mục nào", dw / 2, 280, 40, pal.text, true, Paint.Align.CENTER);
            text(cv, "Bật trong tab Giá cả của ứng dụng", dw / 2, 330, 26, pal.sub, false, Paint.Align.CENTER);
            return bmp;
        }
        int cur = PriceClient.currentTab(c, tabs);

        // tiêu đề
        float titleMax = dw * 0.92f - 24 - 28 - 48;
        text(cv, PRICE_TAB_TITLE[cur], 48, 86, fit(PRICE_TAB_TITLE[cur], titleMax, 44, Typeface.DEFAULT_BOLD), pal.text, true, Paint.Align.LEFT);
        String sub = d.time > 0 ? "Cập nhật " : "Chưa có dữ liệu · chạm ⟳ để cập nhật";
        if (d.time > 0) {
            Calendar t = Calendar.getInstance();
            t.setTimeInMillis(d.time);
            sub += String.format(Locale.US, "%02d:%02d ngày %02d/%02d", t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE),
                    t.get(Calendar.DAY_OF_MONTH), t.get(Calendar.MONTH) + 1);
        }
        text(cv, sub, 48, 124, fit(sub, dw - 96, 24, Typeface.DEFAULT), pal.sub, false, Paint.Align.LEFT);

        // nội dung
        float top = 148, bottom = 466, x0 = 28, w = dw - 56;
        if (cur == 0) {
            boolean cof = Prefs.priceCoffee(c), pep = Prefs.pricePepper(c);
            boolean wide = dw >= 700;
            if (cof && pep) {
                if (wide) {
                    float cw = (w - 20) / 2f;
                    drawList(cv, x0, top, cw, bottom - top, "Cà phê", "đ/kg", d.coffee, d.status[0], pal);
                    drawList(cv, x0 + cw + 20, top, cw, bottom - top, "Hồ tiêu", "đ/kg", d.pepper, d.status[1], pal);
                } else {
                    float h2 = (bottom - top - 10) / 2f;
                    drawList(cv, x0, top, w, h2, "Cà phê", "đ/kg", d.coffee, d.status[0], pal);
                    drawList(cv, x0, top + h2 + 10, w, h2, "Hồ tiêu", "đ/kg", d.pepper, d.status[1], pal);
                }
            } else if (cof) drawList(cv, x0, top, w, bottom - top, "Cà phê", "đ/kg", d.coffee, d.status[0], pal);
            else drawList(cv, x0, top, w, bottom - top, "Hồ tiêu", "đ/kg", d.pepper, d.status[1], pal);
        } else if (cur == 1) {
            drawTwoCol(cv, x0, top, w, bottom - top, "Vàng trong nước", "triệu đồng/lượng", "Mua", "Bán",
                    d.gold, true, d.status[2], pal, Prefs.goldPage(c));
        } else {
            String unit = d.fuelDate.length() > 0 ? "đ/lít · " + d.fuelDate : "đ/lít";
            drawTwoCol(cv, x0, top, w, bottom - top, "Xăng dầu Petrolimex", unit, "Vùng 1", "Vùng 2",
                    d.fuel, false, d.status[3], pal, 0);
        }

        // thanh tab (giống iOS): chạm để chuyển tab
        float barTop = 480, barBot = DH - 20;
        rrect(cv, 28, barTop, dw - 28, barBot, 32, pal.tile, pal.tileStroke, 2.5f);
        float seg = (dw - 56) / tabs.size();
        for (int j = 0; j < tabs.size(); j++) {
            int t = tabs.get(j);
            float sx = 28 + j * seg;
            boolean on = t == cur;
            if (on) rrect(cv, sx + 5, barTop + 5, sx + seg - 5, barBot - 5, 28, pal.today, pal.todayStroke, 2.5f);
            String lab = PRICE_TAB_LABEL[t];
            text(cv, lab, sx + seg / 2, (barTop + barBot) / 2 + 9, fit(lab, seg - 24, 26, Typeface.DEFAULT_BOLD),
                    on ? pal.text : pal.sub, true, Paint.Align.CENTER);
        }
        return bmp;
    }

    /** Danh sách "tên ... giá" (cà phê, tiêu theo tỉnh, xăng dầu). */
    private static void drawList(Canvas cv, float x, float y, float w, float h, String title, String unit,
                                 List<PriceClient.Item> items, String status, Pal pal) {
        text(cv, title, x + 8, y + 30, 28, pal.text, true, Paint.Align.LEFT);
        text(cv, unit, x + w - 8, y + 30, fit(unit, w * 0.55f, 21, Typeface.DEFAULT), pal.sub, false, Paint.Align.RIGHT);
        float ty = y + 44;
        if (items.isEmpty()) {
            String msg = status != null && status.length() > 0 && !"OK".equals(status) ? "Lỗi: " + status : "Chưa có dữ liệu";
            text(cv, msg, x + w / 2, ty + (h - 44) / 2, fit(msg, w - 20, 24, Typeface.DEFAULT), pal.sub, false, Paint.Align.CENTER);
            return;
        }
        int n = Math.min(items.size(), 6);
        float rowH = Math.min(58f, (h - 44) / n);
        if (rowH < 34 && n > 1) { n = Math.max(1, (int) ((h - 44) / 34f)); rowH = (h - 44) / n; }
        for (int i = 0; i < n; i++) {
            PriceClient.Item it = items.get(i);
            float ry = ty + i * rowH;
            rrect(cv, x, ry + 3, x + w, ry + rowH - 3, Math.min(24, rowH * 0.4f), pal.tile, pal.tileStroke, 1.5f);
            float cy = ry + rowH / 2;
            String val = PriceClient.fmt(it.v1);
            float vs = Math.min(30f, rowH * 0.5f);
            float vw = width(val, vs, Typeface.DEFAULT_BOLD);
            text(cv, val, x + w - 16, cy + vs * 0.35f, vs, pal.text, Typeface.DEFAULT_BOLD, Paint.Align.RIGHT);
            float chW = 0;
            if (it.v2 != 0) {
                String ch = (it.v2 > 0 ? "▲" : "▼") + PriceClient.fmt(Math.abs(it.v2));
                float cs = Math.min(20f, rowH * 0.36f);
                chW = width(ch, cs, Typeface.DEFAULT_BOLD) + 14;
                text(cv, ch, x + w - 16 - vw - 12, cy + cs * 0.35f, cs, it.v2 > 0 ? 0xFF22C55E : 0xFFEF4444, Typeface.DEFAULT_BOLD, Paint.Align.RIGHT);
            }
            float ns = Math.min(26f, rowH * 0.46f);
            float nameMax = w - 32 - vw - 12 - chW;
            text(cv, it.name, x + 16, cy + ns * 0.35f, fit(it.name, nameMax, ns, Typeface.DEFAULT_BOLD), pal.text, true, Paint.Align.LEFT);
        }
    }

    /** Bảng hai cột số (vàng: mua/bán, xăng dầu: vùng 1/vùng 2), tự chia trang nếu nhiều dòng. */
    private static void drawTwoCol(Canvas cv, float x, float y, float w, float h, String title, String unit,
                                   String c1, String c2, List<PriceClient.Item> items, boolean gold,
                                   String status, Pal pal, int page) {
        int perPage = Math.max(1, Math.min(8, (int) ((h - 74) / 34f)));
        int pages = Math.max(1, (items.size() + perPage - 1) / perPage);
        int pg = items.isEmpty() ? 0 : page % pages;
        String head = pages > 1 ? title + " (" + (pg + 1) + "/" + pages + ")" : title;
        text(cv, head, x + 8, y + 30, fit(head, w * 0.6f, 28, Typeface.DEFAULT_BOLD), pal.text, true, Paint.Align.LEFT);
        text(cv, unit, x + w - 8, y + 30, fit(unit, w * 0.4f, 21, Typeface.DEFAULT), pal.sub, false, Paint.Align.RIGHT);
        float ty = y + 44;
        if (items.isEmpty()) {
            String msg = status != null && status.length() > 0 && !"OK".equals(status) ? "Lỗi: " + status : "Chưa có dữ liệu";
            text(cv, msg, x + w / 2, ty + (h - 44) / 2, fit(msg, w - 20, 24, Typeface.DEFAULT), pal.sub, false, Paint.Align.CENTER);
            return;
        }
        float colW = Math.max(90f, Math.min(170f, w * 0.21f));
        text(cv, c1, x + w - 16 - colW, ty + 22, 21, pal.sub, true, Paint.Align.RIGHT);
        text(cv, c2, x + w - 16, ty + 22, 21, pal.sub, true, Paint.Align.RIGHT);
        float ry0 = ty + 30;
        int shown = Math.min(perPage, items.size() - pg * perPage);
        float rowH = Math.min(52f, (h - 74) / Math.min(items.size(), perPage));
        for (int i = 0; i < shown; i++) {
            PriceClient.Item it = items.get(pg * perPage + i);
            float ry = ry0 + i * rowH;
            rrect(cv, x, ry + 3, x + w, ry + rowH - 3, Math.min(22, rowH * 0.4f), pal.tile, pal.tileStroke, 1.5f);
            float cy = ry + rowH / 2;
            float vs = Math.min(27f, Math.min(rowH * 0.48f, w * 0.065f));
            String s1 = gold ? PriceClient.fmtMillion(it.v1) : (it.v1 > 0 ? PriceClient.fmt(it.v1) : "-");
            String s2 = gold ? PriceClient.fmtMillion(it.v2) : (it.v2 > 0 ? PriceClient.fmt(it.v2) : "-");
            text(cv, s2, x + w - 16, cy + vs * 0.35f, vs, pal.text, Typeface.DEFAULT_BOLD, Paint.Align.RIGHT);
            text(cv, s1, x + w - 16 - colW, cy + vs * 0.35f, vs, pal.text, Typeface.DEFAULT_BOLD, Paint.Align.RIGHT);
            float ns = Math.min(24f, rowH * 0.44f);
            float nameMax = w - 32 - colW - width(s1, vs, Typeface.DEFAULT_BOLD) - 14;
            text(cv, it.name, x + 16, cy + ns * 0.35f, fit(it.name, nameMax, ns, Typeface.DEFAULT_BOLD), pal.text, true, Paint.Align.LEFT);
        }
    }
}
