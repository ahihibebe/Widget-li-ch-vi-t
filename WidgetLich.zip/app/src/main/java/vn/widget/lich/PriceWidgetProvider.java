package vn.widget.lich;

/** Widget giá cà phê / hồ tiêu / xăng dầu. Toàn bộ xử lý dùng chung với WidgetProvider. */
public class PriceWidgetProvider extends WidgetProvider {
}
