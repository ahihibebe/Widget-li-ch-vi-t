package vn.widget.lich;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("widget_lich", Context.MODE_PRIVATE);
    }

    // ----- giao diện -----
    /** 0 = Chuẩn Sáng, 1 = Chuẩn Tối, 2 = Liquid Glass */
    static int theme(Context c) { return sp(c).getInt("theme", 2); }
    static void setTheme(Context c, int v) { sp(c).edit().putInt("theme", v).apply(); }

    /** 0 = Thông số hệ thống, 1 = Thời tiết cổ điển */
    static int style(Context c) { return sp(c).getInt("style", 0); }
    static void setStyle(Context c, int v) { sp(c).edit().putInt("style", v).apply(); }

    static boolean is24h(Context c) { return sp(c).getBoolean("h24", true); }
    static void set24h(Context c, boolean v) { sp(c).edit().putBoolean("h24", v).apply(); }

    static boolean showLunar(Context c) { return sp(c).getBoolean("lunar", true); }
    static void setShowLunar(Context c, boolean v) { sp(c).edit().putBoolean("lunar", v).apply(); }

    static boolean showAnimal(Context c) { return sp(c).getBoolean("animal", true); }
    static void setShowAnimal(Context c, boolean v) { sp(c).edit().putBoolean("animal", v).apply(); }

    static boolean showZodiac(Context c) { return sp(c).getBoolean("zodiac", true); }
    static void setShowZodiac(Context c, boolean v) { sp(c).edit().putBoolean("zodiac", v).apply(); }

    // ----- font giờ / màu giờ -----
    static int font(Context c) { return sp(c).getInt("font", 3); }
    static void setFont(Context c, int v) { sp(c).edit().putInt("font", v).apply(); }

    /** 0 = tự động theo giao diện, còn lại là màu trong WidgetRenderer.TIME_COLORS */
    static int timeColor(Context c) { return sp(c).getInt("tcolor", 0); }
    static void setTimeColor(Context c, int v) { sp(c).edit().putInt("tcolor", v).apply(); }

    // ----- tên hiển thị trên giờ -----
    static boolean nameOn(Context c) { return sp(c).getBoolean("name_on", false); }
    static void setNameOn(Context c, boolean v) { sp(c).edit().putBoolean("name_on", v).apply(); }
    static String name(Context c) { return sp(c).getString("name", ""); }
    static void setName(Context c, String v) { sp(c).edit().putString("name", v).apply(); }

    // ----- ảnh nền: 0 = không, 1..N = nền màu có sẵn, 100 = ảnh của bạn -----
    static int bg(Context c) { return sp(c).getInt("bg", 0); }
    static void setBg(Context c, int v) { sp(c).edit().putInt("bg", v).apply(); }
    /** Độ trong suốt của nền widget (0 = đục hoàn toàn, tối đa 95). */
    static int transparency(Context c) { return sp(c).getInt("transp", 0); }
    static void setTransparency(Context c, int v) { sp(c).edit().putInt("transp", v).apply(); }
    static int bgDim(Context c) { return sp(c).getInt("bg_dim", 35); }
    static void setBgDim(Context c, int v) { sp(c).edit().putInt("bg_dim", v).apply(); }

    // ----- vị trí thời tiết -----
    static double lat(Context c) { return Double.longBitsToDouble(sp(c).getLong("lat", Double.doubleToLongBits(21.0278))); }
    static double lon(Context c) { return Double.longBitsToDouble(sp(c).getLong("lon", Double.doubleToLongBits(105.8342))); }
    static String locLabel(Context c) { return sp(c).getString("loc_label", "Hà Nội"); }
    /** Độ chính xác: 3 = GPS, 2 = phường/xã, 1 = chỉ tới tỉnh */
    static int locLevel(Context c) { return sp(c).getInt("loc_level", 1); }
    static int provinceCode(Context c) { return sp(c).getInt("prov_code", 0); }
    static int wardCode(Context c) { return sp(c).getInt("ward_code", 0); }

    static void setLocation(Context c, double lat, double lon, String label, int level, int provCode, int wardCode) {
        sp(c).edit()
                .putLong("lat", Double.doubleToLongBits(lat))
                .putLong("lon", Double.doubleToLongBits(lon))
                .putString("loc_label", label)
                .putInt("loc_level", level)
                .putInt("prov_code", provCode)
                .putInt("ward_code", wardCode)
                .putLong("wtime", 0)
                .apply();
    }

    // ----- giá cả -----
    static boolean priceCoffee(Context c) { return sp(c).getBoolean("p_coffee", true); }
    static void setPriceCoffee(Context c, boolean v) { sp(c).edit().putBoolean("p_coffee", v).apply(); }
    static boolean pricePepper(Context c) { return sp(c).getBoolean("p_pepper", true); }
    static void setPricePepper(Context c, boolean v) { sp(c).edit().putBoolean("p_pepper", v).apply(); }
    static boolean priceGold(Context c) { return sp(c).getBoolean("p_gold", true); }
    static void setPriceGold(Context c, boolean v) { sp(c).edit().putBoolean("p_gold", v).apply(); }
    /** Tab đang xem của widget giá: 0 = cà phê/tiêu, 1 = vàng, 2 = xăng dầu */
    static int priceTab(Context c) { return sp(c).getInt("p_tab", 0); }
    static void setPriceTab(Context c, int v) { sp(c).edit().putInt("p_tab", v).apply(); }
    static int goldPage(Context c) { return sp(c).getInt("g_page", 0); }
    static void setGoldPage(Context c, int v) { sp(c).edit().putInt("g_page", v).apply(); }
    static boolean priceFuel(Context c) { return sp(c).getBoolean("p_fuel", true); }
    static void setPriceFuel(Context c, boolean v) { sp(c).edit().putBoolean("p_fuel", v).apply(); }

    /** Kích thước xem trước trong app: 0 = 2x2, 1 = 4x2, 2 = 4x3 */
    static int previewSize(Context c) { return sp(c).getInt("pv_size", 2); }
    static void setPreviewSize(Context c, int v) { sp(c).edit().putInt("pv_size", v).apply(); }
}
