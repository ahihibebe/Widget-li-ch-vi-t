package vn.widget.lich;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    static final String[] CITY_NAMES = {"Hà Nội", "TP. Hồ Chí Minh", "Đà Nẵng", "Hải Phòng", "Cần Thơ", "Huế",
            "Nha Trang", "Đà Lạt", "Vinh", "Buôn Ma Thuột", "Vũng Tàu", "Quy Nhơn", "Hạ Long",
            "Thái Nguyên", "Vĩnh Long", "Pleiku", "Phan Thiết"};
    static final double[] CITY_LAT = {21.0278, 10.8231, 16.0544, 20.8449, 10.0452, 16.4637,
            12.2388, 11.9404, 18.6796, 12.6667, 10.3460, 13.7765, 20.9599,
            21.5928, 10.2538, 13.9833, 10.9289};
    static final double[] CITY_LON = {105.8342, 106.6297, 108.2022, 106.6881, 105.7469, 107.5909,
            109.1967, 108.4583, 105.6813, 108.0378, 107.0843, 109.2237, 107.0448,
            105.8442, 105.9722, 108.0000, 108.1021};

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("widget_lich", Context.MODE_PRIVATE);
    }

    /** 0 = Chuẩn Sáng, 1 = Chuẩn Tối, 2 = Liquid Glass */
    static int theme(Context c) { return sp(c).getInt("theme", 2); }
    static void setTheme(Context c, int v) { sp(c).edit().putInt("theme", v).apply(); }

    /** 0 = Thông số hệ thống, 1 = Thời tiết cổ điển */
    static int style(Context c) { return sp(c).getInt("style", 0); }
    static void setStyle(Context c, int v) { sp(c).edit().putInt("style", v).apply(); }

    static boolean is24h(Context c) { return sp(c).getBoolean("h24", true); }
    static void set24h(Context c, boolean v) { sp(c).edit().putBoolean("h24", v).apply(); }

    static boolean showLunar(Context c) { return sp(c).getBoolean("lunar", true); }
    static void setShowLunar(Context c, boolean v) { sp(c).edit().putBoolean("lunar", v).apply(); }

    /** Chỉ số thành phố; bằng CITY_NAMES.length nghĩa là dùng GPS. */
    static int city(Context c) { return sp(c).getInt("city", 0); }
    static void setCity(Context c, int v) { sp(c).edit().putInt("city", v).apply(); }

    static void setGps(Context c, double lat, double lon) {
        sp(c).edit().putString("gps_lat", String.valueOf(lat)).putString("gps_lon", String.valueOf(lon)).apply();
    }
    static boolean hasGps(Context c) { return sp(c).contains("gps_lat"); }

    static double lat(Context c) {
        int i = city(c);
        if (i < CITY_NAMES.length) return CITY_LAT[i];
        try { return Double.parseDouble(sp(c).getString("gps_lat", "21.0278")); } catch (Exception e) { return 21.0278; }
    }
    static double lon(Context c) {
        int i = city(c);
        if (i < CITY_NAMES.length) return CITY_LON[i];
        try { return Double.parseDouble(sp(c).getString("gps_lon", "105.8342")); } catch (Exception e) { return 105.8342; }
    }
    static String cityLabel(Context c) {
        int i = city(c);
        return i < CITY_NAMES.length ? CITY_NAMES[i] : "Vị trí hiện tại";
    }
}
