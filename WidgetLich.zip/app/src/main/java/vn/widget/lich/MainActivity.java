package vn.widget.lich;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final int BLUE = 0xFF2563EB, DARK = 0xFF111827, GRAY = 0xFF6B7280, RED = 0xFFDC2626, BG = 0xFFF3F5FA;
    static final int REQ_BG = 11, REQ_FONT = 12, REQ_GPS = 7;
    static final int TABS = 5;
    static final String[] TAB_ICON = {"📅", "⛅", "💰", "🎨", "📖"};
    static final String[] TAB_NAME = {"Lịch Việt", "Thời tiết", "Giá cả", "Tùy chỉnh", "Hướng dẫn"};
    static final int[][] PREVIEW_PX = {{560, 560}, {1000, 500}, {840, 560}};
    static final String[] PREVIEW_NAMES = {"2×2", "4×2", "4×3"};

    interface IntCb { void on(int i); }

    final Handler ui = new Handler(Looper.getMainLooper());
    LinearLayout page;
    final LinearLayout[] navItems = new LinearLayout[TABS];
    int tab = 0, calY, calM, selD;
    ImageView preview, pricePreview;

    // chọn địa phương
    Spinner provSpinner, wardSpinner;
    List<GeoClient.Item> provList = new ArrayList<>(), wardList = new ArrayList<>();
    int loadedProv = -1;
    TextView locStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(8), dp(16), dp(24));
        sv.addView(page, new ViewGroup.LayoutParams(MP, WC));
        root.addView(sv, new LinearLayout.LayoutParams(MP, 0, 1));
        root.addView(buildNav(), new LinearLayout.LayoutParams(MP, WC));
        setContentView(root);

        Calendar c = Calendar.getInstance();
        calY = c.get(Calendar.YEAR);
        calM = c.get(Calendar.MONTH);
        selD = c.get(Calendar.DAY_OF_MONTH);
        showTab(0);

        new Thread(() -> {
            WeatherClient.refreshIfStale(getApplicationContext());
            PriceClient.refreshIfStale(getApplicationContext());
            ui.post(() -> {
                WidgetProvider.updateAll(this);
                if (tab == 1 || tab == 2) showTab(tab);
            });
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        WidgetProvider.updateAll(this);
        WidgetProvider.scheduleNext(this);
        refreshPreviews();
    }

    // ---------------- helpers ----------------
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable shape(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1.5f), stroke);
        return g;
    }

    TextView tv(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout.LayoutParams lp(int w, int h, float top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(16), dp(18), dp(18));
        l.setBackground(shape(0xFFFFFFFF, 26, 0xFFE5E9F2));
        page.addView(l, lp(MP, WC, 14));
        return l;
    }

    TextView section(String s) {
        TextView t = tv(s, 13, 0xFF4B5563, true);
        t.setLetterSpacing(0.1f);
        return t;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    TextView pill(CharSequence s, boolean on, float sp) {
        TextView t = tv("", sp, on ? BLUE : 0xFF374151, true);
        t.setText(s);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        t.setBackground(shape(on ? 0xFFE8EFFF : 0xFFFFFFFF, 20, on ? BLUE : 0xFFD1D5DB));
        return t;
    }

    TextView button(String s) {
        TextView t = tv(s, 16, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(13), dp(16), dp(13));
        t.setBackground(shape(BLUE, 16, 0));
        return t;
    }

    TextView buttonLight(String s) {
        TextView t = tv(s, 16, BLUE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(13), dp(16), dp(13));
        t.setBackground(shape(0xFFE8EFFF, 16, BLUE));
        return t;
    }

    /** Lưới chip nhiều hàng. faces/dots (nếu có) dùng để đổi font hoặc tô màu chấm đầu chữ. */
    void chipGrid(LinearLayout parent, String[] labels, int selected, int perRow, Typeface[] faces, int[] dots, IntCb cb) {
        LinearLayout row = null;
        for (int i = 0; i < labels.length; i++) {
            if (i % perRow == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                parent.addView(row, lp(MP, WC, 8));
            }
            CharSequence txt = labels[i];
            if (dots != null && dots[i] != 0) {
                SpannableString sp = new SpannableString("● " + labels[i]);
                sp.setSpan(new ForegroundColorSpan(dots[i]), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                txt = sp;
            }
            final int idx = i;
            TextView ch = pill(txt, i == selected, 14);
            if (faces != null && faces[i] != null) ch.setTypeface(faces[i]);
            ch.setOnClickListener(v -> cb.on(idx));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WC, 1);
            p.rightMargin = dp(6);
            row.addView(ch, p);
        }
        int rem = (perRow - labels.length % perRow) % perRow;
        for (int k = 0; k < rem && row != null; k++) {
            View sp = new View(this);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 1, 1);
            p.rightMargin = dp(6);
            row.addView(sp, p);
        }
    }

    Switch addSwitch(LinearLayout parent, String label, boolean on, android.widget.CompoundButton.OnCheckedChangeListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(tv(label, 17, DARK, false), new LinearLayout.LayoutParams(0, WC, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        row.addView(sw);
        parent.addView(row, lp(MP, WC, 12));
        return sw;
    }

    // ---------------- điều hướng ----------------
    View buildNav() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(0xFFFFFFFF);
        bar.setPadding(dp(4), dp(6), dp(4), dp(6));
        for (int i = 0; i < TABS; i++) {
            final int idx = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setPadding(dp(2), dp(6), dp(2), dp(6));
            TextView icon = tv(TAB_ICON[i], 22, DARK, false);
            icon.setGravity(Gravity.CENTER);
            icon.setIncludeFontPadding(false);
            icon.setSingleLine(true);
            it.addView(icon, new LinearLayout.LayoutParams(MP, WC));
            TextView name = tv(TAB_NAME[i], 11, GRAY, true);
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            name.setIncludeFontPadding(false);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(MP, WC);
            np.topMargin = dp(3);
            it.addView(name, np);
            it.setOnClickListener(v -> showTab(idx));
            navItems[i] = it;
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, WC, 1);
            ip.leftMargin = dp(2);
            ip.rightMargin = dp(2);
            bar.addView(it, ip);
        }
        return bar;
    }

    void showTab(int t) {
        tab = t;
        for (int i = 0; i < TABS; i++) {
            boolean on = i == t;
            navItems[i].setBackground(on ? shape(0xFFE8EFFF, 18, 0) : null);
            ((TextView) navItems[i].getChildAt(1)).setTextColor(on ? BLUE : GRAY);
        }
        preview = null;
        pricePreview = null;
        provSpinner = null;
        wardSpinner = null;
        locStatus = null;
        page.removeAllViews();
        page.addView(header(), lp(MP, WC, 8));
        if (t == 0) calendarTab();
        else if (t == 1) weatherTab();
        else if (t == 2) priceTab();
        else if (t == 3) customTab();
        else guideTab();
    }

    View header() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(22), dp(22), dp(22), dp(22));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF2563EB, 0xFF5B3FE0});
        g.setCornerRadius(dp(28));
        h.setBackground(g);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(tv("Widget Lịch", 28, 0xFFFFFFFF, true));
        left.addView(tv("Đồng hồ · Lịch Việt", 14, 0xFFDDE7FF, false));
        h.addView(left, new LinearLayout.LayoutParams(0, WC, 1));
        TextView badge = tv("v10", 16, 0xFFFFFFFF, true);
        badge.setPadding(dp(14), dp(7), dp(14), dp(7));
        badge.setBackground(shape(0x33FFFFFF, 20, 0));
        h.addView(badge);
        return h;
    }

    // ---------------- Tab 1: Lịch Việt ----------------
    void calendarTab() {
        LinearLayout card = card();
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView prev = tv("◀", 20, BLUE, true), next = tv("▶", 20, BLUE, true);
        prev.setPadding(dp(14), dp(8), dp(14), dp(8));
        next.setPadding(dp(14), dp(8), dp(14), dp(8));
        TextView title = tv("Tháng " + (calM + 1) + "/" + calY, 20, DARK, true);
        title.setGravity(Gravity.CENTER);
        prev.setOnClickListener(v -> { calM--; if (calM < 0) { calM = 11; calY--; } selD = 1; showTab(0); });
        next.setOnClickListener(v -> { calM++; if (calM > 11) { calM = 0; calY++; } selD = 1; showTab(0); });
        nav.addView(prev);
        nav.addView(title, new LinearLayout.LayoutParams(0, WC, 1));
        nav.addView(next);
        card.addView(nav, new LinearLayout.LayoutParams(MP, WC));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            TextView t = tv(WidgetRenderer.DOW_SHORT[i], 14, i == 6 ? RED : GRAY, true);
            t.setGravity(Gravity.CENTER);
            head.addView(t, new LinearLayout.LayoutParams(0, WC, 1));
        }
        card.addView(head, lp(MP, WC, 10));

        Calendar now = Calendar.getInstance();
        Calendar first = new GregorianCalendar(calY, calM, 1);
        int offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7;
        int dim = first.getActualMaximum(Calendar.DAY_OF_MONTH);
        int rows = (offset + dim + 6) / 7;
        List<String> holidays = new ArrayList<>();
        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 7; col++) {
                final int day = r * 7 + col - offset + 1;
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                if (day >= 1 && day <= dim) {
                    int[] l = LunarCalendar.solarToLunar(day, calM + 1, calY);
                    String hol = LunarCalendar.holiday(day, calM + 1, l);
                    if (hol != null) holidays.add(day + "/" + (calM + 1) + ": " + hol);
                    boolean isToday = day == now.get(Calendar.DAY_OF_MONTH) && calM == now.get(Calendar.MONTH) && calY == now.get(Calendar.YEAR);
                    boolean sel = day == selD;
                    int numColor = isToday ? 0xFFFFFFFF : (col == 6 || hol != null ? RED : DARK);
                    cell.addView(tv(String.valueOf(day), 17, numColor, true));
                    cell.addView(tv(l[0] == 1 ? l[0] + "/" + l[1] : String.valueOf(l[0]), 11,
                            isToday ? 0xFFDDE7FF : (hol != null ? RED : GRAY), false));
                    if (isToday) cell.setBackground(shape(BLUE, 14, 0));
                    else if (sel) cell.setBackground(shape(0xFFE8EFFF, 14, BLUE));
                    cell.setOnClickListener(v -> { selD = day; showTab(0); });
                }
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(56), 1);
                p.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
                row.addView(cell, p);
            }
            card.addView(row, new LinearLayout.LayoutParams(MP, WC));
        }

        TextView today = button("Về hôm nay");
        today.setOnClickListener(v -> {
            Calendar n = Calendar.getInstance();
            calY = n.get(Calendar.YEAR);
            calM = n.get(Calendar.MONTH);
            selD = n.get(Calendar.DAY_OF_MONTH);
            showTab(0);
        });
        card.addView(today, lp(MP, WC, 12));

        int sd = Math.min(selD, dim);
        int[] sl = LunarCalendar.solarToLunar(sd, calM + 1, calY);
        int dow = new GregorianCalendar(calY, calM, sd).get(Calendar.DAY_OF_WEEK) - 1;
        LinearLayout info = card();
        info.addView(section("NGÀY ĐÃ CHỌN"));
        info.addView(tv(WidgetRenderer.DOW_LONG[dow] + ", " + sd + "/" + (calM + 1) + "/" + calY, 20, DARK, true), lp(WC, WC, 8));
        info.addView(tv("Âm lịch: " + sl[0] + " tháng " + sl[1] + (sl[3] == 1 ? " (nhuận)" : "")
                + " · năm " + LunarCalendar.canChi(sl[2]), 16, GRAY, false), lp(WC, WC, 4));
        info.addView(tv(LunarCalendar.animalEmoji(sl[2]) + " Tuổi con " + LunarCalendar.animal(sl[2]), 16, DARK, false), lp(WC, WC, 6));
        info.addView(tv(LunarCalendar.zodiacSymbol(sd, calM + 1) + " Cung " + LunarCalendar.zodiac(sd, calM + 1), 16, DARK, false), lp(WC, WC, 4));
        String sh = LunarCalendar.holiday(sd, calM + 1, sl);
        if (sh != null) info.addView(tv("🎉 " + sh, 16, RED, true), lp(WC, WC, 6));

        if (!holidays.isEmpty()) {
            LinearLayout hc = card();
            hc.addView(section("NGÀY LỄ TRONG THÁNG"));
            for (String s : holidays) hc.addView(tv(s, 15, DARK, false), lp(WC, WC, 6));
        }
    }

    // ---------------- Tab 2: Thời tiết ----------------
    void weatherTab() {
        LinearLayout loc = card();
        loc.addView(section("VỊ TRÍ THỜI TIẾT"));
        loc.addView(tv("📍 " + Prefs.locLabel(this), 18, DARK, true), lp(WC, WC, 8));
        int lv = Prefs.locLevel(this);
        String acc = lv == 3 ? "Đang dùng GPS của máy (chính xác nhất)."
                : lv == 2 ? "Đã định vị tới phường/xã."
                : "Chưa tìm được phường/xã trên bản đồ, đang dùng tâm của tỉnh/thành.";
        locStatus = tv(acc, 13, GRAY, false);
        loc.addView(locStatus, lp(WC, WC, 2));

        loc.addView(tv("Chọn tỉnh/thành", 14, GRAY, true), lp(WC, WC, 14));
        final Spinner ps = new Spinner(this, Spinner.MODE_DIALOG);
        provSpinner = ps;
        loc.addView(ps, lp(MP, WC, 2));
        loc.addView(tv("Chọn phường/xã", 14, GRAY, true), lp(WC, WC, 10));
        final Spinner ws = new Spinner(this, Spinner.MODE_DIALOG);
        wardSpinner = ws;
        loc.addView(ws, lp(MP, WC, 2));

        TextView set = button("Đặt vị trí theo phường/xã");
        set.setOnClickListener(v -> applyAdminLocation());
        loc.addView(set, lp(MP, WC, 12));
        TextView gps = buttonLight("📍 Dùng vị trí GPS hiện tại");
        gps.setOnClickListener(v -> useGps());
        loc.addView(gps, lp(MP, WC, 8));
        TextView refresh = buttonLight("Cập nhật thời tiết");
        refresh.setOnClickListener(v -> fetchWeather());
        loc.addView(refresh, lp(MP, WC, 8));
        loc.addView(tv("Dữ liệu từ Open-Meteo, lưới dự báo vài km nên GPS hoặc phường/xã cho kết quả sát nhất.", 12, GRAY, false), lp(WC, WC, 10));

        loadProvinces(ps, ws);

        WeatherClient.Data w = WeatherClient.load(this);
        LinearLayout cur = card();
        cur.addView(section("HIỆN TẠI"));
        if (!w.ok) {
            cur.addView(tv("Chưa có dữ liệu. Bấm \"Cập nhật thời tiết\" (cần kết nối mạng).", 16, GRAY, false), lp(WC, WC, 8));
            return;
        }
        cur.addView(tv(Math.round(w.temp) + "°C", 54, DARK, true), lp(WC, WC, 4));
        cur.addView(tv(WeatherClient.describe(w.code) + " · Thấp " + Math.round(w.tmin) + "° – Cao " + Math.round(w.tmax) + "°", 17, GRAY, false));
        Calendar tc = Calendar.getInstance();
        tc.setTimeInMillis(w.time);
        cur.addView(tv(String.format(Locale.US, "Cập nhật lúc %02d:%02d", tc.get(Calendar.HOUR_OF_DAY), tc.get(Calendar.MINUTE)), 13, GRAY, false), lp(WC, WC, 6));

        LinearLayout fc = card();
        fc.addView(section("DỰ BÁO " + w.days + " NGÀY"));
        for (int i = 0; i < w.days; i++) {
            String[] p = w.dates[i].split("-");
            int yy = Integer.parseInt(p[0]), mm = Integer.parseInt(p[1]), dd = Integer.parseInt(p[2]);
            int dw = new GregorianCalendar(yy, mm - 1, dd).get(Calendar.DAY_OF_WEEK) - 1;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(tv(i == 0 ? "Hôm nay" : WidgetRenderer.DOW_LONG[dw] + " " + dd + "/" + mm, 15, DARK, true), new LinearLayout.LayoutParams(0, WC, 1.1f));
            row.addView(tv(WeatherClient.describe(w.codes[i]), 15, GRAY, false), new LinearLayout.LayoutParams(0, WC, 1));
            TextView range = tv(Math.round(w.mins[i]) + "° / " + Math.round(w.maxs[i]) + "°", 15, DARK, true);
            range.setGravity(Gravity.END);
            row.addView(range, new LinearLayout.LayoutParams(0, WC, 0.8f));
            fc.addView(row, lp(MP, WC, 12));
        }
    }

    /** Tải danh sách tỉnh, rồi phường/xã của tỉnh đang chọn (chạy nền, có cache). */
    void loadProvinces(final Spinner ps, final Spinner ws) {
        ws.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Đang tải..."}));
        ps.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Đang tải..."}));
        new Thread(() -> {
            final List<GeoClient.Item> list = GeoClient.provinces(getApplicationContext());
            ui.post(() -> {
                if (provSpinner != ps) return;
                if (list.isEmpty()) {
                    ps.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Không tải được (kiểm tra mạng)"}));
                    return;
                }
                provList = list;
                ArrayAdapter<GeoClient.Item> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list);
                ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                ps.setAdapter(ad);
                int sel = 0;
                for (int i = 0; i < list.size(); i++) if (list.get(i).code == Prefs.provinceCode(this)) sel = i;
                ps.setSelection(sel);
                loadedProv = -1;
                ps.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                        loadWards(list.get(pos).code, ws);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) { }
                });
            });
        }).start();
    }

    void loadWards(final int provCode, final Spinner ws) {
        if (provCode == loadedProv && !wardList.isEmpty()) return;
        loadedProv = provCode;
        ws.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Đang tải..."}));
        new Thread(() -> {
            final List<GeoClient.Item> list = GeoClient.wards(getApplicationContext(), provCode);
            ui.post(() -> {
                if (wardSpinner != ws || loadedProv != provCode) return;
                wardList = list;
                if (list.isEmpty()) {
                    ws.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Không tải được danh sách"}));
                    return;
                }
                ArrayAdapter<GeoClient.Item> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list);
                ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                ws.setAdapter(ad);
                if (provCode == Prefs.provinceCode(this)) {
                    for (int i = 0; i < list.size(); i++) if (list.get(i).code == Prefs.wardCode(this)) ws.setSelection(i);
                }
            });
        }).start();
    }

    void applyAdminLocation() {
        if (provSpinner == null || wardSpinner == null || wardList.isEmpty() || provList.isEmpty()) {
            toast("Chờ danh sách tải xong rồi chọn tỉnh và phường/xã");
            return;
        }
        final GeoClient.Item prov = provList.get(provSpinner.getSelectedItemPosition());
        final GeoClient.Item ward = wardList.get(Math.min(wardSpinner.getSelectedItemPosition(), wardList.size() - 1));
        toast("Đang định vị " + ward.name + "...");
        new Thread(() -> {
            final double[] r = GeoClient.geocode(ward.name, prov.name);
            if (r != null) {
                Prefs.setLocation(getApplicationContext(), r[0], r[1], ward.name + ", " + prov.name, (int) r[2], prov.code, ward.code);
                WeatherClient.fetch(getApplicationContext());
            }
            ui.post(() -> {
                if (r == null) { toast("Không tìm được tọa độ, kiểm tra mạng rồi thử lại"); return; }
                if ((int) r[2] == 1) toast("Không thấy phường/xã này trên bản đồ, dùng tâm tỉnh/thành");
                WidgetProvider.updateAll(this);
                showTab(1);
            });
        }).start();
    }

    void fetchWeather() {
        toast("Đang cập nhật thời tiết...");
        new Thread(() -> {
            final boolean ok = WeatherClient.fetch(getApplicationContext());
            ui.post(() -> {
                if (!ok) toast("Không lấy được thời tiết, hãy kiểm tra mạng");
                WidgetProvider.updateAll(this);
                if (tab == 1 || tab == 3) showTab(tab);
            });
        }).start();
    }

    void useGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GPS);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location best = null;
        for (String p : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (SecurityException ignored) { }
        }
        if (best == null) {
            toast("Chưa lấy được vị trí. Hãy bật Vị trí trên máy rồi thử lại");
            return;
        }
        final double lat = best.getLatitude(), lon = best.getLongitude();
        toast("Đang cập nhật theo GPS...");
        new Thread(() -> {
            String label = GeoClient.reverse(lat, lon);
            if (label == null) label = "Vị trí hiện tại";
            Prefs.setLocation(getApplicationContext(), lat, lon, label, 3, 0, 0);
            WeatherClient.fetch(getApplicationContext());
            ui.post(() -> {
                WidgetProvider.updateAll(this);
                showTab(1);
            });
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_GPS) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) useGps();
            else toast("Cần cấp quyền vị trí để dùng GPS");
        }
    }

    // ---------------- Tab 3: Giá cả ----------------
    void priceTab() {
        LinearLayout sw = card();
        sw.addView(section("HIỂN THỊ TRÊN WIDGET GIÁ"));
        addSwitch(sw, "☕ Giá cà phê (theo tỉnh)", Prefs.priceCoffee(this), (b, on) -> { Prefs.setPriceCoffee(this, on); priceChanged(on); });
        addSwitch(sw, "🌶️ Giá hồ tiêu (theo tỉnh)", Prefs.pricePepper(this), (b, on) -> { Prefs.setPricePepper(this, on); priceChanged(on); });
        addSwitch(sw, "🥇 Giá vàng", Prefs.priceGold(this), (b, on) -> { Prefs.setPriceGold(this, on); priceChanged(on); });
        addSwitch(sw, "⛽ Giá xăng dầu", Prefs.priceFuel(this), (b, on) -> { Prefs.setPriceFuel(this, on); priceChanged(on); });
        TextView upd = button("Cập nhật giá ngay");
        upd.setOnClickListener(v -> fetchPrices());
        sw.addView(upd, lp(MP, WC, 14));

        PriceClient.Data d = PriceClient.load(this);
        StringBuilder st = new StringBuilder();
        String[] names = {"Cà phê", "Tiêu", "Vàng", "Xăng dầu"};
        boolean[] on = {Prefs.priceCoffee(this), Prefs.pricePepper(this), Prefs.priceGold(this), Prefs.priceFuel(this)};
        for (int i = 0; i < 4; i++) {
            if (!on[i] || d.status[i].length() == 0) continue;
            if (st.length() > 0) st.append("  ·  ");
            st.append(names[i]).append(": ").append(d.status[i].startsWith("OK") ? "✓" + d.status[i].substring(2) : "✗ " + d.status[i]);
        }
        if (st.length() > 0) sw.addView(tv(st.toString(), 12, GRAY, false), lp(WC, WC, 10));

        LinearLayout pv = card();
        pv.addView(section("XEM TRƯỚC WIDGET GIÁ"));
        List<Integer> tabs = PriceClient.enabledTabs(this);
        if (!tabs.isEmpty()) {
            String[] labels = new String[tabs.size()];
            for (int i = 0; i < labels.length; i++) labels[i] = WidgetRenderer.PRICE_TAB_LABEL[tabs.get(i)];
            int cur = tabs.indexOf(PriceClient.currentTab(this, tabs));
            chipGrid(pv, labels, cur, labels.length, null, null, i -> { Prefs.setPriceTab(this, tabs.get(i)); applyAndRedraw(); });
        }
        pricePreview = new ImageView(this);
        pricePreview.setAdjustViewBounds(true);
        pricePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pricePreview.setPadding(dp(4), dp(4), dp(4), dp(4));
        pricePreview.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3A4A78, 0xFF6C5A9A, 0xFF8E5BA8}));
        pricePreview.setImageBitmap(WidgetRenderer.renderPrices(this, 840, 560));
        pv.addView(pricePreview, lp(MP, WC, 12));
        pv.addView(tv("Trên màn hình chính, chạm vào thanh tab ở đáy widget để chuyển tab, chạm ⟳ góc phải-trên để làm mới.", 13, GRAY, false), lp(WC, WC, 10));

        if (!d.any()) {
            LinearLayout none = card();
            none.addView(tv("Chưa có dữ liệu. Bấm \"Cập nhật giá ngay\" (cần mạng).", 16, GRAY, false));
            return;
        }
        if (Prefs.priceCoffee(this) && !d.coffee.isEmpty()) addRegionCard("CÀ PHÊ", "đ/kg", d.coffee);
        if (Prefs.pricePepper(this) && !d.pepper.isEmpty()) addRegionCard("HỒ TIÊU", "đ/kg", d.pepper);
        if (Prefs.priceGold(this) && !d.gold.isEmpty()) {
            LinearLayout g = card();
            g.addView(section("GIÁ VÀNG · " + d.gold.size() + " LOẠI (triệu đồng/lượng)"));
            for (PriceClient.Item it : d.gold) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.addView(tv(it.name, 14, DARK, false), new LinearLayout.LayoutParams(0, WC, 1));
                row.addView(tv("mua " + PriceClient.fmtMillion(it.v1) + " · bán " + PriceClient.fmtMillion(it.v2), 14, DARK, true));
                g.addView(row, lp(MP, WC, 8));
            }
        }
        if (Prefs.priceFuel(this) && !d.fuel.isEmpty()) {
            LinearLayout f = card();
            f.addView(section("XĂNG DẦU PETROLIMEX (đ/lít)"));
            for (PriceClient.Item it : d.fuel) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.addView(tv(it.name, 14, DARK, false), new LinearLayout.LayoutParams(0, WC, 1));
                String v2 = it.v2 > 0 ? PriceClient.fmt(it.v2) : "-";
                row.addView(tv("V1 " + PriceClient.fmt(it.v1) + " · V2 " + v2, 14, DARK, true));
                f.addView(row, lp(MP, WC, 8));
            }
            if (d.fuelDate.length() > 0) f.addView(tv("Cập nhật: " + d.fuelDate, 13, GRAY, false), lp(WC, WC, 10));
            f.addView(tv("Theo Petrolimex chỉ có 2 vùng giá. Vùng 1: nội địa. Vùng 2: miền núi, hải đảo và các tỉnh xa kho "
                    + "(gồm Lâm Đồng, Gia Lai, Đắk Lắk, Đắk Nông, Kon Tum...), cao hơn vùng 1 khoảng 2%.", 12, GRAY, false), lp(WC, WC, 6));
        }
        LinearLayout dg = card();
        dg.addView(section("CHẨN ĐOÁN GIACAPHE.COM"));
        dg.addView(tv("Nếu cà phê vẫn thiếu tỉnh: bấm nút bên dưới, sao chép kết quả rồi gửi cho tác giả để chỉnh đúng theo trang.", 13, GRAY, false), lp(WC, WC, 6));
        TextView dbtn = buttonLight("Kiểm tra giacaphe.com");
        dbtn.setOnClickListener(v -> runDiagnose());
        dg.addView(dbtn, lp(MP, WC, 10));
        page.addView(tv("Nguồn baolamdong.vn, webgia.com và giacaphe.com, chỉ mang tính tham khảo; giá thực tế tuỳ nơi và đại lý.", 12, GRAY, false), lp(WC, WC, 12));
    }

    void addRegionCard(String title, String unit, List<PriceClient.Item> items) {
        LinearLayout c = card();
        c.addView(section(title + " (" + unit + ")"));
        for (PriceClient.Item it : items) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(tv(it.name, 15, DARK, false), new LinearLayout.LayoutParams(0, WC, 1));
            String ch = it.v2 == 0 ? "" : (it.v2 > 0 ? "  ▲" : "  ▼") + PriceClient.fmt(Math.abs(it.v2));
            TextView val = tv(PriceClient.fmt(it.v1) + ch, 15, DARK, true);
            val.setGravity(Gravity.END);
            row.addView(val);
            c.addView(row, lp(MP, WC, 8));
        }
    }

    void priceChanged(boolean turnedOn) {
        WidgetProvider.updateAll(this);
        showTab(2);
        if (turnedOn) fetchPrices();
    }

    void runDiagnose() {
        toast("Đang kiểm tra...");
        new Thread(() -> {
            final String r = PriceClient.diagnose();
            ui.post(() -> {
                TextView t = tv(r, 11, DARK, false);
                t.setTextIsSelectable(true);
                t.setPadding(dp(16), dp(8), dp(16), dp(8));
                ScrollView sv = new ScrollView(this);
                sv.addView(t);
                new AlertDialog.Builder(this)
                        .setTitle("Kết quả kiểm tra")
                        .setView(sv)
                        .setPositiveButton("Sao chép", (d, w) -> {
                            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText("giacaphe", r)); toast("Đã sao chép"); }
                        })
                        .setNegativeButton("Đóng", null)
                        .show();
            });
        }).start();
    }

    void fetchPrices() {
        if (!PriceClient.anyEnabled(this)) { toast("Hãy bật ít nhất một mục"); return; }
        toast("Đang cập nhật giá...");
        new Thread(() -> {
            final boolean ok = PriceClient.fetch(getApplicationContext());
            ui.post(() -> {
                if (!ok) toast("Không lấy được giá, xem trạng thái bên dưới");
                WidgetProvider.updateAll(this);
                if (tab == 2) showTab(2);
            });
        }).start();
    }

    // ---------------- Tab 4: Tùy chỉnh ----------------
    void customTab() {
        // --- xem trước ---
        LinearLayout pv = card();
        pv.addView(section("XEM TRƯỚC TRỰC TIẾP"));
        pv.addView(tv("Cỡ widget", 13, GRAY, true), lp(WC, WC, 10));
        chipGrid(pv, PREVIEW_NAMES, Prefs.previewSize(this), 3, null, null, i -> { Prefs.setPreviewSize(this, i); showTab(3); });
        pv.addView(tv("Giao diện", 13, GRAY, true), lp(WC, WC, 12));
        chipGrid(pv, new String[]{"Chuẩn · Sáng", "Chuẩn · Tối", "Liquid Glass"}, Prefs.theme(this), 3, null, null,
                i -> { Prefs.setTheme(this, i); applyAndRedraw(); });
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setPadding(dp(4), dp(4), dp(4), dp(4));
        preview.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3A4A78, 0xFF6C5A9A, 0xFF8E5BA8}));
        renderMainPreview();
        pv.addView(preview, lp(MP, WC, 12));
        pv.addView(tv("Mọi thay đổi áp dụng ngay lên widget ngoài màn hình chính. Kéo cạnh widget để đổi cỡ, chữ tự co giãn.", 13, GRAY, false), lp(WC, WC, 10));

        // --- công tắc hiển thị trên widget ---
        LinearLayout lc = card();
        lc.addView(section("HIỂN THỊ TRÊN WIDGET"));
        addSwitch(lc, "Giờ 24 giờ", Prefs.is24h(this), (b, on) -> { Prefs.set24h(this, on); redrawOnly(); });
        addSwitch(lc, "Dòng thứ, ngày, tháng (dưới đồng hồ)", Prefs.showDateLine(this), (b, on) -> { Prefs.setShowDateLine(this, on); redrawOnly(); });
        addSwitch(lc, "Dải lịch tuần (dưới cùng widget)", Prefs.showWeek(this), (b, on) -> { Prefs.setShowWeek(this, on); redrawOnly(); });
        addSwitch(lc, "Âm lịch", Prefs.showLunar(this), (b, on) -> { Prefs.setShowLunar(this, on); redrawOnly(); });
        addSwitch(lc, "Nhắc Rằm / Mùng Một (Nay 14, Mai là Rằm)", Prefs.showHint(this), (b, on) -> { Prefs.setShowHint(this, on); redrawOnly(); });
        addSwitch(lc, "Con giáp của năm", Prefs.showAnimal(this), (b, on) -> { Prefs.setShowAnimal(this, on); redrawOnly(); });
        addSwitch(lc, "Cung hoàng đạo", Prefs.showZodiac(this), (b, on) -> { Prefs.setShowZodiac(this, on); redrawOnly(); });
        lc.addView(tv("Ô thông số hệ thống (kiểu mới) — các ô tự co giãn cho vừa số mục bạn bật", 13, GRAY, true), lp(WC, WC, 16));
        addSwitch(lc, "Pin", Prefs.statPin(this), (b, on) -> { Prefs.setStatPin(this, on); redrawOnly(); });
        addSwitch(lc, "Nhiệt độ máy", Prefs.statTemp(this), (b, on) -> { Prefs.setStatTemp(this, on); redrawOnly(); });
        addSwitch(lc, "RAM", Prefs.statRam(this), (b, on) -> { Prefs.setStatRam(this, on); redrawOnly(); });
        addSwitch(lc, "Bộ nhớ (ổ cứng)", Prefs.statDisk(this), (b, on) -> { Prefs.setStatDisk(this, on); redrawOnly(); });

        // --- ảnh nền ---
        LinearLayout bg = card();
        bg.addView(section("ẢNH NỀN"));
        int cur = Prefs.bg(this);
        String[] bgLabels = new String[WidgetRenderer.BG_NAMES.length + 1];
        int[] bgDots = new int[bgLabels.length];
        for (int i = 0; i < WidgetRenderer.BG_NAMES.length; i++) {
            bgLabels[i] = WidgetRenderer.BG_NAMES[i];
            bgDots[i] = i == 0 ? 0 : WidgetRenderer.BG_PRESETS[i][0];
        }
        bgLabels[bgLabels.length - 1] = "Ảnh của bạn";
        int curIdx = cur == WidgetRenderer.BG_IMAGE ? bgLabels.length - 1 : Math.min(cur, bgLabels.length - 2);
        chipGrid(bg, bgLabels, curIdx, 3, null, bgDots, i -> {
            if (i == bgLabels.length - 1) {
                if (WidgetRenderer.bgFile(this).exists()) { Prefs.setBg(this, WidgetRenderer.BG_IMAGE); applyAndRedraw(); }
                else pickBackground();
            } else { Prefs.setBg(this, i); applyAndRedraw(); }
        });
        TextView pick = buttonLight("🖼️ Chọn ảnh từ máy");
        pick.setOnClickListener(v -> pickBackground());
        bg.addView(pick, lp(MP, WC, 12));
        bg.addView(tv("Độ trong suốt của nền widget", 13, GRAY, true), lp(WC, WC, 14));
        SeekBar tb = new SeekBar(this);
        tb.setMax(95);
        tb.setProgress(Prefs.transparency(this));
        tb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) { Prefs.setTransparency(MainActivity.this, p); redrawOnly(); } }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        bg.addView(tb, lp(MP, WC, 4));
        if (cur != 0) {
            bg.addView(tv("Độ tối của nền (giúp chữ dễ đọc)", 13, GRAY, true), lp(WC, WC, 14));
            SeekBar sb = new SeekBar(this);
            sb.setMax(80);
            sb.setProgress(Prefs.bgDim(this));
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) { Prefs.setBgDim(MainActivity.this, p); redrawOnly(); } }
                @Override public void onStartTrackingTouch(SeekBar s) { }
                @Override public void onStopTrackingTouch(SeekBar s) { }
            });
            bg.addView(sb, lp(MP, WC, 4));
        }

        // --- font & màu giờ ---
        LinearLayout ft = card();
        ft.addView(section("ĐỒNG HỒ: KIỂU · CỠ · FONT · MÀU"));
        ft.addView(tv("Kiểu đồng hồ", 13, GRAY, true), lp(WC, WC, 10));
        chipGrid(ft, new String[]{"Số (chuẩn)", "Lật số (flip)"}, Prefs.clockStyle(this), 2, null, null, i -> { Prefs.setClockStyle(this, i); applyAndRedraw(); });
        ft.addView(tv("Cỡ chữ đồng hồ", 13, GRAY, true), lp(WC, WC, 14));
        SeekBar cs = new SeekBar(this);
        cs.setMax(70);
        cs.setProgress(Math.max(0, Math.min(70, Prefs.clockScale(this) - 50)));
        cs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb2, int p, boolean user) { if (user) { Prefs.setClockScale(MainActivity.this, 50 + p); redrawOnly(); } }
            @Override public void onStartTrackingTouch(SeekBar sb2) { }
            @Override public void onStopTrackingTouch(SeekBar sb2) { }
        });
        ft.addView(cs, lp(MP, WC, 4));
        ft.addView(tv("Font", 13, GRAY, true), lp(WC, WC, 14));
        Typeface[] faces = new Typeface[WidgetRenderer.FONT_NAMES.length];
        for (int i = 0; i < faces.length; i++) faces[i] = WidgetRenderer.faceFor(this, i);
        chipGrid(ft, WidgetRenderer.FONT_NAMES, Prefs.font(this), 3, faces, null, i -> {
            if (i == 9 && !WidgetRenderer.fontFile(this).exists()) { pickFont(); return; }
            Prefs.setFont(this, i);
            applyAndRedraw();
        });
        TextView pf = buttonLight("🔤 Nhập font của bạn (.ttf / .otf)");
        pf.setOnClickListener(v -> pickFont());
        ft.addView(pf, lp(MP, WC, 12));
        ft.addView(tv("Muốn giống iPhone: nhập font SF Pro / SF Pro Rounded nếu bạn có file font.", 12, GRAY, false), lp(WC, WC, 6));
        ft.addView(tv("Màu giờ", 13, GRAY, true), lp(WC, WC, 14));
        int[] colDots = new int[WidgetRenderer.TIME_COLORS.length];
        for (int i = 1; i < colDots.length; i++) colDots[i] = WidgetRenderer.TIME_COLORS[i] == 0xFFFFFFFF ? 0xFF9CA3AF : WidgetRenderer.TIME_COLORS[i];
        chipGrid(ft, WidgetRenderer.TIME_COLOR_NAMES, Prefs.timeColor(this), 3, null, colDots, i -> { Prefs.setTimeColor(this, i); applyAndRedraw(); });

        // --- tên hiển thị ---
        LinearLayout nm = card();
        nm.addView(section("TÊN HIỂN THỊ TRÊN GIỜ"));
        addSwitch(nm, "Hiện tên", Prefs.nameOn(this), (b, on) -> { Prefs.setNameOn(this, on); redrawOnly(); });
        EditText et = new EditText(this);
        et.setHint("Ví dụ: Nhà của Trường");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        et.setText(Prefs.name(this));
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { Prefs.setName(MainActivity.this, e.toString()); redrawOnly(); }
        });
        nm.addView(et, lp(MP, WC, 8));

        // --- kiểu widget ---
        LinearLayout st = card();
        st.addView(section("KIỂU HIỂN THỊ WIDGET"));
        addStyleOption(st, 0, "Kiểu mới · Thông số hệ thống", "Pin, nhiệt độ máy, RAM, ổ cứng cập nhật realtime");
        addStyleOption(st, 1, "Kiểu cổ điển · Thời tiết", "Thời tiết kèm pin và nhiệt độ máy");
    }

    void addStyleOption(LinearLayout parent, final int idx, String title, String desc) {
        boolean on = Prefs.style(this) == idx;
        LinearLayout o = new LinearLayout(this);
        o.setOrientation(LinearLayout.VERTICAL);
        o.setPadding(dp(16), dp(14), dp(16), dp(14));
        o.setBackground(shape(on ? 0xFFE8EFFF : 0xFFFFFFFF, 20, on ? BLUE : 0xFFE5E9F2));
        o.addView(tv(title, 17, DARK, true));
        o.addView(tv(desc, 14, GRAY, false), lp(WC, WC, 3));
        o.setOnClickListener(v -> { Prefs.setStyle(this, idx); applyAndRedraw(); });
        parent.addView(o, lp(MP, WC, 10));
    }

    void renderMainPreview() {
        if (preview == null) return;
        int[] px = PREVIEW_PX[Math.max(0, Math.min(2, Prefs.previewSize(this)))];
        preview.setImageBitmap(WidgetRenderer.render(this, px[0], px[1]));
    }

    void refreshPreviews() {
        renderMainPreview();
        if (pricePreview != null) pricePreview.setImageBitmap(WidgetRenderer.renderPrices(this, 840, 560));
    }

    /** Đổi lựa chọn có chip: vẽ lại cả tab để cập nhật trạng thái chọn. */
    void applyAndRedraw() {
        WidgetProvider.updateAll(this);
        showTab(tab);
    }

    /** Đổi công tắc/nhập chữ: chỉ vẽ lại ảnh xem trước và widget. */
    void redrawOnly() {
        WidgetProvider.updateAll(this);
        refreshPreviews();
    }

    // ---------------- chọn ảnh nền / font ----------------
    void pickBackground() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try { startActivityForResult(i, REQ_BG); } catch (Exception e) { toast("Máy không có trình chọn ảnh"); }
    }

    void pickFont() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, REQ_FONT); } catch (Exception e) { toast("Máy không có trình chọn tệp"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        if (req == REQ_BG) {
            new Thread(() -> {
                final boolean ok = importBackground(u);
                ui.post(() -> {
                    if (ok) { Prefs.setBg(this, WidgetRenderer.BG_IMAGE); applyAndRedraw(); }
                    else toast("Không đọc được ảnh này");
                });
            }).start();
        } else if (req == REQ_FONT) {
            new Thread(() -> {
                final boolean ok = importFont(u);
                ui.post(() -> {
                    if (ok) { Prefs.setFont(this, 9); applyAndRedraw(); }
                    else toast("File font không hợp lệ");
                });
            }).start();
        }
    }

    boolean importBackground(Uri u) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / s > 1600) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            Bitmap b;
            try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) return false;
            try (FileOutputStream out = new FileOutputStream(WidgetRenderer.bgFile(this))) { b.compress(Bitmap.CompressFormat.JPEG, 88, out); }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    boolean importFont(Uri u) {
        File f = WidgetRenderer.fontFile(this);
        try {
            try (InputStream in = getContentResolver().openInputStream(u); OutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (f.length() < 1024) { f.delete(); return false; }
            Typeface.createFromFile(f);
            return true;
        } catch (Throwable t) {
            f.delete();
            return false;
        }
    }

    // ---------------- Tab 5: Hướng dẫn ----------------
    void guideTab() {
        LinearLayout dn = card();
        dn.addView(section("ỦNG HỘ TÁC GIẢ"));
        dn.addView(tv("🍿 Gói Bim Bim", 22, DARK, true), lp(WC, WC, 8));
        dn.addView(tv("Nếu thấy app hữu ích, mời tác giả một gói bim bim nhé. Cảm ơn bạn rất nhiều!", 14, GRAY, false), lp(WC, WC, 4));
        dn.addView(tv("Ngân hàng: MB Bank", 16, DARK, false), lp(WC, WC, 14));
        dn.addView(tv("Số tài khoản: 220011026789", 20, BLUE, true), lp(WC, WC, 4));
        TextView copy = buttonLight("Sao chép số tài khoản");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText("MB Bank", "220011026789")); toast("Đã sao chép số tài khoản"); }
        });
        dn.addView(copy, lp(MP, WC, 10));
        dn.addView(tv("Hoặc quét mã QR:", 14, GRAY, true), lp(WC, WC, 14));
        ImageView qr = new ImageView(this);
        qr.setImageResource(R.drawable.donate_qr);
        qr.setAdjustViewBounds(true);
        qr.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams qp = lp(dp(240), dp(240), 8);
        qp.gravity = Gravity.CENTER_HORIZONTAL;
        dn.addView(qr, qp);
        LinearLayout g = card();
        g.addView(section("THÊM WIDGET RA MÀN HÌNH"));
        String[] steps = {
                "1. Nhấn giữ vùng trống trên màn hình chính, chọn \"Widget\".",
                "2. Tìm \"Widget Lịch\" (lịch + đồng hồ) hoặc \"Widget Giá\" (cà phê, tiêu, vàng, xăng dầu) rồi kéo ra màn hình.",
                "3. Chạm vào widget để mở app, chạm nút ⟳ ở góc phải-trên để làm mới thời tiết và giá."};
        for (String s : steps) g.addView(tv(s, 16, DARK, false), lp(WC, WC, 8));

        LinearLayout t = card();
        t.addView(section("MẸO"));
        String[] tips = {
                "• Kéo cạnh widget để phóng to / thu nhỏ: bố cục và cỡ chữ tự co giãn.",
                "• Widget Giá có 3 tab (Cà phê/Tiêu, Vàng, Xăng dầu): chạm thanh tab ở đáy widget để chuyển; tab Vàng nhiều loại thì chạm lại tab Vàng để sang trang kế.",
                "• Thời tiết: chọn tỉnh và phường/xã ở tab Thời tiết; GPS cho vị trí sát nhất.",
                "• Tab Tùy chỉnh: giao diện, ảnh nền, độ trong suốt, font và màu giờ, tên hiển thị, con giáp, cung hoàng đạo.",
                "• Nếu widget không nhảy giờ đều, hãy tắt tối ưu hóa pin cho ứng dụng trong Cài đặt máy.",
                "• Âm lịch tính theo múi giờ Việt Nam (UTC+7), có đánh dấu ngày lễ chính."};
        for (String s : tips) t.addView(tv(s, 15, GRAY, false), lp(WC, WC, 8));

    }
}
