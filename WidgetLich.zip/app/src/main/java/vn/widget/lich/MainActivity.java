package vn.widget.lich;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final int BLUE = 0xFF2563EB, DARK = 0xFF111827, GRAY = 0xFF6B7280, RED = 0xFFDC2626, BG = 0xFFF3F5FA;
    static final String[] TAB_ICON = {"📅", "⛅", "🎨", "📖"};
    static final String[] TAB_NAME = {"Lịch Việt", "Thời tiết", "Tùy chỉnh", "Hướng dẫn"};

    final Handler ui = new Handler(Looper.getMainLooper());
    LinearLayout page;
    final LinearLayout[] navItems = new LinearLayout[4];
    int tab = 0, calY, calM, selD;
    ImageView preview;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(8), dp(16), dp(24));
        sv.addView(page, new ViewGroup.LayoutParams(MP, WC));
        root.addView(sv, new LinearLayout.LayoutParams(MP, 0, 1));
        root.addView(buildNav(), new LinearLayout.LayoutParams(MP, WC));
        setContentView(root);

        Calendar c = Calendar.getInstance();
        calY = c.get(Calendar.YEAR);
        calM = c.get(Calendar.MONTH);
        selD = c.get(Calendar.DAY_OF_MONTH);
        showTab(0);

        new Thread(() -> {
            WeatherClient.refreshIfStale(getApplicationContext());
            ui.post(() -> {
                WidgetProvider.updateAll(this);
                if (tab == 1) showTab(1);
            });
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        WidgetProvider.updateAll(this);
        WidgetProvider.scheduleNext(this);
        if (preview != null && tab == 2) preview.setImageBitmap(WidgetRenderer.render(this));
    }

    // ---------------- helpers ----------------
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable shape(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1.5f), stroke);
        return g;
    }

    TextView tv(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout.LayoutParams lp(int w, int h, float top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(16), dp(18), dp(18));
        l.setBackground(shape(0xFFFFFFFF, 26, 0xFFE5E9F2));
        page.addView(l, lp(MP, WC, 14));
        return l;
    }

    TextView section(String s) {
        TextView t = tv(s, 13, 0xFF4B5563, true);
        t.setLetterSpacing(0.1f);
        return t;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    TextView pill(String s, boolean on) {
        TextView t = tv(s, 16, on ? BLUE : 0xFF374151, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(10), dp(8), dp(10));
        t.setBackground(shape(on ? 0xFFE8EFFF : 0xFFFFFFFF, 22, on ? BLUE : 0xFFD1D5DB));
        return t;
    }

    TextView button(String s) {
        TextView t = tv(s, 16, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(13), dp(16), dp(13));
        t.setBackground(shape(BLUE, 16, 0));
        return t;
    }

    // ---------------- điều hướng ----------------
    View buildNav() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0xFFFFFFFF);
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            it.addView(tv(TAB_ICON[i], 24, DARK, false));
            TextView name = tv(TAB_NAME[i], 12, GRAY, true);
            name.setGravity(Gravity.CENTER);
            it.addView(name);
            it.setOnClickListener(v -> showTab(idx));
            navItems[i] = it;
            bar.addView(it, new LinearLayout.LayoutParams(0, WC, 1));
        }
        return bar;
    }

    void showTab(int t) {
        tab = t;
        for (int i = 0; i < 4; i++) {
            boolean on = i == t;
            navItems[i].setBackground(on ? shape(0xFFE8EFFF, 18, 0) : null);
            ((TextView) navItems[i].getChildAt(1)).setTextColor(on ? BLUE : GRAY);
        }
        preview = null;
        page.removeAllViews();
        page.addView(header(), lp(MP, WC, 8));
        if (t == 0) calendarTab();
        else if (t == 1) weatherTab();
        else if (t == 2) customTab();
        else guideTab();
    }

    View header() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(22), dp(22), dp(22), dp(22));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF2563EB, 0xFF5B3FE0});
        g.setCornerRadius(dp(28));
        h.setBackground(g);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(tv("Widget Lịch", 28, 0xFFFFFFFF, true));
        left.addView(tv("Đồng hồ · Lịch Việt · Số liệu realtime", 14, 0xFFDDE7FF, false));
        h.addView(left, new LinearLayout.LayoutParams(0, WC, 1));
        TextView badge = tv("v1.0", 16, 0xFFFFFFFF, true);
        badge.setPadding(dp(14), dp(7), dp(14), dp(7));
        badge.setBackground(shape(0x33FFFFFF, 20, 0));
        h.addView(badge);
        return h;
    }

    // ---------------- Tab 1: Lịch Việt ----------------
    void calendarTab() {
        LinearLayout card = card();
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView prev = tv("◀", 20, BLUE, true), next = tv("▶", 20, BLUE, true);
        prev.setPadding(dp(14), dp(8), dp(14), dp(8));
        next.setPadding(dp(14), dp(8), dp(14), dp(8));
        TextView title = tv("Tháng " + (calM + 1) + "/" + calY, 20, DARK, true);
        title.setGravity(Gravity.CENTER);
        prev.setOnClickListener(v -> { calM--; if (calM < 0) { calM = 11; calY--; } selD = 1; showTab(0); });
        next.setOnClickListener(v -> { calM++; if (calM > 11) { calM = 0; calY++; } selD = 1; showTab(0); });
        nav.addView(prev);
        nav.addView(title, new LinearLayout.LayoutParams(0, WC, 1));
        nav.addView(next);
        card.addView(nav, new LinearLayout.LayoutParams(MP, WC));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            TextView t = tv(WidgetRenderer.DOW_SHORT[i], 14, i == 6 ? RED : GRAY, true);
            t.setGravity(Gravity.CENTER);
            head.addView(t, new LinearLayout.LayoutParams(0, WC, 1));
        }
        card.addView(head, lp(MP, WC, 10));

        Calendar now = Calendar.getInstance();
        Calendar first = new GregorianCalendar(calY, calM, 1);
        int offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7;
        int dim = first.getActualMaximum(Calendar.DAY_OF_MONTH);
        int rows = (offset + dim + 6) / 7;
        List<String> holidays = new ArrayList<>();
        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 7; col++) {
                final int day = r * 7 + col - offset + 1;
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                if (day >= 1 && day <= dim) {
                    int[] l = LunarCalendar.solarToLunar(day, calM + 1, calY);
                    String hol = LunarCalendar.holiday(day, calM + 1, l);
                    if (hol != null) holidays.add(day + "/" + (calM + 1) + ": " + hol);
                    boolean isToday = day == now.get(Calendar.DAY_OF_MONTH) && calM == now.get(Calendar.MONTH) && calY == now.get(Calendar.YEAR);
                    boolean sel = day == selD;
                    int numColor = isToday ? 0xFFFFFFFF : (col == 6 || hol != null ? RED : DARK);
                    cell.addView(tv(String.valueOf(day), 17, numColor, true));
                    cell.addView(tv(l[0] == 1 ? l[0] + "/" + l[1] : String.valueOf(l[0]), 11,
                            isToday ? 0xFFDDE7FF : (hol != null ? RED : GRAY), false));
                    if (isToday) cell.setBackground(shape(BLUE, 14, 0));
                    else if (sel) cell.setBackground(shape(0xFFE8EFFF, 14, BLUE));
                    cell.setOnClickListener(v -> { selD = day; showTab(0); });
                }
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(56), 1);
                p.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
                row.addView(cell, p);
            }
            card.addView(row, new LinearLayout.LayoutParams(MP, WC));
        }

        TextView today = button("Về hôm nay");
        today.setOnClickListener(v -> {
            Calendar n = Calendar.getInstance();
            calY = n.get(Calendar.YEAR);
            calM = n.get(Calendar.MONTH);
            selD = n.get(Calendar.DAY_OF_MONTH);
            showTab(0);
        });
        card.addView(today, lp(MP, WC, 12));

        int sd = Math.min(selD, dim);
        int[] sl = LunarCalendar.solarToLunar(sd, calM + 1, calY);
        int dow = new GregorianCalendar(calY, calM, sd).get(Calendar.DAY_OF_WEEK) - 1;
        LinearLayout info = card();
        info.addView(section("NGÀY ĐÃ CHỌN"));
        info.addView(tv(WidgetRenderer.DOW_LONG[dow] + ", " + sd + "/" + (calM + 1) + "/" + calY, 20, DARK, true), lp(WC, WC, 8));
        info.addView(tv("Âm lịch: " + sl[0] + " tháng " + sl[1] + (sl[3] == 1 ? " (nhuận)" : "")
                + " · năm " + LunarCalendar.canChi(sl[2]), 16, GRAY, false), lp(WC, WC, 4));
        String sh = LunarCalendar.holiday(sd, calM + 1, sl);
        if (sh != null) info.addView(tv("🎉 " + sh, 16, RED, true), lp(WC, WC, 6));

        if (!holidays.isEmpty()) {
            LinearLayout hc = card();
            hc.addView(section("NGÀY LỄ TRONG THÁNG"));
            for (String s : holidays) hc.addView(tv(s, 15, DARK, false), lp(WC, WC, 6));
        }
    }

    // ---------------- Tab 2: Thời tiết ----------------
    void weatherTab() {
        LinearLayout loc = card();
        loc.addView(section("VỊ TRÍ"));
        List<String> names = new ArrayList<>();
        for (String s : Prefs.CITY_NAMES) names.add(s);
        names.add("📍 Vị trí hiện tại (GPS)");
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setSelection(Prefs.city(this));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (pos == Prefs.city(MainActivity.this)) return;
                if (pos >= Prefs.CITY_NAMES.length) {
                    useGps();
                } else {
                    Prefs.setCity(MainActivity.this, pos);
                    fetchWeather();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        loc.addView(sp, lp(MP, WC, 6));
        TextView refresh = button("Cập nhật thời tiết");
        refresh.setOnClickListener(v -> fetchWeather());
        loc.addView(refresh, lp(MP, WC, 10));

        WeatherClient.Data w = WeatherClient.load(this);
        LinearLayout cur = card();
        cur.addView(section("HIỆN TẠI · " + Prefs.cityLabel(this).toUpperCase(Locale.ROOT)));
        if (!w.ok) {
            cur.addView(tv("Chưa có dữ liệu. Bấm \"Cập nhật thời tiết\" (cần kết nối mạng).", 16, GRAY, false), lp(WC, WC, 8));
            return;
        }
        cur.addView(tv(Math.round(w.temp) + "°C", 54, DARK, true), lp(WC, WC, 4));
        cur.addView(tv(WeatherClient.describe(w.code) + " · Thấp " + Math.round(w.tmin) + "° – Cao " + Math.round(w.tmax) + "°", 17, GRAY, false));
        Calendar tc = Calendar.getInstance();
        tc.setTimeInMillis(w.time);
        cur.addView(tv(String.format(Locale.US, "Cập nhật lúc %02d:%02d", tc.get(Calendar.HOUR_OF_DAY), tc.get(Calendar.MINUTE)), 13, GRAY, false), lp(WC, WC, 6));

        LinearLayout fc = card();
        fc.addView(section("DỰ BÁO " + w.days + " NGÀY"));
        for (int i = 0; i < w.days; i++) {
            String[] p = w.dates[i].split("-");
            int yy = Integer.parseInt(p[0]), mm = Integer.parseInt(p[1]), dd = Integer.parseInt(p[2]);
            int dw = new GregorianCalendar(yy, mm - 1, dd).get(Calendar.DAY_OF_WEEK) - 1;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView day = tv(i == 0 ? "Hôm nay" : WidgetRenderer.DOW_LONG[dw] + " " + dd + "/" + mm, 15, DARK, true);
            row.addView(day, new LinearLayout.LayoutParams(0, WC, 1.1f));
            row.addView(tv(WeatherClient.describe(w.codes[i]), 15, GRAY, false), new LinearLayout.LayoutParams(0, WC, 1));
            TextView range = tv(Math.round(w.mins[i]) + "° / " + Math.round(w.maxs[i]) + "°", 15, DARK, true);
            range.setGravity(Gravity.END);
            row.addView(range, new LinearLayout.LayoutParams(0, WC, 0.8f));
            fc.addView(row, lp(MP, WC, 12));
        }
    }

    void fetchWeather() {
        toast("Đang cập nhật thời tiết...");
        new Thread(() -> {
            final boolean ok = WeatherClient.fetch(getApplicationContext());
            ui.post(() -> {
                if (!ok) toast("Không lấy được thời tiết, hãy kiểm tra mạng");
                WidgetProvider.updateAll(this);
                if (tab == 1 || tab == 2) showTab(tab);
            });
        }).start();
    }

    void useGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 7);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location best = null;
        for (String p : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (SecurityException ignored) { }
        }
        if (best == null) {
            toast("Chưa lấy được vị trí. Hãy bật Vị trí trên máy rồi thử lại");
            showTab(1);
            return;
        }
        Prefs.setGps(this, best.getLatitude(), best.getLongitude());
        Prefs.setCity(this, Prefs.CITY_NAMES.length);
        fetchWeather();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 7) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) useGps();
            else { toast("Cần cấp quyền vị trí để dùng GPS"); showTab(1); }
        }
    }

    // ---------------- Tab 3: Tùy chỉnh ----------------
    void customTab() {
        LinearLayout pv = card();
        pv.addView(section("XEM TRƯỚC TRỰC TIẾP"));
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Chuẩn · Sáng", "Chuẩn · Tối", "Liquid Glass"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView ch = pill(names[i], Prefs.theme(this) == i);
            ch.setTextSize(14);
            ch.setOnClickListener(v -> { Prefs.setTheme(this, idx); applyAndRedraw(); });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, WC, 1);
            p.rightMargin = i < 2 ? dp(6) : 0;
            chips.addView(ch, p);
        }
        pv.addView(chips, lp(MP, WC, 10));

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setPadding(dp(4), dp(4), dp(4), dp(4));
        preview.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3A4A78, 0xFF6C5A9A, 0xFF8E5BA8}));
        preview.setImageBitmap(WidgetRenderer.render(this));
        pv.addView(preview, lp(MP, WC, 12));
        pv.addView(tv("Mọi thay đổi áp dụng ngay lên widget ngoài màn hình chính.", 14, GRAY, false), lp(WC, WC, 10));

        LinearLayout st = card();
        st.addView(section("KIỂU HIỂN THỊ WIDGET"));
        addStyleOption(st, 0, "Kiểu mới · Thông số hệ thống", "Pin, nhiệt độ máy, RAM, ổ cứng cập nhật realtime");
        addStyleOption(st, 1, "Kiểu cổ điển · Thời tiết", "Thời tiết kèm pin và nhiệt độ máy");

        LinearLayout op = card();
        op.addView(section("TÙY CHỌN"));
        addSwitch(op, "Giờ 24 giờ", Prefs.is24h(this), (b, on) -> { Prefs.set24h(this, on); redrawOnly(); });
        addSwitch(op, "Hiện âm lịch", Prefs.showLunar(this), (b, on) -> { Prefs.setShowLunar(this, on); redrawOnly(); });

        TextView add = button("＋ Thêm widget ra màn hình chính");
        add.setOnClickListener(v -> pinWidget());
        page.addView(add, lp(MP, WC, 16));
    }

    void addStyleOption(LinearLayout parent, final int idx, String title, String desc) {
        boolean on = Prefs.style(this) == idx;
        LinearLayout o = new LinearLayout(this);
        o.setOrientation(LinearLayout.VERTICAL);
        o.setPadding(dp(16), dp(14), dp(16), dp(14));
        o.setBackground(shape(on ? 0xFFE8EFFF : 0xFFFFFFFF, 20, on ? BLUE : 0xFFE5E9F2));
        o.addView(tv(title, 17, DARK, true));
        o.addView(tv(desc, 14, GRAY, false), lp(WC, WC, 3));
        o.setOnClickListener(v -> { Prefs.setStyle(this, idx); applyAndRedraw(); });
        parent.addView(o, lp(MP, WC, 10));
    }

    void addSwitch(LinearLayout parent, String label, boolean on, android.widget.CompoundButton.OnCheckedChangeListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(tv(label, 17, DARK, false), new LinearLayout.LayoutParams(0, WC, 1));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        row.addView(sw);
        parent.addView(row, lp(MP, WC, 12));
    }

    /** Đổi kiểu/giao diện: vẽ lại cả tab để cập nhật trạng thái chọn. */
    void applyAndRedraw() {
        WidgetProvider.updateAll(this);
        showTab(2);
    }

    /** Đổi công tắc: chỉ vẽ lại ảnh xem trước và widget. */
    void redrawOnly() {
        WidgetProvider.updateAll(this);
        if (preview != null) preview.setImageBitmap(WidgetRenderer.render(this));
    }

    void pinWidget() {
        AppWidgetManager m = getSystemService(AppWidgetManager.class);
        if (Build.VERSION.SDK_INT >= 26 && m != null && m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(this, WidgetProvider.class), null, null);
        } else {
            toast("Nhấn giữ màn hình chính → Widget → Widget Lịch");
        }
    }

    // ---------------- Tab 4: Hướng dẫn ----------------
    void guideTab() {
        LinearLayout g = card();
        g.addView(section("THÊM WIDGET RA MÀN HÌNH"));
        String[] steps = {
                "1. Nhấn giữ vùng trống trên màn hình chính.",
                "2. Chọn \"Widget\" rồi tìm \"Widget Lịch\".",
                "3. Kéo widget ra màn hình (hoặc bấm nút \"Thêm widget\" ở tab Tùy chỉnh).",
                "4. Chạm vào widget để mở lại ứng dụng."};
        for (String s : steps) g.addView(tv(s, 16, DARK, false), lp(WC, WC, 8));

        LinearLayout t = card();
        t.addView(section("MẸO"));
        String[] tips = {
                "• Kéo cạnh widget để phóng to hoặc thu nhỏ, giao diện tự co giãn theo.",
                "• Kiểu \"Thông số hệ thống\" hiện pin, nhiệt độ pin, RAM và ổ cứng.",
                "• Kiểu \"Thời tiết\" lấy dữ liệu miễn phí từ Open-Meteo, chọn thành phố ở tab Thời tiết.",
                "• Nếu widget không nhảy giờ, hãy tắt tối ưu hóa pin cho ứng dụng trong Cài đặt máy.",
                "• Âm lịch tính theo múi giờ Việt Nam (UTC+7), có đánh dấu ngày lễ chính."};
        for (String s : tips) t.addView(tv(s, 15, GRAY, false), lp(WC, WC, 8));
    }
}
