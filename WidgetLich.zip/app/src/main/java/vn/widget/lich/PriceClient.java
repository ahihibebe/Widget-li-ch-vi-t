package vn.widget.lich;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Giá cà phê / hồ tiêu theo tỉnh, giá vàng, giá xăng dầu.
 * Nguồn: baolamdong.vn (cà phê, tiêu, vàng) và giacaphe.com (xăng dầu, dự phòng cà phê). Chỉ mang tính tham khảo.
 */
public class PriceClient {
    static final long MAX_AGE = 30 * 60 * 1000L;
    static final long RETRY_GAP = 5 * 60 * 1000L;
    static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36";

    /** Mỗi vùng: tên hiển thị đứng đầu, sau đó là các cách viết khác trên web. */
    static final String[][] COFFEE_REGIONS = {
            {"Đắk Lắk", "Đắc Lắc", "Đăk Lăk"}, {"Gia Lai"}, {"Lâm Đồng"}, {"Đắk Nông", "Đắc Nông", "Đăk Nông"},
            {"Kon Tum"}, {"Đồng Nai"}, {"Bình Phước"}};
    static final String[][] PEPPER_REGIONS = {
            {"Đắk Lắk", "Đắc Lắc", "Đăk Lăk"}, {"Gia Lai"}, {"Lâm Đồng"}, {"Đồng Nai"}, {"Đắk Nông", "Đắc Nông", "Đăk Nông"},
            {"Bình Phước"}, {"Bà Rịa"}, {"Quảng Trị"}};

    /** Regions/fuel: v1 = giá, v2 = thay đổi (có dấu). Gold: v1 = mua vào, v2 = bán ra (đồng/lượng). */
    static class Item {
        String name;
        long v1, v2;
        Item(String n, long a, long b) { name = n; v1 = a; v2 = b; }
    }

    static class Data {
        List<Item> coffee = new ArrayList<>(), pepper = new ArrayList<>(), gold = new ArrayList<>(), fuel = new ArrayList<>();
        String fuelDate = "";
        long time;
        String[] status = {"", "", "", ""};   // cà phê, tiêu, vàng, xăng dầu
        boolean any() { return !coffee.isEmpty() || !pepper.isEmpty() || !gold.isEmpty() || !fuel.isEmpty(); }
    }

    // ---------- tiện ích ----------
    static long num(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) if (ch >= '0' && ch <= '9') b.append(ch);
        return b.length() == 0 || b.length() > 15 ? 0 : Long.parseLong(b.toString());
    }

    static String fmt(long v) {
        String s = String.valueOf(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append('.');
            b.append(s.charAt(i));
        }
        return (v < 0 ? "-" : "") + b;
    }

    /** 142000000 -> "142,0" (triệu đồng/lượng) */
    static String fmtMillion(long v) {
        return String.format(Locale.US, "%.1f", v / 1_000_000.0).replace('.', ',');
    }

    static String get(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setConnectTimeout(8000);
            con.setReadTimeout(10000);
            con.setRequestProperty("User-Agent", UA);
            con.setRequestProperty("Accept-Language", "vi-VN,vi;q=0.9");
            int code = con.getResponseCode();
            if (code >= 400) throw new Exception("HTTP " + code);
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) > 0) {
                sb.append(buf, 0, n);
                if (sb.length() > 3_000_000) break;
            }
            r.close();
            return sb.toString();
        } finally {
            con.disconnect();
        }
    }

    /** HTML -> chữ: ô bảng ngăn bằng " | ", mỗi hàng một dòng. */
    static String flatten(String html) {
        String s = html.replaceAll("(?is)<script.*?</script>|<style.*?</style>|<!--.*?-->", " ");
        s = s.replaceAll("(?i)</t[dh]>", " | ").replaceAll("(?i)</tr>|<br\\s*/?>|</p>|</li>|</h\\d>|</div>", "\n");
        s = s.replaceAll("<[^>]+>", " ").replace("&nbsp;", " ").replace("&amp;", "&");
        return s.replaceAll("[ \\t\\u00A0]+", " ");
    }

    private static String shortStatus(Exception e) {
        String m = e.getMessage();
        if (m == null) m = e.getClass().getSimpleName();
        return m.length() > 40 ? m.substring(0, 40) : m;
    }

    // ---------- cà phê / tiêu theo vùng ----------
    private static String regionLabel(String name) {
        if (name.equals("Đắk Nông")) return "Đắk Nông (cũ)";
        if (name.equals("Bà Rịa")) return "Bà Rịa - Vũng Tàu";
        return name;
    }

    /**
     * Tìm giá của từng vùng. Giá phải đứng ngay sau tên vùng (hoặc trong cùng hàng bảng) và theo sau là mũi tên tăng/giảm,
     * dấu "|" hay "ổn định": nhờ vậy không bắt nhầm số trong tiêu đề tin như "Lâm Đồng vượt 85.000 đồng/kg".
     * Giá lệch quá 12% so với trung vị sẽ bị loại.
     */
    static List<Item> parseRegions(String text, String[][] regions, long min, long max) {
        text = Normalizer.normalize(text, Normalizer.Form.NFC);
        String flat = text.replace('\n', ' ');
        String price = "(\\d{2,3}[.,]\\d{3})(?!\\d)";
        String look = "(?=\\s*(?:[↓↑▼▲|—–]|giảm|tăng|ổn định|đi ngang))";
        String chg = "(?:(?:\\s*\\|)?\\s*([↓↑▼▲]|giảm|tăng)\\s*(?:giảm|tăng)?\\s*([0-9][0-9.,]*))?";
        List<Item> out = new ArrayList<>();
        for (String[] names : regions) {
            StringBuilder alt = new StringBuilder();
            for (String n : names) { if (alt.length() > 0) alt.append('|'); alt.append(Pattern.quote(Normalizer.normalize(n, Normalizer.Form.NFC))); }
            // không tính khi tên vùng chỉ xuất hiện trong chú thích như "hiện thuộc tỉnh Lâm Đồng"
            String pre = "(?<!tỉnh )(?<!Tỉnh )(?<!thuộc )(?:" + alt + ")";
            String[] passes = {
                    pre + "[\\s*|:]{0,6}" + price + look + chg,
                    pre + "[^0-9\\n]{0,120}?" + price + look + chg,
                    pre + "[^0-9]{0,120}?" + price + look + chg};
            String[] src = {text, text, flat};
            Item found = null;
            for (int k = 0; k < passes.length && found == null; k++) {
                Matcher m = Pattern.compile(passes[k]).matcher(src[k]);
                while (m.find()) {
                    long p = num(m.group(1));
                    if (p < min || p > max) continue;
                    long ch = 0;
                    if (m.group(3) != null) {
                        ch = num(m.group(3));
                        if (m.group(2) != null && "↓▼giảm".contains(m.group(2))) ch = -ch;
                    }
                    found = new Item(regionLabel(names[0]), p, ch);
                    break;
                }
            }
            if (found != null) out.add(found);
        }
        if (out.size() >= 3) {
            long[] v = new long[out.size()];
            for (int i = 0; i < v.length; i++) v[i] = out.get(i).v1;
            java.util.Arrays.sort(v);
            long med = v[v.length / 2];
            List<Item> keep = new ArrayList<>();
            for (Item it : out) if (Math.abs(it.v1 - med) <= med * 0.12) keep.add(it);
            out = keep;
        }
        return out;
    }

    /** Thử lần lượt các địa chỉ, lấy danh sách có nhiều vùng nhất. */
    static List<Item> fetchRegions(String[] urls, String[][] regions, long min, long max) throws Exception {
        Exception last = null;
        List<Item> best = new ArrayList<>();
        for (String u : urls) {
            try {
                List<Item> r = parseRegions(flatten(get(u)), regions, min, max);
                if (r.size() > best.size()) best = r;
                if (best.size() >= 4) break;
            } catch (Exception e) {
                last = e;
            }
        }
        if (best.isEmpty()) throw last == null ? new Exception("không đọc được bảng giá") : last;
        return best;
    }

    // ---------- giacaphe.com ----------
    private static String metaDesc(String html) {
        Matcher m = Pattern.compile("<meta[^>]+name=[\"']description[\"'][^>]+content=[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE).matcher(html);
        if (m.find()) return m.group(1);
        m = Pattern.compile("content=[\"']([^\"']*)[\"'][^>]+name=[\"']description[\"']", Pattern.CASE_INSENSITIVE).matcher(html);
        return m.find() ? m.group(1) : "";
    }

    private static String titleOf(String html) {
        Matcher m = Pattern.compile("<title[^>]*>([^<]*)</title>", Pattern.CASE_INSENSITIVE).matcher(html);
        return m.find() ? m.group(1) : "";
    }

    /** Đổi các chuỗi \\uXXXX (dữ liệu JSON nhúng trong trang) thành chữ thật. */
    static String unescapeUnicode(String s) {
        Matcher m = Pattern.compile("\\\\u([0-9a-fA-F]{4})").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(m.group(1), 16))));
        m.appendTail(sb);
        return sb.toString();
    }

    /** Tìm "tên vùng ... giá" trong dữ liệu JSON/JS nhúng sẵn trong HTML. */
    static List<Item> parseEmbedded(String raw, String[][] regions, long min, long max) {
        String text = Normalizer.normalize(unescapeUnicode(raw), Normalizer.Form.NFC);
        List<Item> out = new ArrayList<>();
        for (String[] names : regions) {
            StringBuilder alt = new StringBuilder();
            for (String n : names) { if (alt.length() > 0) alt.append('|'); alt.append(Pattern.quote(Normalizer.normalize(n, Normalizer.Form.NFC))); }
            Matcher m = Pattern.compile("(?<!tỉnh )(?<!Tỉnh )(?<!thuộc )(?:" + alt + ")[\"'\\s:,\\]\\}\\[]{1,12}[^0-9]{0,40}?(\\d{2,3}[.,]\\d{3}|\\d{5,6})(?!\\d)").matcher(text);
            while (m.find()) {
                long p = num(m.group(1));
                if (p >= min && p <= max) { out.add(new Item(regionLabel(names[0]), p, 0)); break; }
            }
        }
        return dropOutliers(out);
    }

    static List<Item> dropOutliers(List<Item> in) {
        if (in.size() < 3) return in;
        long[] v = new long[in.size()];
        for (int i = 0; i < v.length; i++) v[i] = in.get(i).v1;
        java.util.Arrays.sort(v);
        long med = v[v.length / 2];
        List<Item> keep = new ArrayList<>();
        for (Item it : in) if (Math.abs(it.v1 - med) <= med * 0.12) keep.add(it);
        return keep;
    }

    /**
     * giacaphe.com ghi giá vào thuộc tính data-* của hàng bảng (ví dụ data-cur="71900") rồi mới hiện bằng JavaScript,
     * nên phải đọc từ HTML gốc chứ không đọc chữ hiển thị. Mỗi hàng &lt;tr&gt; được xét riêng để không lẫn giá giữa các vùng.
     */
    static List<Item> parseDataAttrs(String raw, String[][] regions, long min, long max) {
        String text = Normalizer.normalize(unescapeUnicode(raw), Normalizer.Form.NFC);
        Pattern attr = Pattern.compile("data-([a-z0-9_\\-]+)=[\"'](\\d{4,6})(?:\\.\\d+)?[\"']", Pattern.CASE_INSENSITIVE);
        Pattern[] pats = new Pattern[regions.length];
        for (int i = 0; i < regions.length; i++) {
            StringBuilder alt = new StringBuilder();
            for (String n : regions[i]) { if (alt.length() > 0) alt.append('|'); alt.append(Pattern.quote(Normalizer.normalize(n, Normalizer.Form.NFC))); }
            pats[i] = Pattern.compile("(?<!tỉnh )(?<!Tỉnh )(?<!thuộc )(?:" + alt + ")");
        }
        Item[] found = new Item[regions.length];
        for (String seg : text.split("(?i)<tr\\b")) {
            // vùng nào xuất hiện sớm nhất trong hàng thì là vùng của hàng
            int best = -1, bestPos = Integer.MAX_VALUE;
            for (int i = 0; i < pats.length; i++) {
                Matcher m = pats[i].matcher(seg);
                if (m.find() && m.start() < bestPos) { best = i; bestPos = m.start(); }
            }
            if (best < 0 || found[best] != null) continue;
            long cur = 0, prev = 0, any = 0;
            Matcher am = attr.matcher(seg);
            while (am.find()) {
                String nm = am.group(1).toLowerCase(Locale.ROOT);
                long v = Long.parseLong(am.group(2));
                if (v < min || v > max) continue;
                if (nm.contains("pre") || nm.contains("old") || nm.contains("last") || nm.contains("yest")) { if (prev == 0) prev = v; }
                else if (nm.contains("cur") || nm.contains("price") || nm.contains("gia") || nm.contains("value")) { if (cur == 0) cur = v; }
                else if (any == 0) any = v;
            }
            long p = cur != 0 ? cur : any;
            if (p == 0) continue;
            found[best] = new Item(regionLabel(regions[best][0]), p, prev != 0 ? p - prev : 0);
        }
        List<Item> out = new ArrayList<>();
        for (Item it : found) if (it != null) out.add(it);
        return dropOutliers(out);
    }

    /** Giá trung bình ở thuộc tính data-cur đầu tiên (cách script coffee-price đọc trang chủ). */
    static long firstDataCur(String raw) {
        Matcher m = Pattern.compile("data-cur=[\"'](\\d{4,6})").matcher(raw);
        return m.find() ? Long.parseLong(m.group(1)) : 0;
    }

    /** Thử lần lượt: thuộc tỉnh data-*, chữ hiển thị trong bảng, dữ liệu JSON nhúng. */
    static List<Item> regionsFromPage(String html, String[][] regions, long min, long max) {
        List<Item> best = parseDataAttrs(html, regions, min, max);
        if (best.size() < 3) {
            List<Item> r = parseRegions(flatten(html), regions, min, max);
            if (r.size() > best.size()) best = r;
        }
        if (best.size() < 3) {
            List<Item> r = parseEmbedded(html, regions, min, max);
            if (r.size() > best.size()) best = r;
        }
        return best;
    }

    /** Báo cáo ngắn về nội dung thật mà app nhận được từ giacaphe.com (để gửi cho tác giả khi chưa hiện đủ tỉnh). */
    static String diagnose() {
        StringBuilder sb = new StringBuilder();
        for (String u : new String[]{"https://giacaphe.com/gia-ca-phe-noi-dia/", "https://giacaphe.com/gia-ca-phe-truc-tuyen/"}) {
            sb.append("== ").append(u).append('\n');
            try {
                String h = get(u);
                String n = Normalizer.normalize(h, Normalizer.Form.NFC);
                sb.append("size=").append(h.length()).append(" data-cur=").append(countOf(h, "data-cur"))
                        .append(" tr=").append(countOf(h, "<tr")).append('\n');
                for (String[] r : COFFEE_REGIONS) {
                    sb.append(r[0]).append('=').append(countOf(h, r[0])).append('/').append(countOf(n, Normalizer.normalize(r[0], Normalizer.Form.NFC))).append("  ");
                }
                sb.append('\n');
                int i = n.indexOf("Lâm Đồng");
                if (i < 0) i = n.indexOf("data-cur");
                if (i >= 0) sb.append(n, Math.max(0, i - 250), Math.min(n.length(), i + 450)).append('\n');
                else sb.append(n, 0, Math.min(500, n.length())).append('\n');
                List<Item> r = regionsFromPage(h, COFFEE_REGIONS, 20000, 400000);
                sb.append("=> đọc được ").append(r.size()).append(" vùng");
                for (Item it : r) sb.append(" | ").append(it.name).append(' ').append(it.v1);
                sb.append('\n');
            } catch (Exception e) {
                sb.append("lỗi: ").append(shortStatus(e)).append('\n');
            }
        }
        return sb.toString();
    }

    static int countOf(String hay, String needle) {
        int n = 0, i = 0;
        while ((i = hay.indexOf(needle, i)) >= 0) { n++; i += needle.length(); }
        return n;
    }

    // ghi chú nguồn để hiện ở tab Giá cả
    static final java.util.concurrent.atomic.AtomicReference<String> lastNote = new java.util.concurrent.atomic.AtomicReference<>("");
    static final java.util.concurrent.atomic.AtomicReference<String> lastNoteP = new java.util.concurrent.atomic.AtomicReference<>("");

    /** Trung bình / cao nhất lấy từ tiêu đề và mô tả của trang, cộng các vùng nếu trang có dữ liệu nhúng. */
    static List<Item> coffeeFromGiacaphe() throws Exception {
        String html = get("https://giacaphe.com/gia-ca-phe-noi-dia/");
        String desc = metaDesc(html), title = titleOf(html), body = flatten(html);
        String all = desc + " \n " + title + " \n " + body;
        List<Item> out = new ArrayList<>();
        long avg = 0, high = 0, ch = 0;
        Matcher m = Pattern.compile("trung bình[^0-9]{0,40}(\\d{2,3}[.,]\\d{3})", Pattern.CASE_INSENSITIVE).matcher(all);
        if (m.find()) avg = num(m.group(1));
        m = Pattern.compile("cao nhất[^0-9]{0,40}(\\d{2,3}[.,]\\d{3})", Pattern.CASE_INSENSITIVE).matcher(all);
        if (m.find()) high = num(m.group(1));
        m = Pattern.compile("(giảm|tăng)[^0-9+\\-]{0,25}([+\\-]?\\d[\\d.,]*)\\s*(?:đ|vnđ|đồng)", Pattern.CASE_INSENSITIVE).matcher(desc + " " + title);
        if (m.find()) ch = m.group(1).equalsIgnoreCase("giảm") ? -num(m.group(2)) : num(m.group(2));
        if (avg == 0) avg = firstDataCur(html);
        if (avg > 20000) out.add(new Item("Trung bình", avg, ch));
        if (high > 20000 && high != avg) out.add(new Item("Cao nhất", high, avg > 0 ? 0 : ch));
        List<Item> regs = regionsFromPage(html, COFFEE_REGIONS, 20000, 400000);
        if (regs.size() < 3) {   // trang cà phê trực tuyến và trang chủ của giacaphe.com
            for (String u : new String[]{"https://giacaphe.com/gia-ca-phe-truc-tuyen/", "https://giacaphe.com/"}) {
                try {
                    List<Item> r2 = regionsFromPage(get(u), COFFEE_REGIONS, 20000, 400000);
                    if (r2.size() > regs.size()) regs = r2;
                    if (regs.size() >= 3) break;
                } catch (Exception ignored) { }
            }
        }
        out.addAll(regs);
        if (out.isEmpty()) throw new Exception("không đọc được bảng giá");
        if (regs.isEmpty()) lastNote.set("giacaphe: chưa thấy vùng (data-cur=" + countOf(html, "data-cur") + ")");
        else lastNote.set("giacaphe " + regs.size() + " vùng");
        return out;
    }

    /** Hồ tiêu: giá cao nhất từ giacaphe.com (dự phòng khi bảng theo tỉnh không đọc được). */
    static List<Item> pepperFromGiacaphe() throws Exception {
        String html = get("https://giacaphe.com/gia-tieu-hom-nay/");
        String all = metaDesc(html) + " \n " + titleOf(html) + " \n " + flatten(html);
        List<Item> out = new ArrayList<>();
        Matcher m = Pattern.compile("cao nhất[^0-9]{0,40}(\\d{2,3}[.,]\\d{3})", Pattern.CASE_INSENSITIVE).matcher(all);
        if (m.find()) {
            long p = num(m.group(1));
            long ch = 0;
            Matcher d = Pattern.compile("(giảm|tăng)[^0-9+\\-]{0,25}([+\\-]?\\d[\\d.,]*)\\s*(?:đ|vnđ|đồng)", Pattern.CASE_INSENSITIVE).matcher(metaDesc(html) + " " + titleOf(html));
            if (d.find()) ch = d.group(1).equalsIgnoreCase("giảm") ? -num(d.group(2)) : num(d.group(2));
            if (p > 50000) out.add(new Item("Cao nhất", p, ch));
        }
        List<Item> regs = parseDataAttrs(html, PEPPER_REGIONS, 50000, 500000);
        if (regs.size() < 2) regs = parseEmbedded(html, PEPPER_REGIONS, 50000, 500000);
        out.addAll(regs);
        if (out.isEmpty()) throw new Exception("không đọc được bảng giá");
        lastNoteP.set(regs.isEmpty() ? "giacaphe: chưa thấy vùng (data-cur=" + countOf(html, "data-cur") + ")" : "giacaphe " + regs.size() + " vùng");
        return out;
    }

    // ---------- vàng ----------
    private static final String[][] GOLD_BRANDS = {
            {"sjc", "SJC"}, {"doji", "DOJI"}, {"pnj", "PNJ"}, {"bao-tin-minh-chau", "Bảo Tín Minh Châu"},
            {"bao-tin-manh-hai", "Bảo Tín Mạnh Hải"}, {"phu-quy", "Phú Quý"}, {"mi-hong", "Mi Hồng"}, {"ngoc-tham", "Ngọc Thẩm"}};
    private static final Pattern MONEY_CELL = Pattern.compile("^\\d{1,3}(?:\\.\\d{3}){2}$");

    /** Đọc các hàng "… | mua | bán |" của một trang webgia (đơn vị đồng/chỉ hoặc đồng/lượng), trả về đồng/lượng. */
    static List<Item> parseGoldPage(String text, String brand) {
        long factor = 0;
        Matcher u = Pattern.compile("Đơn vị:\\s*đồng\\s*/\\s*(chỉ|lượng)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (u.find()) factor = u.group(1).equalsIgnoreCase("chỉ") ? 10 : 1;
        List<Item> out = new ArrayList<>();
        for (String line : text.split("\n")) {
            String[] cells = line.split("\\|");
            for (int i = 0; i < cells.length; i++) cells[i] = cells[i].replaceAll("\\s+", " ").trim();
            for (int i = 1; i + 1 < cells.length; i++) {
                if (!MONEY_CELL.matcher(cells[i]).matches() || !MONEY_CELL.matcher(cells[i + 1]).matches()) continue;
                String label = cells[i - 1];
                if (label.length() < 3 || MONEY_CELL.matcher(label).matches()) break;
                long buy = num(cells[i]), sell = num(cells[i + 1]);
                long f = factor != 0 ? factor : (buy < 30_000_000L ? 10 : 1);
                buy *= f; sell *= f;
                if (buy < 5_000_000L || sell > 800_000_000L || sell < buy * 0.8) break;
                label = label.replaceAll("\\(.*?\\)", " ").replaceAll("\\s+", " ").trim();
                if (!label.toLowerCase(Locale.ROOT).contains(brand.toLowerCase(Locale.ROOT))) label = brand + " · " + label;
                boolean dup = false;
                for (Item x : out) if (x.name.equals(label) && x.v1 == buy && x.v2 == sell) dup = true;
                if (!dup) out.add(new Item(label, buy, sell));
                break;
            }
        }
        return out;
    }

    /** Parser cho trang tổng hợp baolamdong.vn (dùng dự phòng). */
    static List<Item> parseGold(String text) {
        Pattern money = Pattern.compile("(\\d{2,3}(?:\\.\\d{3}){2})");
        List<Item> all = new ArrayList<>();
        for (String line : text.split("\n")) {
            Matcher m = money.matcher(line);
            if (!m.find()) continue;
            int start = m.start();
            long buy = num(m.group(1));
            if (!m.find()) continue;
            long sell = num(m.group(1));
            if (buy < 5_000_000 || sell < 5_000_000 || sell > 1_000_000_000L) continue;
            String label = line.substring(0, start).replaceAll("\\(.*?\\)", " ").replace("|", " · ")
                    .replaceAll("\\s*·\\s*$", "").replaceAll("\\s+", " ").trim();
            label = label.replaceAll("^· ", "").trim();
            if (label.length() < 2) continue;
            all.add(new Item(label, buy, sell));
        }
        return all;
    }

    static List<Item> fetchGold() throws Exception {
        Exception last = null;
        List<Item> all = new ArrayList<>();
        for (String[] b : GOLD_BRANDS) {
            try {
                all.addAll(parseGoldPage(flatten(get("https://webgia.com/gia-vang/" + b[0] + "/")), b[1]));
            } catch (Exception e) { last = e; }
        }
        if (!all.isEmpty()) return all;
        try {
            List<Item> r = parseGold(flatten(get("https://baolamdong.vn/gia-vang")));
            if (!r.isEmpty()) return r.size() > 30 ? r.subList(0, 30) : r;
        } catch (Exception e) { last = e; }
        throw last == null ? new Exception("không đọc được bảng giá") : last;
    }

    // ---------- xăng dầu Petrolimex: vùng 1 / vùng 2 ----------
    private static final Pattern ZONE_CELL = Pattern.compile("^\\d{2}\\.\\d{3}$");

    static List<Item> parseFuelWebgia(String text, Data d) {
        List<Item> out = new ArrayList<>();
        for (String line : text.split("\n")) {
            String[] cells = line.split("\\|");
            for (int i = 0; i < cells.length; i++) cells[i] = cells[i].replaceAll("\\s+", " ").trim();
            for (int i = 1; i + 1 < cells.length; i++) {
                if (ZONE_CELL.matcher(cells[i]).matches() && ZONE_CELL.matcher(cells[i + 1]).matches()
                        && (cells[i - 1].contains("Xăng") || cells[i - 1].contains("Dầu"))) {
                    out.add(new Item(cells[i - 1], num(cells[i]), num(cells[i + 1])));
                    break;
                }
            }
        }
        Matcher m = Pattern.compile("Cập nhật lúc\\s*(\\d{1,2}:\\d{2})(?::\\d{2})?\\s*(\\d{1,2}/\\d{1,2})/(\\d{4})").matcher(text);
        if (m.find()) d.fuelDate = m.group(2) + " " + m.group(1);
        return out;
    }

    private static Item fuelRow(String text, String name, String label) {
        Matcher m = Pattern.compile(Pattern.quote(name) + "\\s*\\|\\s*([0-9][0-9.,]*)").matcher(text);
        if (!m.find()) return null;
        long p = num(m.group(1));
        return p < 1000 ? null : new Item(label, p, 0);
    }

    static List<Item> fetchFuel(Data d) throws Exception {
        Exception last = null;
        try {
            List<Item> r = parseFuelWebgia(flatten(get("https://webgia.com/gia-xang-dau/petrolimex/")), d);
            if (!r.isEmpty()) return r;
        } catch (Exception e) { last = e; }
        try {   // dự phòng: chỉ có một mức giá (vùng 1)
            String text = flatten(get("https://giacaphe.com/gia-xang-dau/"));
            List<Item> out = new ArrayList<>();
            Item a = fuelRow(text, "Xăng RON 95-III", "Xăng RON 95-III");
            Item b = fuelRow(text, "Xăng E5 RON 92-II", "Xăng E5 RON 92-II");
            Item c = fuelRow(text, "Dầu DO 0,05S-II", "Dầu DO 0,05S-II");
            if (a != null) out.add(a);
            if (b != null) out.add(b);
            if (c != null) out.add(c);
            Matcher m = Pattern.compile("Lần điều chỉnh[^0-9]*(\\d{1,2}/\\d{1,2})/(\\d{2,4})").matcher(text);
            d.fuelDate = m.find() ? m.group(1) : "";
            if (!out.isEmpty()) return out;
        } catch (Exception e) { last = e; }
        throw last == null ? new Exception("không đọc được bảng giá") : last;
    }

    // ---------- lưu / đọc ----------
    private static JSONArray toJson(List<Item> l) throws Exception {
        JSONArray a = new JSONArray();
        for (Item i : l) a.put(new JSONObject().put("n", i.name).put("a", i.v1).put("b", i.v2));
        return a;
    }

    private static List<Item> fromJson(JSONArray a) {
        List<Item> l = new ArrayList<>();
        if (a == null) return l;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) l.add(new Item(o.optString("n"), o.optLong("a"), o.optLong("b")));
        }
        return l;
    }

    static Data load(Context c) {
        Data d = new Data();
        String s = Prefs.sp(c).getString("pjson2", null);
        if (s == null) return d;
        try {
            JSONObject o = new JSONObject(s);
            d.coffee = fromJson(o.optJSONArray("coffee"));
            d.pepper = fromJson(o.optJSONArray("pepper"));
            d.gold = fromJson(o.optJSONArray("gold"));
            d.fuel = fromJson(o.optJSONArray("fuel"));
            d.fuelDate = o.optString("fdate", "");
            JSONArray st = o.optJSONArray("st");
            if (st != null) for (int i = 0; i < 4 && i < st.length(); i++) d.status[i] = st.optString(i);
            d.time = Prefs.sp(c).getLong("ptime", 0);
        } catch (Exception ignored) { }
        return d;
    }

    private static void save(Context c, Data d, long now) throws Exception {
        JSONObject o = new JSONObject();
        o.put("coffee", toJson(d.coffee)).put("pepper", toJson(d.pepper)).put("gold", toJson(d.gold)).put("fuel", toJson(d.fuel));
        o.put("fdate", d.fuelDate);
        JSONArray st = new JSONArray();
        for (String s : d.status) st.put(s);
        o.put("st", st);
        Prefs.sp(c).edit().putString("pjson2", o.toString()).putLong("ptime", now).apply();
    }

    private interface Job { void run() throws Exception; }

    private static Thread start(final Job j, final String[] status, final int idx, final boolean[] got) {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try { status[idx] = ""; j.run(); if (status[idx].length() == 0) status[idx] = "OK"; got[idx] = true; } catch (Exception e) { status[idx] = shortStatus(e); }
            }
        });
        t.start();
        return t;
    }

    /** Gọi trong luồng nền. Các mục đang bật được tải song song; mục lỗi giữ giá trị cũ và ghi lý do vào status. */
    static boolean fetch(Context c) {
        long now = System.currentTimeMillis();
        Prefs.sp(c).edit().putLong("ptry", now).apply();
        final Data d = load(c);
        final boolean[] got = new boolean[4];
        List<Thread> ts = new ArrayList<>();
        if (Prefs.priceCoffee(c)) ts.add(start(() -> {
            lastNote.set("");
            List<Item> giac = new ArrayList<>(), regs = new ArrayList<>();
            Exception err = null;
            try { giac = coffeeFromGiacaphe(); } catch (Exception e) { err = e; }
            try {
                regs = fetchRegions(new String[]{"https://baolamdong.vn/gia-ca-phe/", "https://webgia.com/gia-hang-hoa/ca-phe/"}, COFFEE_REGIONS, 20000, 400000);
            } catch (Exception e) { if (err == null) err = e; }
            List<Item> merged = new ArrayList<>();
            List<Item> giacRegions = new ArrayList<>();
            for (Item it : giac) { if (it.name.equals("Trung bình") || it.name.equals("Cao nhất")) merged.add(it); else giacRegions.add(it); }
            List<Item> regions = giacRegions.size() >= 3 ? giacRegions : (regs.isEmpty() ? giacRegions : regs);
            merged.addAll(regions);
            if (merged.isEmpty()) throw err == null ? new Exception("không đọc được bảng giá") : err;
            d.coffee = merged;
            String note = lastNote.get();
            d.status[0] = "OK · " + (giacRegions.size() >= 3 ? note : (regs.isEmpty() ? note : note + "; baolamdong " + regs.size() + " vùng"));
        }, d.status, 0, got));
        if (Prefs.pricePepper(c)) ts.add(start(() -> {
            lastNoteP.set("");
            List<Item> giac = new ArrayList<>(), regs = new ArrayList<>();
            Exception err = null;
            try { giac = pepperFromGiacaphe(); } catch (Exception e) { err = e; }
            List<Item> head = new ArrayList<>(), giacRegions = new ArrayList<>();
            for (Item it : giac) { if (it.name.equals("Cao nhất")) head.add(it); else giacRegions.add(it); }
            if (giacRegions.size() < 3) {
                try {
                    regs = fetchRegions(new String[]{"https://baolamdong.vn/gia-tieu", "https://baolamdong.vn/gia-tieu/lam-dong", "https://baolamdong.vn/gia-tieu/dak-lak"},
                            PEPPER_REGIONS, 50000, 500000);
                } catch (Exception e) { if (err == null) err = e; }
            }
            List<Item> merged = new ArrayList<>(head);
            merged.addAll(giacRegions.size() >= 3 ? giacRegions : (regs.isEmpty() ? giacRegions : regs));
            if (merged.isEmpty()) throw err == null ? new Exception("không đọc được bảng giá") : err;
            d.pepper = merged;
            d.status[1] = "OK · " + (giacRegions.size() >= 3 ? lastNoteP.get() : (regs.isEmpty() ? lastNoteP.get() : "baolamdong " + regs.size() + " vùng"));
        }, d.status, 1, got));
        if (Prefs.priceGold(c)) ts.add(start(() -> d.gold = fetchGold(), d.status, 2, got));
        if (Prefs.priceFuel(c)) ts.add(start(() -> d.fuel = fetchFuel(d), d.status, 3, got));
        for (Thread t : ts) { try { t.join(45000); } catch (InterruptedException ignored) { } }
        boolean any = got[0] || got[1] || got[2] || got[3];
        try { save(c, d, any ? now : Prefs.sp(c).getLong("ptime", 0)); } catch (Exception ignored) { }
        return any;
    }

    static boolean isStale(Context c) {
        if (!anyEnabled(c)) return false;
        long now = System.currentTimeMillis();
        return now - Prefs.sp(c).getLong("ptime", 0) > MAX_AGE && now - Prefs.sp(c).getLong("ptry", 0) > RETRY_GAP;
    }

    static boolean anyEnabled(Context c) {
        return Prefs.priceCoffee(c) || Prefs.pricePepper(c) || Prefs.priceGold(c) || Prefs.priceFuel(c);
    }

    static void refreshIfStale(Context c) {
        if (!anyEnabled(c)) return;
        long now = System.currentTimeMillis();
        if (now - Prefs.sp(c).getLong("ptime", 0) > MAX_AGE && now - Prefs.sp(c).getLong("ptry", 0) > RETRY_GAP) fetch(c);
    }

    // ---------- tab của widget ----------
    /** Danh sách tab đang bật: 0 = cà phê/tiêu, 1 = vàng, 2 = xăng dầu. */
    static List<Integer> enabledTabs(Context c) {
        List<Integer> t = new ArrayList<>();
        if (Prefs.priceCoffee(c) || Prefs.pricePepper(c)) t.add(0);
        if (Prefs.priceGold(c)) t.add(1);
        if (Prefs.priceFuel(c)) t.add(2);
        return t;
    }

    static int currentTab(Context c, List<Integer> tabs) {
        int cur = Prefs.priceTab(c);
        if (tabs.contains(cur)) return cur;
        return tabs.isEmpty() ? 0 : tabs.get(0);
    }
}
