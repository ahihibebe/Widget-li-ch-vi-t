package vn.widget.lich;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Giá cà phê / hồ tiêu theo tỉnh, giá vàng, giá xăng dầu.
 * Nguồn: baolamdong.vn (cà phê, tiêu, vàng) và giacaphe.com (xăng dầu, dự phòng cà phê). Chỉ mang tính tham khảo.
 */
public class PriceClient {
    static final long MAX_AGE = 30 * 60 * 1000L;
    static final long RETRY_GAP = 5 * 60 * 1000L;
    static final String UA = "Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    /** Mỗi vùng: tên hiển thị đứng đầu, sau đó là các cách viết khác trên web. */
    static final String[][] COFFEE_REGIONS = {
            {"Đắk Lắk", "Đắc Lắc", "Đăk Lăk"}, {"Gia Lai"}, {"Lâm Đồng"}, {"Đắk Nông", "Đắc Nông", "Đăk Nông"},
            {"Kon Tum"}, {"Đồng Nai"}, {"Bình Phước"}};
    static final String[][] PEPPER_REGIONS = {
            {"Đắk Lắk", "Đắc Lắc", "Đăk Lăk"}, {"Gia Lai"}, {"Lâm Đồng"}, {"Đồng Nai"}, {"Đắk Nông", "Đắc Nông", "Đăk Nông"},
            {"Bình Phước"}, {"Bà Rịa"}, {"Quảng Trị"}};

    /** Regions/fuel: v1 = giá, v2 = thay đổi (có dấu). Gold: v1 = mua vào, v2 = bán ra (đồng/lượng). */
    static class Item {
        String name;
        long v1, v2;
        Item(String n, long a, long b) { name = n; v1 = a; v2 = b; }
    }

    static class Data {
        List<Item> coffee = new ArrayList<>(), pepper = new ArrayList<>(), gold = new ArrayList<>(), fuel = new ArrayList<>();
        String fuelDate = "";
        long time;
        String[] status = {"", "", "", ""};   // cà phê, tiêu, vàng, xăng dầu
        boolean any() { return !coffee.isEmpty() || !pepper.isEmpty() || !gold.isEmpty() || !fuel.isEmpty(); }
    }

    // ---------- tiện ích ----------
    static long num(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) if (ch >= '0' && ch <= '9') b.append(ch);
        return b.length() == 0 || b.length() > 15 ? 0 : Long.parseLong(b.toString());
    }

    static String fmt(long v) {
        String s = String.valueOf(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append('.');
            b.append(s.charAt(i));
        }
        return (v < 0 ? "-" : "") + b;
    }

    /** 142000000 -> "142,0" (triệu đồng/lượng) */
    static String fmtMillion(long v) {
        return String.format(Locale.US, "%.1f", v / 1_000_000.0).replace('.', ',');
    }

    static String get(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setConnectTimeout(8000);
            con.setReadTimeout(10000);
            con.setRequestProperty("User-Agent", UA);
            con.setRequestProperty("Accept-Language", "vi-VN,vi;q=0.9");
            int code = con.getResponseCode();
            if (code >= 400) throw new Exception("HTTP " + code);
            BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) > 0) {
                sb.append(buf, 0, n);
                if (sb.length() > 3_000_000) break;
            }
            r.close();
            return sb.toString();
        } finally {
            con.disconnect();
        }
    }

    /** HTML -> chữ: ô bảng ngăn bằng " | ", mỗi hàng một dòng. */
    static String flatten(String html) {
        String s = html.replaceAll("(?is)<script.*?</script>|<style.*?</style>|<!--.*?-->", " ");
        s = s.replaceAll("(?i)</t[dh]>", " | ").replaceAll("(?i)</tr>|<br\\s*/?>|</p>|</li>|</h\\d>|</div>", "\n");
        s = s.replaceAll("<[^>]+>", " ").replace("&nbsp;", " ").replace("&amp;", "&");
        return s.replaceAll("[ \\t\\u00A0]+", " ");
    }

    private static String shortStatus(Exception e) {
        String m = e.getMessage();
        if (m == null) m = e.getClass().getSimpleName();
        return m.length() > 40 ? m.substring(0, 40) : m;
    }

    // ---------- cà phê / tiêu theo vùng ----------
    private static String regionLabel(String name) {
        if (name.equals("Đắk Nông")) return "Đắk Nông (cũ)";
        if (name.equals("Bà Rịa")) return "Bà Rịa - Vũng Tàu";
        return name;
    }

    /** Tìm giá của từng vùng: ưu tiên cùng một dòng (hàng bảng), nếu không thấy thì tìm xuyên dòng (dạng thẻ). */
    static List<Item> parseRegions(String text, String[][] regions, long min, long max) {
        text = Normalizer.normalize(text, Normalizer.Form.NFC);
        String flat = text.replace('\n', ' ');
        List<Item> out = new ArrayList<>();
        for (String[] names : regions) {
            StringBuilder alt = new StringBuilder();
            for (String n : names) { if (alt.length() > 0) alt.append('|'); alt.append(Pattern.quote(Normalizer.normalize(n, Normalizer.Form.NFC))); }
            String tail = "(\\d{2,3}[.,]\\d{3})(?!\\d)(?:(?:\\s*\\|)?\\s*([↓↑▼▲]|giảm|tăng)\\s*(?:giảm|tăng)?\\s*([0-9][0-9.,]*))?";
            Item found = null;
            String[] passes = {"(?:" + alt + ")[^0-9\\n]{0,300}?" + tail, "(?:" + alt + ")[^0-9]{0,140}?" + tail};
            String[] src = {text, flat};
            for (int k = 0; k < 2 && found == null; k++) {
                Matcher m = Pattern.compile(passes[k]).matcher(src[k]);
                while (m.find()) {
                    long p = num(m.group(1));
                    if (p < min || p > max) continue;
                    long ch = 0;
                    if (m.group(3) != null) {
                        ch = num(m.group(3));
                        if (m.group(2) != null && "↓▼giảm".contains(m.group(2))) ch = -ch;
                    }
                    found = new Item(regionLabel(names[0]), p, ch);
                    break;
                }
            }
            if (found != null) out.add(found);
        }
        return out;
    }

    /** Thử lần lượt các địa chỉ, lấy danh sách có nhiều vùng nhất. */
    static List<Item> fetchRegions(String[] urls, String[][] regions, long min, long max) throws Exception {
        Exception last = null;
        List<Item> best = new ArrayList<>();
        for (String u : urls) {
            try {
                List<Item> r = parseRegions(flatten(get(u)), regions, min, max);
                if (r.size() > best.size()) best = r;
                if (best.size() >= 4) break;
            } catch (Exception e) {
                last = e;
            }
        }
        if (best.isEmpty()) throw last == null ? new Exception("không đọc được bảng giá") : last;
        return best;
    }

    static List<Item> coffeeFromGiacaphe() throws Exception {
        String html = get("https://giacaphe.com/gia-ca-phe-noi-dia/");
        String t = flatten(html);
        Matcher m = Pattern.compile("trung bình[^0-9]{0,40}(\\d{2,3}[.,]\\d{3})", Pattern.CASE_INSENSITIVE).matcher(t);
        List<Item> out = new ArrayList<>();
        if (m.find()) {
            long p = num(m.group(1));
            long ch = 0;
            Matcher d = Pattern.compile("(giảm|tăng)[^0-9+\\-]{0,20}([+\\-]?\\d[\\d.,]*)\\s*(?:đ|vnđ|đồng)", Pattern.CASE_INSENSITIVE).matcher(t);
            if (d.find()) ch = d.group(1).equalsIgnoreCase("giảm") ? -num(d.group(2)) : num(d.group(2));
            if (p > 20000) out.add(new Item("Trung bình", p, ch));
        }
        if (out.isEmpty()) throw new Exception("không đọc được bảng giá");
        return out;
    }

    // ---------- vàng ----------
    private static final String[][] GOLD_BRANDS = {
            {"sjc", "SJC"}, {"doji", "DOJI"}, {"pnj", "PNJ"}, {"bao-tin-minh-chau", "Bảo Tín Minh Châu"},
            {"bao-tin-manh-hai", "Bảo Tín Mạnh Hải"}, {"phu-quy", "Phú Quý"}, {"mi-hong", "Mi Hồng"}, {"ngoc-tham", "Ngọc Thẩm"}};
    private static final Pattern MONEY_CELL = Pattern.compile("^\\d{1,3}(?:\\.\\d{3}){2}$");

    /** Đọc các hàng "… | mua | bán |" của một trang webgia (đơn vị đồng/chỉ hoặc đồng/lượng), trả về đồng/lượng. */
    static List<Item> parseGoldPage(String text, String brand) {
        long factor = 0;
        Matcher u = Pattern.compile("Đơn vị:\\s*đồng\\s*/\\s*(chỉ|lượng)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (u.find()) factor = u.group(1).equalsIgnoreCase("chỉ") ? 10 : 1;
        List<Item> out = new ArrayList<>();
        for (String line : text.split("\n")) {
            String[] cells = line.split("\\|");
            for (int i = 0; i < cells.length; i++) cells[i] = cells[i].replaceAll("\\s+", " ").trim();
            for (int i = 1; i + 1 < cells.length; i++) {
                if (!MONEY_CELL.matcher(cells[i]).matches() || !MONEY_CELL.matcher(cells[i + 1]).matches()) continue;
                String label = cells[i - 1];
                if (label.length() < 3 || MONEY_CELL.matcher(label).matches()) break;
                long buy = num(cells[i]), sell = num(cells[i + 1]);
                long f = factor != 0 ? factor : (buy < 30_000_000L ? 10 : 1);
                buy *= f; sell *= f;
                if (buy < 5_000_000L || sell > 800_000_000L || sell < buy * 0.8) break;
                label = label.replaceAll("\\(.*?\\)", " ").replaceAll("\\s+", " ").trim();
                if (!label.toLowerCase(Locale.ROOT).contains(brand.toLowerCase(Locale.ROOT))) label = brand + " · " + label;
                boolean dup = false;
                for (Item x : out) if (x.name.equals(label) && x.v1 == buy && x.v2 == sell) dup = true;
                if (!dup) out.add(new Item(label, buy, sell));
                break;
            }
        }
        return out;
    }

    /** Parser cho trang tổng hợp baolamdong.vn (dùng dự phòng). */
    static List<Item> parseGold(String text) {
        Pattern money = Pattern.compile("(\\d{2,3}(?:\\.\\d{3}){2})");
        List<Item> all = new ArrayList<>();
        for (String line : text.split("\n")) {
            Matcher m = money.matcher(line);
            if (!m.find()) continue;
            int start = m.start();
            long buy = num(m.group(1));
            if (!m.find()) continue;
            long sell = num(m.group(1));
            if (buy < 5_000_000 || sell < 5_000_000 || sell > 1_000_000_000L) continue;
            String label = line.substring(0, start).replaceAll("\\(.*?\\)", " ").replace("|", " · ")
                    .replaceAll("\\s*·\\s*$", "").replaceAll("\\s+", " ").trim();
            label = label.replaceAll("^· ", "").trim();
            if (label.length() < 2) continue;
            all.add(new Item(label, buy, sell));
        }
        return all;
    }

    static List<Item> fetchGold() throws Exception {
        Exception last = null;
        List<Item> all = new ArrayList<>();
        for (String[] b : GOLD_BRANDS) {
            try {
                all.addAll(parseGoldPage(flatten(get("https://webgia.com/gia-vang/" + b[0] + "/")), b[1]));
            } catch (Exception e) { last = e; }
        }
        if (!all.isEmpty()) return all;
        try {
            List<Item> r = parseGold(flatten(get("https://baolamdong.vn/gia-vang")));
            if (!r.isEmpty()) return r.size() > 30 ? r.subList(0, 30) : r;
        } catch (Exception e) { last = e; }
        throw last == null ? new Exception("không đọc được bảng giá") : last;
    }

    // ---------- xăng dầu Petrolimex: vùng 1 / vùng 2 ----------
    private static final Pattern ZONE_CELL = Pattern.compile("^\\d{2}\\.\\d{3}$");

    static List<Item> parseFuelWebgia(String text, Data d) {
        List<Item> out = new ArrayList<>();
        for (String line : text.split("\n")) {
            String[] cells = line.split("\\|");
            for (int i = 0; i < cells.length; i++) cells[i] = cells[i].replaceAll("\\s+", " ").trim();
            for (int i = 1; i + 1 < cells.length; i++) {
                if (ZONE_CELL.matcher(cells[i]).matches() && ZONE_CELL.matcher(cells[i + 1]).matches()
                        && (cells[i - 1].contains("Xăng") || cells[i - 1].contains("Dầu"))) {
                    out.add(new Item(cells[i - 1], num(cells[i]), num(cells[i + 1])));
                    break;
                }
            }
        }
        Matcher m = Pattern.compile("Cập nhật lúc\\s*(\\d{1,2}:\\d{2})(?::\\d{2})?\\s*(\\d{1,2}/\\d{1,2})/(\\d{4})").matcher(text);
        if (m.find()) d.fuelDate = m.group(2) + " " + m.group(1);
        return out;
    }

    private static Item fuelRow(String text, String name, String label) {
        Matcher m = Pattern.compile(Pattern.quote(name) + "\\s*\\|\\s*([0-9][0-9.,]*)").matcher(text);
        if (!m.find()) return null;
        long p = num(m.group(1));
        return p < 1000 ? null : new Item(label, p, 0);
    }

    static List<Item> fetchFuel(Data d) throws Exception {
        Exception last = null;
        try {
            List<Item> r = parseFuelWebgia(flatten(get("https://webgia.com/gia-xang-dau/petrolimex/")), d);
            if (!r.isEmpty()) return r;
        } catch (Exception e) { last = e; }
        try {   // dự phòng: chỉ có một mức giá (vùng 1)
            String text = flatten(get("https://giacaphe.com/gia-xang-dau/"));
            List<Item> out = new ArrayList<>();
            Item a = fuelRow(text, "Xăng RON 95-III", "Xăng RON 95-III");
            Item b = fuelRow(text, "Xăng E5 RON 92-II", "Xăng E5 RON 92-II");
            Item c = fuelRow(text, "Dầu DO 0,05S-II", "Dầu DO 0,05S-II");
            if (a != null) out.add(a);
            if (b != null) out.add(b);
            if (c != null) out.add(c);
            Matcher m = Pattern.compile("Lần điều chỉnh[^0-9]*(\\d{1,2}/\\d{1,2})/(\\d{2,4})").matcher(text);
            d.fuelDate = m.find() ? m.group(1) : "";
            if (!out.isEmpty()) return out;
        } catch (Exception e) { last = e; }
        throw last == null ? new Exception("không đọc được bảng giá") : last;
    }

    // ---------- lưu / đọc ----------
    private static JSONArray toJson(List<Item> l) throws Exception {
        JSONArray a = new JSONArray();
        for (Item i : l) a.put(new JSONObject().put("n", i.name).put("a", i.v1).put("b", i.v2));
        return a;
    }

    private static List<Item> fromJson(JSONArray a) {
        List<Item> l = new ArrayList<>();
        if (a == null) return l;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) l.add(new Item(o.optString("n"), o.optLong("a"), o.optLong("b")));
        }
        return l;
    }

    static Data load(Context c) {
        Data d = new Data();
        String s = Prefs.sp(c).getString("pjson2", null);
        if (s == null) return d;
        try {
            JSONObject o = new JSONObject(s);
            d.coffee = fromJson(o.optJSONArray("coffee"));
            d.pepper = fromJson(o.optJSONArray("pepper"));
            d.gold = fromJson(o.optJSONArray("gold"));
            d.fuel = fromJson(o.optJSONArray("fuel"));
            d.fuelDate = o.optString("fdate", "");
            JSONArray st = o.optJSONArray("st");
            if (st != null) for (int i = 0; i < 4 && i < st.length(); i++) d.status[i] = st.optString(i);
            d.time = Prefs.sp(c).getLong("ptime", 0);
        } catch (Exception ignored) { }
        return d;
    }

    private static void save(Context c, Data d, long now) throws Exception {
        JSONObject o = new JSONObject();
        o.put("coffee", toJson(d.coffee)).put("pepper", toJson(d.pepper)).put("gold", toJson(d.gold)).put("fuel", toJson(d.fuel));
        o.put("fdate", d.fuelDate);
        JSONArray st = new JSONArray();
        for (String s : d.status) st.put(s);
        o.put("st", st);
        Prefs.sp(c).edit().putString("pjson2", o.toString()).putLong("ptime", now).apply();
    }

    /** Gọi trong luồng nền. Chỉ tải các mục đang bật; mục lỗi giữ giá trị cũ và ghi lý do vào status. */
    static boolean fetch(Context c) {
        long now = System.currentTimeMillis();
        Prefs.sp(c).edit().putLong("ptry", now).apply();
        Data d = load(c);
        boolean got = false;
        if (Prefs.priceCoffee(c)) {
            try {
                try {
                    d.coffee = fetchRegions(new String[]{"https://baolamdong.vn/gia-ca-phe/", "https://webgia.com/gia-hang-hoa/ca-phe/"}, COFFEE_REGIONS, 20000, 400000);
                } catch (Exception e) {
                    d.coffee = coffeeFromGiacaphe();
                }
                d.status[0] = "OK"; got = true;
            } catch (Exception e) { d.status[0] = shortStatus(e); }
        }
        if (Prefs.pricePepper(c)) {
            try {
                d.pepper = fetchRegions(new String[]{"https://baolamdong.vn/gia-tieu", "https://baolamdong.vn/gia-tieu/lam-dong", "https://baolamdong.vn/gia-tieu/dak-lak"},
                        PEPPER_REGIONS, 50000, 500000);
                d.status[1] = "OK"; got = true;
            } catch (Exception e) { d.status[1] = shortStatus(e); }
        }
        if (Prefs.priceGold(c)) {
            try { d.gold = fetchGold(); d.status[2] = "OK"; got = true; } catch (Exception e) { d.status[2] = shortStatus(e); }
        }
        if (Prefs.priceFuel(c)) {
            try { d.fuel = fetchFuel(d); d.status[3] = "OK"; got = true; } catch (Exception e) { d.status[3] = shortStatus(e); }
        }
        try { save(c, d, got ? now : Prefs.sp(c).getLong("ptime", 0)); } catch (Exception ignored) { }
        return got;
    }

    static boolean anyEnabled(Context c) {
        return Prefs.priceCoffee(c) || Prefs.pricePepper(c) || Prefs.priceGold(c) || Prefs.priceFuel(c);
    }

    static void refreshIfStale(Context c) {
        if (!anyEnabled(c)) return;
        long now = System.currentTimeMillis();
        if (now - Prefs.sp(c).getLong("ptime", 0) > MAX_AGE && now - Prefs.sp(c).getLong("ptry", 0) > RETRY_GAP) fetch(c);
    }

    // ---------- tab của widget ----------
    /** Danh sách tab đang bật: 0 = cà phê/tiêu, 1 = vàng, 2 = xăng dầu. */
    static List<Integer> enabledTabs(Context c) {
        List<Integer> t = new ArrayList<>();
        if (Prefs.priceCoffee(c) || Prefs.pricePepper(c)) t.add(0);
        if (Prefs.priceGold(c)) t.add(1);
        if (Prefs.priceFuel(c)) t.add(2);
        return t;
    }

    static int currentTab(Context c, List<Integer> tabs) {
        int cur = Prefs.priceTab(c);
        if (tabs.contains(cur)) return cur;
        return tabs.isEmpty() ? 0 : tabs.get(0);
    }
}
