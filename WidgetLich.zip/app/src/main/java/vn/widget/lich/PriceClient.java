package vn.widget.lich;

import android.content.Context;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Giá cà phê, hồ tiêu, xăng dầu lấy từ giacaphe.com (chỉ mang tính tham khảo). */
public class PriceClient {
    static final long MAX_AGE = 60 * 60 * 1000L;
    static final long RETRY_GAP = 10 * 60 * 1000L;

    static class Row {
        boolean ok;
        long price, change;
    }

    static class Data {
        Row coffee = new Row(), pepper = new Row(), ron95 = new Row(), e5 = new Row(), diesel = new Row();
        String fuelDate = "";
        long time;
        boolean any() { return coffee.ok || pepper.ok || ron95.ok || e5.ok || diesel.ok; }
    }

    static long num(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) if (ch >= '0' && ch <= '9') b.append(ch);
        return b.length() == 0 ? 0 : Long.parseLong(b.toString());
    }

    static String fmt(long v) {
        String s = String.valueOf(Math.abs(v));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append('.');
            b.append(s.charAt(i));
        }
        return (v < 0 ? "-" : "") + b;
    }

    private static String meta(String html) {
        Matcher m = Pattern.compile("<meta[^>]+name=\"description\"[^>]+content=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE).matcher(html);
        if (m.find()) return m.group(1);
        m = Pattern.compile("content=\"([^\"]*)\"[^>]+name=\"description\"", Pattern.CASE_INSENSITIVE).matcher(html);
        return m.find() ? m.group(1) : html;
    }

    private static long delta(String text) {
        Matcher m = Pattern.compile("(giảm|tăng)[^0-9+\\-]{0,20}([+\\-]?[0-9][0-9.,]*)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (!m.find()) return 0;
        long v = num(m.group(2));
        return m.group(1).equalsIgnoreCase("giảm") ? -v : v;
    }

    /** Đổi HTML thành chữ thường, ô bảng ngăn bằng " | ", mỗi hàng một dòng. */
    private static String flatten(String html) {
        String s = html.replaceAll("(?is)<script.*?</script>|<style.*?</style>", " ");
        s = s.replaceAll("(?i)</t[dh]>", " | ").replaceAll("(?i)</tr>|<br\\s*/?>|</p>|</li>|</h\\d>", "\n");
        s = s.replaceAll("<[^>]+>", " ").replace("&nbsp;", " ").replace("&amp;", "&");
        return s.replaceAll("[ \\t\\u00A0]+", " ");
    }

    static void fetchCoffee(Data d) {
        try {
            String html = GeoClient.http("https://giacaphe.com/gia-ca-phe-noi-dia/", 10000);
            String desc = meta(html);
            Matcher m = Pattern.compile("trung bình\\s*([0-9][0-9.,]*)\\s*(?:vnđ|VNĐ|đ|₫)\\s*/\\s*kg", Pattern.CASE_INSENSITIVE).matcher(desc);
            if (!m.find()) m = Pattern.compile("trung bình ở mức\\s*([0-9][0-9.,]*)", Pattern.CASE_INSENSITIVE).matcher(flatten(html));
            if (m.find()) {
                d.coffee.price = num(m.group(1));
                d.coffee.change = delta(desc);
                d.coffee.ok = d.coffee.price > 1000;
            }
        } catch (Exception ignored) { }
    }

    static void fetchPepper(Data d) {
        try {
            String html = GeoClient.http("https://giacaphe.com/gia-tieu-hom-nay/", 10000);
            String desc = meta(html);
            Matcher m = Pattern.compile("cao nhất\\s*([0-9][0-9.,]*)\\s*(?:vnđ|VNĐ|đ|₫)", Pattern.CASE_INSENSITIVE).matcher(desc);
            if (m.find()) {
                d.pepper.price = num(m.group(1));
                d.pepper.change = delta(desc);
                d.pepper.ok = d.pepper.price > 1000;
            }
        } catch (Exception ignored) { }
    }

    private static Row fuelRow(String text, String name) {
        Row r = new Row();
        Matcher m = Pattern.compile(Pattern.quote(name) + "\\s*\\|\\s*([0-9][0-9.,]*)\\s*\\|\\s*([+\\-−]?\\s*[0-9][0-9.,]*|0)?").matcher(text);
        if (m.find()) {
            r.price = num(m.group(1));
            String ch = m.group(2);
            if (ch != null) {
                long v = num(ch);
                r.change = (ch.contains("-") || ch.contains("−")) ? -v : v;
            }
            r.ok = r.price > 1000;
        }
        return r;
    }

    static void fetchFuel(Data d) {
        try {
            String text = flatten(GeoClient.http("https://giacaphe.com/gia-xang-dau/", 10000));
            d.ron95 = fuelRow(text, "Xăng RON 95-III");
            d.e5 = fuelRow(text, "Xăng E5 RON 92-II");
            d.diesel = fuelRow(text, "Dầu DO 0,05S-II");
            Matcher m = Pattern.compile("Lần điều chỉnh[^0-9]*(\\d{1,2}/\\d{1,2})/(\\d{2,4})").matcher(text);
            if (m.find()) d.fuelDate = m.group(1);
        } catch (Exception ignored) { }
    }

    private static void put(JSONObject o, String k, Row r) throws Exception {
        if (r.ok) o.put(k, new JSONObject().put("p", r.price).put("c", r.change));
    }

    private static Row get(JSONObject o, String k) {
        Row r = new Row();
        JSONObject x = o.optJSONObject(k);
        if (x != null) { r.ok = true; r.price = x.optLong("p"); r.change = x.optLong("c"); }
        return r;
    }

    static Data load(Context c) {
        Data d = new Data();
        String s = Prefs.sp(c).getString("pjson", null);
        if (s == null) return d;
        try {
            JSONObject o = new JSONObject(s);
            d.coffee = get(o, "coffee");
            d.pepper = get(o, "pepper");
            d.ron95 = get(o, "ron95");
            d.e5 = get(o, "e5");
            d.diesel = get(o, "diesel");
            d.fuelDate = o.optString("fdate", "");
            d.time = Prefs.sp(c).getLong("ptime", 0);
        } catch (Exception ignored) { }
        return d;
    }

    /** Gọi trong luồng nền. Chỉ tải các mục đang bật; mục lỗi giữ giá trị cũ. */
    static boolean fetch(Context c) {
        long now = System.currentTimeMillis();
        Prefs.sp(c).edit().putLong("ptry", now).apply();
        Data old = load(c);
        Data d = new Data();
        d.coffee = old.coffee; d.pepper = old.pepper; d.ron95 = old.ron95; d.e5 = old.e5; d.diesel = old.diesel;
        d.fuelDate = old.fuelDate;
        boolean got = false;
        if (Prefs.priceCoffee(c)) { Row bak = d.coffee; d.coffee = new Row(); fetchCoffee(d); if (!d.coffee.ok) d.coffee = bak; else got = true; }
        if (Prefs.pricePepper(c)) { Row bak = d.pepper; d.pepper = new Row(); fetchPepper(d); if (!d.pepper.ok) d.pepper = bak; else got = true; }
        if (Prefs.priceFuel(c)) {
            Data f = new Data();
            fetchFuel(f);
            if (f.ron95.ok || f.e5.ok || f.diesel.ok) { d.ron95 = f.ron95; d.e5 = f.e5; d.diesel = f.diesel; d.fuelDate = f.fuelDate; got = true; }
        }
        if (!got) return false;
        try {
            JSONObject o = new JSONObject();
            put(o, "coffee", d.coffee); put(o, "pepper", d.pepper);
            put(o, "ron95", d.ron95); put(o, "e5", d.e5); put(o, "diesel", d.diesel);
            o.put("fdate", d.fuelDate);
            Prefs.sp(c).edit().putString("pjson", o.toString()).putLong("ptime", now).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean anyEnabled(Context c) { return Prefs.priceCoffee(c) || Prefs.pricePepper(c) || Prefs.priceFuel(c); }

    static void refreshIfStale(Context c) {
        if (!anyEnabled(c)) return;
        long now = System.currentTimeMillis();
        if (now - Prefs.sp(c).getLong("ptime", 0) > MAX_AGE && now - Prefs.sp(c).getLong("ptry", 0) > RETRY_GAP) fetch(c);
    }
}
